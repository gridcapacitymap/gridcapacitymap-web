--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg110+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: keycloak; Type: DATABASE; Schema: -; Owner: postgres_user
--

CREATE DATABASE keycloak WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE keycloak OWNER TO postgres_user;

\connect keycloak

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


ALTER TABLE public.admin_event_entity OWNER TO postgres_user;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO postgres_user;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO postgres_user;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO postgres_user;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO postgres_user;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO postgres_user;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO postgres_user;

--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO postgres_user;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO postgres_user;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO postgres_user;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO postgres_user;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO postgres_user;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO postgres_user;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO postgres_user;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO postgres_user;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO postgres_user;

--
-- Name: client_session; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


ALTER TABLE public.client_session OWNER TO postgres_user;

--
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_auth_status OWNER TO postgres_user;

--
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_note OWNER TO postgres_user;

--
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_prot_mapper OWNER TO postgres_user;

--
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_role OWNER TO postgres_user;

--
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_user_session_note OWNER TO postgres_user;

--
-- Name: component; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO postgres_user;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


ALTER TABLE public.component_config OWNER TO postgres_user;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO postgres_user;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO postgres_user;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO postgres_user;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO postgres_user;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO postgres_user;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255)
);


ALTER TABLE public.event_entity OWNER TO postgres_user;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024)
);


ALTER TABLE public.fed_user_attribute OWNER TO postgres_user;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO postgres_user;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO postgres_user;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO postgres_user;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO postgres_user;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO postgres_user;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO postgres_user;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO postgres_user;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO postgres_user;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO postgres_user;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO postgres_user;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


ALTER TABLE public.identity_provider OWNER TO postgres_user;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO postgres_user;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO postgres_user;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO postgres_user;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


ALTER TABLE public.keycloak_group OWNER TO postgres_user;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO postgres_user;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO postgres_user;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


ALTER TABLE public.offline_client_session OWNER TO postgres_user;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.offline_user_session OWNER TO postgres_user;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO postgres_user;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO postgres_user;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO postgres_user;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO postgres_user;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO postgres_user;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO postgres_user;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO postgres_user;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO postgres_user;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO postgres_user;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO postgres_user;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO postgres_user;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO postgres_user;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO postgres_user;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO postgres_user;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO postgres_user;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO postgres_user;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO postgres_user;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO postgres_user;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO postgres_user;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO postgres_user;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO postgres_user;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO postgres_user;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO postgres_user;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO postgres_user;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO postgres_user;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO postgres_user;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO postgres_user;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL
);


ALTER TABLE public.user_attribute OWNER TO postgres_user;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO postgres_user;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO postgres_user;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO postgres_user;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO postgres_user;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO postgres_user;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO postgres_user;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO postgres_user;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO postgres_user;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO postgres_user;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO postgres_user;

--
-- Name: user_session; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


ALTER TABLE public.user_session OWNER TO postgres_user;

--
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


ALTER TABLE public.user_session_note OWNER TO postgres_user;

--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


ALTER TABLE public.username_login_failure OWNER TO postgres_user;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: postgres_user
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO postgres_user;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
fc3b6c76-ce9d-4f3b-9803-bd96de5529ed	1a9c3688-b70a-4ad9-b9a0-ddae742b942c
5a45080a-e4c1-47ca-9633-21e15b714a44	3eb93418-25d3-4021-975b-3cb54da81394
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
c0617e1b-be7f-4b73-839e-af502edd1110	\N	auth-cookie	69219f75-5959-4178-a860-0ae90853470b	d8a7a3e4-d406-4507-9868-91c9117b4caa	2	10	f	\N	\N
74f7aaca-3826-4caf-ba07-637f5c783eaa	\N	auth-spnego	69219f75-5959-4178-a860-0ae90853470b	d8a7a3e4-d406-4507-9868-91c9117b4caa	3	20	f	\N	\N
7b20ca29-dc69-46c2-9151-293d0c8ab5a5	\N	identity-provider-redirector	69219f75-5959-4178-a860-0ae90853470b	d8a7a3e4-d406-4507-9868-91c9117b4caa	2	25	f	\N	\N
1220bd0c-f0f9-4358-a6eb-4f6fe4413d28	\N	\N	69219f75-5959-4178-a860-0ae90853470b	d8a7a3e4-d406-4507-9868-91c9117b4caa	2	30	t	b207dd63-547c-477a-9a40-0a02630e2368	\N
4a8450f5-8ddd-4c61-9301-0c201986732c	\N	auth-username-password-form	69219f75-5959-4178-a860-0ae90853470b	b207dd63-547c-477a-9a40-0a02630e2368	0	10	f	\N	\N
13b4a300-40b0-4cef-bc8d-479578b91ee2	\N	\N	69219f75-5959-4178-a860-0ae90853470b	b207dd63-547c-477a-9a40-0a02630e2368	1	20	t	4ebd4fce-d1c4-424d-a22f-2f166fe0087a	\N
53770f28-58ae-432e-8d63-0b56e24591e6	\N	conditional-user-configured	69219f75-5959-4178-a860-0ae90853470b	4ebd4fce-d1c4-424d-a22f-2f166fe0087a	0	10	f	\N	\N
49549deb-614f-4e1b-91d5-11893448d78b	\N	auth-otp-form	69219f75-5959-4178-a860-0ae90853470b	4ebd4fce-d1c4-424d-a22f-2f166fe0087a	0	20	f	\N	\N
79cccb8f-c83f-43d9-aac4-28e1ae54f4c2	\N	direct-grant-validate-username	69219f75-5959-4178-a860-0ae90853470b	2bec55b0-439b-4101-876d-168ee196f42a	0	10	f	\N	\N
7250ccbd-f97a-49ae-a8bc-4459a148702a	\N	direct-grant-validate-password	69219f75-5959-4178-a860-0ae90853470b	2bec55b0-439b-4101-876d-168ee196f42a	0	20	f	\N	\N
7b286824-9158-4d0c-adab-c8dec4cb9d1b	\N	\N	69219f75-5959-4178-a860-0ae90853470b	2bec55b0-439b-4101-876d-168ee196f42a	1	30	t	04b28f81-3f40-44c9-80f0-2ec7c42ad500	\N
36a8a92c-6b62-49bb-8f60-ddb76e7696fd	\N	conditional-user-configured	69219f75-5959-4178-a860-0ae90853470b	04b28f81-3f40-44c9-80f0-2ec7c42ad500	0	10	f	\N	\N
82cd11ed-bbed-44b0-a90a-6483710a3157	\N	direct-grant-validate-otp	69219f75-5959-4178-a860-0ae90853470b	04b28f81-3f40-44c9-80f0-2ec7c42ad500	0	20	f	\N	\N
b892f7b7-4d7b-4394-8e04-9006ed826896	\N	registration-page-form	69219f75-5959-4178-a860-0ae90853470b	069e58b3-781b-44a8-bb7e-436ec20710d6	0	10	t	8eeec7c5-a94a-41c3-a438-b7ced9c7f524	\N
681a5388-1595-4773-82e4-541f80743db0	\N	registration-user-creation	69219f75-5959-4178-a860-0ae90853470b	8eeec7c5-a94a-41c3-a438-b7ced9c7f524	0	20	f	\N	\N
e17985af-4496-4ef5-95c1-3e9f2a5ef217	\N	registration-profile-action	69219f75-5959-4178-a860-0ae90853470b	8eeec7c5-a94a-41c3-a438-b7ced9c7f524	0	40	f	\N	\N
7dc3c04e-098e-47fb-b031-179caa392386	\N	registration-password-action	69219f75-5959-4178-a860-0ae90853470b	8eeec7c5-a94a-41c3-a438-b7ced9c7f524	0	50	f	\N	\N
2d304188-05e1-450a-a595-2ef19106e394	\N	registration-recaptcha-action	69219f75-5959-4178-a860-0ae90853470b	8eeec7c5-a94a-41c3-a438-b7ced9c7f524	3	60	f	\N	\N
77fe1425-45cf-4374-abb8-9f3a35f5906c	\N	registration-terms-and-conditions	69219f75-5959-4178-a860-0ae90853470b	8eeec7c5-a94a-41c3-a438-b7ced9c7f524	3	70	f	\N	\N
515731ca-b95d-4095-a936-c8f895832a57	\N	reset-credentials-choose-user	69219f75-5959-4178-a860-0ae90853470b	486ef05e-c701-460b-bc5b-ecd16cfde9b6	0	10	f	\N	\N
5ed206ab-351e-489b-81b6-4dafffb000eb	\N	reset-credential-email	69219f75-5959-4178-a860-0ae90853470b	486ef05e-c701-460b-bc5b-ecd16cfde9b6	0	20	f	\N	\N
7d0b5a21-0c9f-4e78-81c6-350fc59b099e	\N	reset-password	69219f75-5959-4178-a860-0ae90853470b	486ef05e-c701-460b-bc5b-ecd16cfde9b6	0	30	f	\N	\N
a14ea390-8ba1-493f-9ea2-1fd221c5d943	\N	\N	69219f75-5959-4178-a860-0ae90853470b	486ef05e-c701-460b-bc5b-ecd16cfde9b6	1	40	t	27da4f4f-74e2-4538-a6af-669cc420a606	\N
a18c2fc2-c215-4681-ae02-2141f2a39e70	\N	conditional-user-configured	69219f75-5959-4178-a860-0ae90853470b	27da4f4f-74e2-4538-a6af-669cc420a606	0	10	f	\N	\N
cb4640b5-d3ae-47d3-b3f1-f60419e8f495	\N	reset-otp	69219f75-5959-4178-a860-0ae90853470b	27da4f4f-74e2-4538-a6af-669cc420a606	0	20	f	\N	\N
9c87c4b4-95a5-483f-b1c4-2df2956159bb	\N	client-secret	69219f75-5959-4178-a860-0ae90853470b	f87c0951-6f71-47fe-9ff3-30b469c4eb2d	2	10	f	\N	\N
67244e3e-86be-477f-92ef-4ea0dc503626	\N	client-jwt	69219f75-5959-4178-a860-0ae90853470b	f87c0951-6f71-47fe-9ff3-30b469c4eb2d	2	20	f	\N	\N
5268b9b7-7273-4edb-952c-546761a46d50	\N	client-secret-jwt	69219f75-5959-4178-a860-0ae90853470b	f87c0951-6f71-47fe-9ff3-30b469c4eb2d	2	30	f	\N	\N
18b1e7e1-2281-4dab-9533-134d78aa9b1e	\N	client-x509	69219f75-5959-4178-a860-0ae90853470b	f87c0951-6f71-47fe-9ff3-30b469c4eb2d	2	40	f	\N	\N
9c847382-b589-418a-95cc-d493d75d9c75	\N	idp-review-profile	69219f75-5959-4178-a860-0ae90853470b	aa27d6d8-6df4-42c8-b744-42b27f886e49	0	10	f	\N	303f70ce-abac-415c-beb0-f89db870f49a
71481c1b-ce96-4def-bcc0-fa75e58ba3e8	\N	\N	69219f75-5959-4178-a860-0ae90853470b	aa27d6d8-6df4-42c8-b744-42b27f886e49	0	20	t	7b1fe09f-5248-4f3b-ae0f-ee9e3d526770	\N
a991465f-a2ce-443c-87cb-9f44d7166702	\N	idp-create-user-if-unique	69219f75-5959-4178-a860-0ae90853470b	7b1fe09f-5248-4f3b-ae0f-ee9e3d526770	2	10	f	\N	3d5af636-0f3f-4530-af0e-22d24369884b
7159358d-a95f-4bd7-a393-3923d8f215a4	\N	\N	69219f75-5959-4178-a860-0ae90853470b	7b1fe09f-5248-4f3b-ae0f-ee9e3d526770	2	20	t	10b9c65b-d6f1-4477-b35e-0fd4f4ad11f0	\N
c9cda99f-a665-4d7c-97c4-e59ba6d68296	\N	idp-confirm-link	69219f75-5959-4178-a860-0ae90853470b	10b9c65b-d6f1-4477-b35e-0fd4f4ad11f0	0	10	f	\N	\N
19034c6e-3042-41b9-9abf-23684b322947	\N	\N	69219f75-5959-4178-a860-0ae90853470b	10b9c65b-d6f1-4477-b35e-0fd4f4ad11f0	0	20	t	36c79984-7a3b-4b7e-ae01-01325646ecb6	\N
9ea403c7-549c-4a3f-adbe-9b06f90769a3	\N	idp-email-verification	69219f75-5959-4178-a860-0ae90853470b	36c79984-7a3b-4b7e-ae01-01325646ecb6	2	10	f	\N	\N
9c476d36-533e-4363-b33c-3d202ddafe37	\N	\N	69219f75-5959-4178-a860-0ae90853470b	36c79984-7a3b-4b7e-ae01-01325646ecb6	2	20	t	bec25c00-d30a-401d-aaf6-b60d9c24ba24	\N
f72b55c3-76dc-47f4-aace-29f6312b0fd6	\N	idp-username-password-form	69219f75-5959-4178-a860-0ae90853470b	bec25c00-d30a-401d-aaf6-b60d9c24ba24	0	10	f	\N	\N
3a49d59e-e09a-4558-866d-e48c9a0281f7	\N	\N	69219f75-5959-4178-a860-0ae90853470b	bec25c00-d30a-401d-aaf6-b60d9c24ba24	1	20	t	9062ada5-f80c-40bc-8767-4ef5380c37e5	\N
5fade4e9-c041-475d-90b9-672873858dc1	\N	conditional-user-configured	69219f75-5959-4178-a860-0ae90853470b	9062ada5-f80c-40bc-8767-4ef5380c37e5	0	10	f	\N	\N
5e1d155d-6e26-43f4-8ea1-634a1cf5ec55	\N	auth-otp-form	69219f75-5959-4178-a860-0ae90853470b	9062ada5-f80c-40bc-8767-4ef5380c37e5	0	20	f	\N	\N
7051e898-81be-4106-9469-8bd2c03cf90f	\N	http-basic-authenticator	69219f75-5959-4178-a860-0ae90853470b	5266ac07-2edc-41d1-bb1e-8305d5cf149d	0	10	f	\N	\N
f7aa2ec8-a8bc-4706-8dd3-1fe726cf8650	\N	docker-http-basic-authenticator	69219f75-5959-4178-a860-0ae90853470b	46bbeac2-5dbb-4e92-9a3d-cbab842c8e48	0	10	f	\N	\N
6069f60f-b3cf-4570-803c-60ea7ea403ab	\N	idp-email-verification	2d41d0c8-a7ac-4cdc-b114-4baf577da237	7a292ea3-b8f6-4261-8809-f236fb8f6b59	2	10	f	\N	\N
df981842-1242-4255-8c6e-71eac0759e35	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	7a292ea3-b8f6-4261-8809-f236fb8f6b59	2	20	t	c4ba9d25-dc0b-44d0-811c-b2b1de63e825	\N
112f01bc-4751-4792-a259-50234e8bf0ad	\N	conditional-user-configured	2d41d0c8-a7ac-4cdc-b114-4baf577da237	289b2186-523b-4d52-a990-239e018d6cc8	0	10	f	\N	\N
eba455da-c715-4c81-a5c4-b97e65c125b4	\N	auth-otp-form	2d41d0c8-a7ac-4cdc-b114-4baf577da237	289b2186-523b-4d52-a990-239e018d6cc8	0	20	f	\N	\N
52050324-5c7a-45d0-be7d-0c9c06ca5374	\N	conditional-user-configured	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0d5329d5-6efc-435b-b508-b7b4bf06f0c7	0	10	f	\N	\N
d639e139-a637-4979-8edb-eef3fed66a46	\N	direct-grant-validate-otp	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0d5329d5-6efc-435b-b508-b7b4bf06f0c7	0	20	f	\N	\N
1ba5462d-e91d-4427-aa49-5466631b664e	\N	conditional-user-configured	2d41d0c8-a7ac-4cdc-b114-4baf577da237	52b7c9ed-9b58-4e76-bb4d-7d73232cc525	0	10	f	\N	\N
eb0a2edb-b7cf-4827-835e-8b4a25d44856	\N	auth-otp-form	2d41d0c8-a7ac-4cdc-b114-4baf577da237	52b7c9ed-9b58-4e76-bb4d-7d73232cc525	0	20	f	\N	\N
e7447a56-e2e0-485e-83b1-be6eb5efc89e	\N	idp-confirm-link	2d41d0c8-a7ac-4cdc-b114-4baf577da237	918bf8f1-f023-41df-ba96-66c448ec830b	0	10	f	\N	\N
4ad6c254-694d-4ba9-98a8-7f8c5750ca9c	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	918bf8f1-f023-41df-ba96-66c448ec830b	0	20	t	7a292ea3-b8f6-4261-8809-f236fb8f6b59	\N
e837cdbd-4c23-444b-b92b-b2dcb8e12c95	\N	conditional-user-configured	2d41d0c8-a7ac-4cdc-b114-4baf577da237	62ce1ce8-c933-4d59-a80b-99ecd915aa6e	0	10	f	\N	\N
ad5bb30d-897b-4a80-8a98-52d38056be10	\N	reset-otp	2d41d0c8-a7ac-4cdc-b114-4baf577da237	62ce1ce8-c933-4d59-a80b-99ecd915aa6e	0	20	f	\N	\N
dcb5747d-eb9d-4d17-a2a9-0dc6a4f98fa4	\N	idp-create-user-if-unique	2d41d0c8-a7ac-4cdc-b114-4baf577da237	a962c70d-d44b-427c-be61-59d0504c6f92	2	10	f	\N	6e5382f1-8095-433b-8767-b77e7c73b86b
39490c2d-7972-4cd3-96d8-cbc89c874426	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	a962c70d-d44b-427c-be61-59d0504c6f92	2	20	t	918bf8f1-f023-41df-ba96-66c448ec830b	\N
b1c548ea-26a9-4638-9446-2e760fa27c52	\N	idp-username-password-form	2d41d0c8-a7ac-4cdc-b114-4baf577da237	c4ba9d25-dc0b-44d0-811c-b2b1de63e825	0	10	f	\N	\N
ac0e8efa-f715-41e4-a3de-0511d6474233	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	c4ba9d25-dc0b-44d0-811c-b2b1de63e825	1	20	t	52b7c9ed-9b58-4e76-bb4d-7d73232cc525	\N
688ecede-31a4-4aa5-8ac1-8579b5f83267	\N	auth-cookie	2d41d0c8-a7ac-4cdc-b114-4baf577da237	e5bb4c58-afbf-446a-9b29-2bd461e788bd	2	10	f	\N	\N
94e7575b-cf5a-4459-8f51-ec76a5a7eff7	\N	auth-spnego	2d41d0c8-a7ac-4cdc-b114-4baf577da237	e5bb4c58-afbf-446a-9b29-2bd461e788bd	3	20	f	\N	\N
6c65d2f7-00e5-4908-a7ca-25287f123f28	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	e5bb4c58-afbf-446a-9b29-2bd461e788bd	2	30	t	775be4a1-89a2-456d-a64c-2428fbe9e14a	\N
7cadb732-2ca7-4d39-9d28-dbacf24dba80	\N	client-secret	2d41d0c8-a7ac-4cdc-b114-4baf577da237	bb432a90-61f9-4852-ae3b-3fb9819b95f5	2	10	f	\N	\N
0fdcd6c3-356b-46e8-8b26-9ead6c01abb9	\N	client-jwt	2d41d0c8-a7ac-4cdc-b114-4baf577da237	bb432a90-61f9-4852-ae3b-3fb9819b95f5	2	20	f	\N	\N
22cf0809-704d-4df8-8128-512be05d7eb1	\N	client-secret-jwt	2d41d0c8-a7ac-4cdc-b114-4baf577da237	bb432a90-61f9-4852-ae3b-3fb9819b95f5	2	30	f	\N	\N
9033522d-d414-4527-b4eb-4eaa2d127167	\N	client-x509	2d41d0c8-a7ac-4cdc-b114-4baf577da237	bb432a90-61f9-4852-ae3b-3fb9819b95f5	2	40	f	\N	\N
9387d702-3049-48b4-b16b-156034a18004	\N	direct-grant-validate-username	2d41d0c8-a7ac-4cdc-b114-4baf577da237	a9d873c2-73a1-4f1b-a565-7e1dcab6b1cc	0	10	f	\N	\N
b1feea58-c719-4dcf-9584-0035b41883b9	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	a9d873c2-73a1-4f1b-a565-7e1dcab6b1cc	1	30	t	0d5329d5-6efc-435b-b508-b7b4bf06f0c7	\N
b631cd1c-fffc-465d-b8f0-03410946581f	\N	docker-http-basic-authenticator	2d41d0c8-a7ac-4cdc-b114-4baf577da237	4417fff2-662e-4178-8659-b359d6df1601	0	10	f	\N	\N
e6e43766-b207-483a-be26-b456ef45b51a	\N	idp-review-profile	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0264017a-1809-4eb3-882b-30d0cfacc88e	0	10	f	\N	99be629a-eb3e-4cd8-8c2c-807795c7689b
d5cbbd98-4139-4c59-9439-0b407003d69a	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0264017a-1809-4eb3-882b-30d0cfacc88e	0	20	t	a962c70d-d44b-427c-be61-59d0504c6f92	\N
e3004159-cbdc-44cb-ab6b-fb80d09ebfd1	\N	auth-username-password-form	2d41d0c8-a7ac-4cdc-b114-4baf577da237	775be4a1-89a2-456d-a64c-2428fbe9e14a	0	10	f	\N	\N
51b01673-930b-45e5-8e04-4cb4e41540dd	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	775be4a1-89a2-456d-a64c-2428fbe9e14a	1	20	t	289b2186-523b-4d52-a990-239e018d6cc8	\N
db2f80b4-7f45-4159-9339-2f44a057f4fd	\N	registration-page-form	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0586966e-4ef5-4874-8286-509f5f6c93ee	0	10	t	2b26cc6e-97b3-44e7-8c1a-813bf3024855	\N
6bbe0852-5aab-45b3-8e2e-c52efb907792	\N	registration-user-creation	2d41d0c8-a7ac-4cdc-b114-4baf577da237	2b26cc6e-97b3-44e7-8c1a-813bf3024855	0	20	f	\N	\N
5c27c968-b433-46ff-90de-69c14e15cb91	\N	registration-profile-action	2d41d0c8-a7ac-4cdc-b114-4baf577da237	2b26cc6e-97b3-44e7-8c1a-813bf3024855	0	40	f	\N	\N
c5500466-126d-45a9-bcdc-495449c96d6c	\N	registration-password-action	2d41d0c8-a7ac-4cdc-b114-4baf577da237	2b26cc6e-97b3-44e7-8c1a-813bf3024855	0	50	f	\N	\N
92a574f4-83b5-4828-a313-4576026ffa8b	\N	registration-recaptcha-action	2d41d0c8-a7ac-4cdc-b114-4baf577da237	2b26cc6e-97b3-44e7-8c1a-813bf3024855	3	60	f	\N	\N
12e6a8cb-cac5-4885-abac-27d44909459e	\N	registration-terms-and-conditions	2d41d0c8-a7ac-4cdc-b114-4baf577da237	2b26cc6e-97b3-44e7-8c1a-813bf3024855	3	70	f	\N	\N
ffc287f7-5114-483b-a026-aaf1a3addc53	\N	reset-credentials-choose-user	2d41d0c8-a7ac-4cdc-b114-4baf577da237	04b71a86-1a66-4cb2-8518-ae68209084da	0	10	f	\N	\N
caf0a21a-640e-4730-a9a7-4c8c25eae2de	\N	reset-credential-email	2d41d0c8-a7ac-4cdc-b114-4baf577da237	04b71a86-1a66-4cb2-8518-ae68209084da	0	20	f	\N	\N
aecaf6ee-42c8-4588-aee1-cf1b0a4fdd47	\N	reset-password	2d41d0c8-a7ac-4cdc-b114-4baf577da237	04b71a86-1a66-4cb2-8518-ae68209084da	0	30	f	\N	\N
b71f93b3-3c9a-4040-8f26-f3b91bb6c7e3	\N	direct-grant-validate-password	2d41d0c8-a7ac-4cdc-b114-4baf577da237	a9d873c2-73a1-4f1b-a565-7e1dcab6b1cc	0	20	f	\N	\N
9e53ed5b-d200-4b0d-a44b-98b74ecccb9a	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	04b71a86-1a66-4cb2-8518-ae68209084da	1	40	t	62ce1ce8-c933-4d59-a80b-99ecd915aa6e	\N
f4995cb6-3537-42b3-878e-1248f1de3579	\N	http-basic-authenticator	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b4edc6fa-65f7-4636-a6b7-ae84b99f8e6e	0	10	f	\N	\N
68cff451-5376-49ed-a617-c8f23709daf5	\N	idp-auto-link	2d41d0c8-a7ac-4cdc-b114-4baf577da237	3990e788-e516-4bb8-864b-f98d040f0280	3	0	f	\N	\N
70d39bec-6cd4-4d7c-b5d6-a5e72303c9a4	\N	identity-provider-redirector	2d41d0c8-a7ac-4cdc-b114-4baf577da237	e5bb4c58-afbf-446a-9b29-2bd461e788bd	2	25	f	\N	\N
76046668-4c5c-4b49-94d0-6155d9cd8b65	\N	webauthn-authenticator-passwordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	3990e788-e516-4bb8-864b-f98d040f0280	0	1	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
d8a7a3e4-d406-4507-9868-91c9117b4caa	browser	browser based authentication	69219f75-5959-4178-a860-0ae90853470b	basic-flow	t	t
b207dd63-547c-477a-9a40-0a02630e2368	forms	Username, password, otp and other auth forms.	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
4ebd4fce-d1c4-424d-a22f-2f166fe0087a	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
2bec55b0-439b-4101-876d-168ee196f42a	direct grant	OpenID Connect Resource Owner Grant	69219f75-5959-4178-a860-0ae90853470b	basic-flow	t	t
04b28f81-3f40-44c9-80f0-2ec7c42ad500	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
069e58b3-781b-44a8-bb7e-436ec20710d6	registration	registration flow	69219f75-5959-4178-a860-0ae90853470b	basic-flow	t	t
8eeec7c5-a94a-41c3-a438-b7ced9c7f524	registration form	registration form	69219f75-5959-4178-a860-0ae90853470b	form-flow	f	t
486ef05e-c701-460b-bc5b-ecd16cfde9b6	reset credentials	Reset credentials for a user if they forgot their password or something	69219f75-5959-4178-a860-0ae90853470b	basic-flow	t	t
27da4f4f-74e2-4538-a6af-669cc420a606	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
f87c0951-6f71-47fe-9ff3-30b469c4eb2d	clients	Base authentication for clients	69219f75-5959-4178-a860-0ae90853470b	client-flow	t	t
aa27d6d8-6df4-42c8-b744-42b27f886e49	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	69219f75-5959-4178-a860-0ae90853470b	basic-flow	t	t
7b1fe09f-5248-4f3b-ae0f-ee9e3d526770	User creation or linking	Flow for the existing/non-existing user alternatives	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
10b9c65b-d6f1-4477-b35e-0fd4f4ad11f0	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
36c79984-7a3b-4b7e-ae01-01325646ecb6	Account verification options	Method with which to verity the existing account	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
bec25c00-d30a-401d-aaf6-b60d9c24ba24	Verify Existing Account by Re-authentication	Reauthentication of existing account	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
9062ada5-f80c-40bc-8767-4ef5380c37e5	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	69219f75-5959-4178-a860-0ae90853470b	basic-flow	f	t
5266ac07-2edc-41d1-bb1e-8305d5cf149d	saml ecp	SAML ECP Profile Authentication Flow	69219f75-5959-4178-a860-0ae90853470b	basic-flow	t	t
46bbeac2-5dbb-4e92-9a3d-cbab842c8e48	docker auth	Used by Docker clients to authenticate against the IDP	69219f75-5959-4178-a860-0ae90853470b	basic-flow	t	t
7a292ea3-b8f6-4261-8809-f236fb8f6b59	Account verification options	Method with which to verity the existing account	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
289b2186-523b-4d52-a990-239e018d6cc8	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
0d5329d5-6efc-435b-b508-b7b4bf06f0c7	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
52b7c9ed-9b58-4e76-bb4d-7d73232cc525	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
918bf8f1-f023-41df-ba96-66c448ec830b	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
62ce1ce8-c933-4d59-a80b-99ecd915aa6e	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
a962c70d-d44b-427c-be61-59d0504c6f92	User creation or linking	Flow for the existing/non-existing user alternatives	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
c4ba9d25-dc0b-44d0-811c-b2b1de63e825	Verify Existing Account by Re-authentication	Reauthentication of existing account	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
e5bb4c58-afbf-446a-9b29-2bd461e788bd	browser	browser based authentication	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	t	t
bb432a90-61f9-4852-ae3b-3fb9819b95f5	clients	Base authentication for clients	2d41d0c8-a7ac-4cdc-b114-4baf577da237	client-flow	t	t
a9d873c2-73a1-4f1b-a565-7e1dcab6b1cc	direct grant	OpenID Connect Resource Owner Grant	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	t	t
4417fff2-662e-4178-8659-b359d6df1601	docker auth	Used by Docker clients to authenticate against the IDP	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	t	t
0264017a-1809-4eb3-882b-30d0cfacc88e	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	t	t
775be4a1-89a2-456d-a64c-2428fbe9e14a	forms	Username, password, otp and other auth forms.	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	f	t
0586966e-4ef5-4874-8286-509f5f6c93ee	registration	registration flow	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	t	t
2b26cc6e-97b3-44e7-8c1a-813bf3024855	registration form	registration form	2d41d0c8-a7ac-4cdc-b114-4baf577da237	form-flow	f	t
04b71a86-1a66-4cb2-8518-ae68209084da	reset credentials	Reset credentials for a user if they forgot their password or something	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	t	t
b4edc6fa-65f7-4636-a6b7-ae84b99f8e6e	saml ecp	SAML ECP Profile Authentication Flow	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	t	t
3990e788-e516-4bb8-864b-f98d040f0280	test	test	2d41d0c8-a7ac-4cdc-b114-4baf577da237	basic-flow	t	f
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
303f70ce-abac-415c-beb0-f89db870f49a	review profile config	69219f75-5959-4178-a860-0ae90853470b
3d5af636-0f3f-4530-af0e-22d24369884b	create unique user config	69219f75-5959-4178-a860-0ae90853470b
6e5382f1-8095-433b-8767-b77e7c73b86b	create unique user config	2d41d0c8-a7ac-4cdc-b114-4baf577da237
99be629a-eb3e-4cd8-8c2c-807795c7689b	review profile config	2d41d0c8-a7ac-4cdc-b114-4baf577da237
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
303f70ce-abac-415c-beb0-f89db870f49a	missing	update.profile.on.first.login
3d5af636-0f3f-4530-af0e-22d24369884b	false	require.password.update.after.registration
6e5382f1-8095-433b-8767-b77e7c73b86b	false	require.password.update.after.registration
99be629a-eb3e-4cd8-8c2c-807795c7689b	missing	update.profile.on.first.login
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	f	master-realm	0	f	\N	\N	t	\N	f	69219f75-5959-4178-a860-0ae90853470b	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	69219f75-5959-4178-a860-0ae90853470b	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
07482b6a-2476-4033-af31-9d6ac30697af	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	69219f75-5959-4178-a860-0ae90853470b	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	t	f	broker	0	f	\N	\N	t	\N	f	69219f75-5959-4178-a860-0ae90853470b	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
3cd83037-98f6-44da-be80-73f9e77a3d39	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	69219f75-5959-4178-a860-0ae90853470b	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
20c3b90a-d84b-40ff-acc7-49e94afecac4	t	f	admin-cli	0	t	\N	\N	f	\N	f	69219f75-5959-4178-a860-0ae90853470b	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	f	realm-management	0	f	\N	\N	t	\N	f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	t	f	admin-cli	0	t	\N	\N	f	\N	f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	f	aad-realm	0	f	\N	\N	t	\N	f	69219f75-5959-4178-a860-0ae90853470b	\N	0	f	f	azuread Realm	f	client-secret	\N	\N	\N	t	f	f	f
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	t	f	broker	0	f	\N	\N	t	\N	f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
701a3ada-3c87-42d9-bfc2-710bc231c878	t	f	security-admin-console	0	t	\N	/admin/aad/console/	f		f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}		\N	t	f	f	f
323975f7-f8df-44d0-96cf-877e7d6ab7b2	t	f	master-realm	0	f	\N	\N	t	\N	f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
512c74b9-7b68-42e2-962e-0d6507f71cd1	t	f	account	0	t	\N	/realms/aad/account/	f		f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}		\N	t	f	f	f
312930c6-3b4a-492f-9f52-bf0947d8c4e5	t	f	account-console	0	t	\N	/realms/aad/account/	f		f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}		\N	t	f	f	f
4042690c-33d1-4e1b-acf7-9ba58ce60da0	t	t	api-backend	0	f	Ln5052MOe9NY126L3ycTb26fokqAmvXe	http://localhost:3000	f		f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	-1	t	f		t	client-secret	http://localhost:3000		\N	t	f	f	f
b467a243-0187-4bb7-8dcb-05d03fe39aec	t	t	api-frontend	0	t	\N		f	http://localhost:3000	f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	-1	t	f		f	client-secret	http://localhost:3000		\N	t	f	t	f
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	t	t	hexagon-service	0	f	ag090VkaunAKKHNhKZt6iaCDp5WcMHHK		f		f	2d41d0c8-a7ac-4cdc-b114-4baf577da237	openid-connect	-1	t	f		t	client-secret			\N	t	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	post.logout.redirect.uris	+
07482b6a-2476-4033-af31-9d6ac30697af	post.logout.redirect.uris	+
07482b6a-2476-4033-af31-9d6ac30697af	pkce.code.challenge.method	S256
3cd83037-98f6-44da-be80-73f9e77a3d39	post.logout.redirect.uris	+
3cd83037-98f6-44da-be80-73f9e77a3d39	pkce.code.challenge.method	S256
512c74b9-7b68-42e2-962e-0d6507f71cd1	post.logout.redirect.uris	+
312930c6-3b4a-492f-9f52-bf0947d8c4e5	post.logout.redirect.uris	+
312930c6-3b4a-492f-9f52-bf0947d8c4e5	pkce.code.challenge.method	S256
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	post.logout.redirect.uris	+
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	post.logout.redirect.uris	+
323975f7-f8df-44d0-96cf-877e7d6ab7b2	post.logout.redirect.uris	+
701a3ada-3c87-42d9-bfc2-710bc231c878	post.logout.redirect.uris	+
701a3ada-3c87-42d9-bfc2-710bc231c878	pkce.code.challenge.method	S256
701a3ada-3c87-42d9-bfc2-710bc231c878	oauth2.device.authorization.grant.enabled	false
701a3ada-3c87-42d9-bfc2-710bc231c878	oidc.ciba.grant.enabled	false
701a3ada-3c87-42d9-bfc2-710bc231c878	display.on.consent.screen	false
701a3ada-3c87-42d9-bfc2-710bc231c878	backchannel.logout.session.required	true
701a3ada-3c87-42d9-bfc2-710bc231c878	backchannel.logout.revoke.offline.tokens	false
312930c6-3b4a-492f-9f52-bf0947d8c4e5	oauth2.device.authorization.grant.enabled	false
312930c6-3b4a-492f-9f52-bf0947d8c4e5	oidc.ciba.grant.enabled	false
312930c6-3b4a-492f-9f52-bf0947d8c4e5	display.on.consent.screen	false
312930c6-3b4a-492f-9f52-bf0947d8c4e5	backchannel.logout.session.required	true
312930c6-3b4a-492f-9f52-bf0947d8c4e5	backchannel.logout.revoke.offline.tokens	false
512c74b9-7b68-42e2-962e-0d6507f71cd1	oauth2.device.authorization.grant.enabled	false
512c74b9-7b68-42e2-962e-0d6507f71cd1	oidc.ciba.grant.enabled	false
512c74b9-7b68-42e2-962e-0d6507f71cd1	display.on.consent.screen	false
512c74b9-7b68-42e2-962e-0d6507f71cd1	backchannel.logout.session.required	true
512c74b9-7b68-42e2-962e-0d6507f71cd1	backchannel.logout.revoke.offline.tokens	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	oauth2.device.authorization.grant.enabled	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	oidc.ciba.grant.enabled	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	backchannel.logout.session.required	true
4042690c-33d1-4e1b-acf7-9ba58ce60da0	backchannel.logout.revoke.offline.tokens	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	display.on.consent.screen	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	use.refresh.tokens	true
4042690c-33d1-4e1b-acf7-9ba58ce60da0	client_credentials.use_refresh_token	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	token.response.type.bearer.lower-case	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	tls.client.certificate.bound.access.tokens	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	require.pushed.authorization.requests	false
4042690c-33d1-4e1b-acf7-9ba58ce60da0	acr.loa.map	{}
4042690c-33d1-4e1b-acf7-9ba58ce60da0	client.secret.creation.time	1697747365
4042690c-33d1-4e1b-acf7-9ba58ce60da0	post.logout.redirect.uris	http://localhost:3000/*
b467a243-0187-4bb7-8dcb-05d03fe39aec	oauth2.device.authorization.grant.enabled	false
b467a243-0187-4bb7-8dcb-05d03fe39aec	oidc.ciba.grant.enabled	false
b467a243-0187-4bb7-8dcb-05d03fe39aec	post.logout.redirect.uris	http://localhost:3000/*
b467a243-0187-4bb7-8dcb-05d03fe39aec	backchannel.logout.session.required	true
b467a243-0187-4bb7-8dcb-05d03fe39aec	backchannel.logout.revoke.offline.tokens	false
b467a243-0187-4bb7-8dcb-05d03fe39aec	display.on.consent.screen	false
b467a243-0187-4bb7-8dcb-05d03fe39aec	use.refresh.tokens	true
b467a243-0187-4bb7-8dcb-05d03fe39aec	client_credentials.use_refresh_token	false
b467a243-0187-4bb7-8dcb-05d03fe39aec	token.response.type.bearer.lower-case	false
b467a243-0187-4bb7-8dcb-05d03fe39aec	tls.client.certificate.bound.access.tokens	false
b467a243-0187-4bb7-8dcb-05d03fe39aec	require.pushed.authorization.requests	false
b467a243-0187-4bb7-8dcb-05d03fe39aec	acr.loa.map	{}
b467a243-0187-4bb7-8dcb-05d03fe39aec	pkce.code.challenge.method	S256
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	client.secret.creation.time	1702652206
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	oauth2.device.authorization.grant.enabled	false
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	oidc.ciba.grant.enabled	false
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	backchannel.logout.session.required	true
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	backchannel.logout.revoke.offline.tokens	false
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	display.on.consent.screen	false
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
17151962-3d4e-4a6b-9ec4-f935fb79eca2	offline_access	69219f75-5959-4178-a860-0ae90853470b	OpenID Connect built-in scope: offline_access	openid-connect
636ac67c-05ca-4257-991f-4a9d9c0db1e1	role_list	69219f75-5959-4178-a860-0ae90853470b	SAML role list	saml
dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	profile	69219f75-5959-4178-a860-0ae90853470b	OpenID Connect built-in scope: profile	openid-connect
04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	email	69219f75-5959-4178-a860-0ae90853470b	OpenID Connect built-in scope: email	openid-connect
1a972335-a90b-49d9-aabe-f8dd1b9a734e	address	69219f75-5959-4178-a860-0ae90853470b	OpenID Connect built-in scope: address	openid-connect
fae0d46e-48ab-4809-87dc-1342a6071211	phone	69219f75-5959-4178-a860-0ae90853470b	OpenID Connect built-in scope: phone	openid-connect
e3268633-89aa-4fcb-a1d6-8de6ee65235f	roles	69219f75-5959-4178-a860-0ae90853470b	OpenID Connect scope for add user roles to the access token	openid-connect
7c4783e6-472c-4b8d-806c-361ff26817de	web-origins	69219f75-5959-4178-a860-0ae90853470b	OpenID Connect scope for add allowed web origins to the access token	openid-connect
04c034a1-7b68-4c88-b61a-6131bdaae4b4	microprofile-jwt	69219f75-5959-4178-a860-0ae90853470b	Microprofile - JWT built-in scope	openid-connect
eaea2a29-24f4-43be-99da-e989a2c7e944	acr	69219f75-5959-4178-a860-0ae90853470b	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
5b4c2a93-e5a4-4693-950d-4a2af5b23063	role_list	2d41d0c8-a7ac-4cdc-b114-4baf577da237	SAML role list	saml
6e0e1856-372a-4825-8ece-b0349456e31c	profile	2d41d0c8-a7ac-4cdc-b114-4baf577da237	OpenID Connect built-in scope: profile	openid-connect
a575d33b-0fe5-4365-80a9-cb004b02a952	web-origins	2d41d0c8-a7ac-4cdc-b114-4baf577da237	OpenID Connect scope for add allowed web origins to the access token	openid-connect
bfc8242a-b171-4c61-b05c-bf815aec0868	email	2d41d0c8-a7ac-4cdc-b114-4baf577da237	OpenID Connect built-in scope: email	openid-connect
7a42d3d9-1b9b-4d01-b2bf-a061edee1908	microprofile-jwt	2d41d0c8-a7ac-4cdc-b114-4baf577da237	Microprofile - JWT built-in scope	openid-connect
a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	offline_access	2d41d0c8-a7ac-4cdc-b114-4baf577da237	OpenID Connect built-in scope: offline_access	openid-connect
be3bdfa6-3417-4740-8344-69553a472eb9	roles	2d41d0c8-a7ac-4cdc-b114-4baf577da237	OpenID Connect scope for add user roles to the access token	openid-connect
d117141b-f630-4483-b380-3f51dcfe9ced	acr	2d41d0c8-a7ac-4cdc-b114-4baf577da237	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
a534ad5a-f520-43c6-ada9-f749bcd71543	address	2d41d0c8-a7ac-4cdc-b114-4baf577da237	OpenID Connect built-in scope: address	openid-connect
c873130a-056f-4fac-b2c1-d8bc990e3c39	phone	2d41d0c8-a7ac-4cdc-b114-4baf577da237	OpenID Connect built-in scope: phone	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
17151962-3d4e-4a6b-9ec4-f935fb79eca2	true	display.on.consent.screen
17151962-3d4e-4a6b-9ec4-f935fb79eca2	${offlineAccessScopeConsentText}	consent.screen.text
636ac67c-05ca-4257-991f-4a9d9c0db1e1	true	display.on.consent.screen
636ac67c-05ca-4257-991f-4a9d9c0db1e1	${samlRoleListScopeConsentText}	consent.screen.text
dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	true	display.on.consent.screen
dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	${profileScopeConsentText}	consent.screen.text
dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	true	include.in.token.scope
04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	true	display.on.consent.screen
04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	${emailScopeConsentText}	consent.screen.text
04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	true	include.in.token.scope
1a972335-a90b-49d9-aabe-f8dd1b9a734e	true	display.on.consent.screen
1a972335-a90b-49d9-aabe-f8dd1b9a734e	${addressScopeConsentText}	consent.screen.text
1a972335-a90b-49d9-aabe-f8dd1b9a734e	true	include.in.token.scope
fae0d46e-48ab-4809-87dc-1342a6071211	true	display.on.consent.screen
fae0d46e-48ab-4809-87dc-1342a6071211	${phoneScopeConsentText}	consent.screen.text
fae0d46e-48ab-4809-87dc-1342a6071211	true	include.in.token.scope
e3268633-89aa-4fcb-a1d6-8de6ee65235f	true	display.on.consent.screen
e3268633-89aa-4fcb-a1d6-8de6ee65235f	${rolesScopeConsentText}	consent.screen.text
e3268633-89aa-4fcb-a1d6-8de6ee65235f	false	include.in.token.scope
7c4783e6-472c-4b8d-806c-361ff26817de	false	display.on.consent.screen
7c4783e6-472c-4b8d-806c-361ff26817de		consent.screen.text
7c4783e6-472c-4b8d-806c-361ff26817de	false	include.in.token.scope
04c034a1-7b68-4c88-b61a-6131bdaae4b4	false	display.on.consent.screen
04c034a1-7b68-4c88-b61a-6131bdaae4b4	true	include.in.token.scope
eaea2a29-24f4-43be-99da-e989a2c7e944	false	display.on.consent.screen
eaea2a29-24f4-43be-99da-e989a2c7e944	false	include.in.token.scope
5b4c2a93-e5a4-4693-950d-4a2af5b23063	${samlRoleListScopeConsentText}	consent.screen.text
5b4c2a93-e5a4-4693-950d-4a2af5b23063	true	display.on.consent.screen
6e0e1856-372a-4825-8ece-b0349456e31c	true	include.in.token.scope
6e0e1856-372a-4825-8ece-b0349456e31c	true	display.on.consent.screen
6e0e1856-372a-4825-8ece-b0349456e31c	${profileScopeConsentText}	consent.screen.text
a575d33b-0fe5-4365-80a9-cb004b02a952	false	include.in.token.scope
a575d33b-0fe5-4365-80a9-cb004b02a952	false	display.on.consent.screen
a575d33b-0fe5-4365-80a9-cb004b02a952		consent.screen.text
bfc8242a-b171-4c61-b05c-bf815aec0868	true	include.in.token.scope
bfc8242a-b171-4c61-b05c-bf815aec0868	true	display.on.consent.screen
bfc8242a-b171-4c61-b05c-bf815aec0868	${emailScopeConsentText}	consent.screen.text
7a42d3d9-1b9b-4d01-b2bf-a061edee1908	true	include.in.token.scope
7a42d3d9-1b9b-4d01-b2bf-a061edee1908	false	display.on.consent.screen
a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	${offlineAccessScopeConsentText}	consent.screen.text
a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	true	display.on.consent.screen
be3bdfa6-3417-4740-8344-69553a472eb9	false	include.in.token.scope
be3bdfa6-3417-4740-8344-69553a472eb9	true	display.on.consent.screen
be3bdfa6-3417-4740-8344-69553a472eb9	${rolesScopeConsentText}	consent.screen.text
d117141b-f630-4483-b380-3f51dcfe9ced	false	include.in.token.scope
d117141b-f630-4483-b380-3f51dcfe9ced	false	display.on.consent.screen
a534ad5a-f520-43c6-ada9-f749bcd71543	true	include.in.token.scope
a534ad5a-f520-43c6-ada9-f749bcd71543	true	display.on.consent.screen
a534ad5a-f520-43c6-ada9-f749bcd71543	${addressScopeConsentText}	consent.screen.text
c873130a-056f-4fac-b2c1-d8bc990e3c39	true	include.in.token.scope
c873130a-056f-4fac-b2c1-d8bc990e3c39	true	display.on.consent.screen
c873130a-056f-4fac-b2c1-d8bc990e3c39	${phoneScopeConsentText}	consent.screen.text
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	eaea2a29-24f4-43be-99da-e989a2c7e944	t
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	e3268633-89aa-4fcb-a1d6-8de6ee65235f	t
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	7c4783e6-472c-4b8d-806c-361ff26817de	t
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	t
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	t
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	fae0d46e-48ab-4809-87dc-1342a6071211	f
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	1a972335-a90b-49d9-aabe-f8dd1b9a734e	f
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	04c034a1-7b68-4c88-b61a-6131bdaae4b4	f
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	17151962-3d4e-4a6b-9ec4-f935fb79eca2	f
07482b6a-2476-4033-af31-9d6ac30697af	eaea2a29-24f4-43be-99da-e989a2c7e944	t
07482b6a-2476-4033-af31-9d6ac30697af	e3268633-89aa-4fcb-a1d6-8de6ee65235f	t
07482b6a-2476-4033-af31-9d6ac30697af	7c4783e6-472c-4b8d-806c-361ff26817de	t
07482b6a-2476-4033-af31-9d6ac30697af	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	t
07482b6a-2476-4033-af31-9d6ac30697af	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	t
07482b6a-2476-4033-af31-9d6ac30697af	fae0d46e-48ab-4809-87dc-1342a6071211	f
07482b6a-2476-4033-af31-9d6ac30697af	1a972335-a90b-49d9-aabe-f8dd1b9a734e	f
07482b6a-2476-4033-af31-9d6ac30697af	04c034a1-7b68-4c88-b61a-6131bdaae4b4	f
07482b6a-2476-4033-af31-9d6ac30697af	17151962-3d4e-4a6b-9ec4-f935fb79eca2	f
20c3b90a-d84b-40ff-acc7-49e94afecac4	eaea2a29-24f4-43be-99da-e989a2c7e944	t
20c3b90a-d84b-40ff-acc7-49e94afecac4	e3268633-89aa-4fcb-a1d6-8de6ee65235f	t
20c3b90a-d84b-40ff-acc7-49e94afecac4	7c4783e6-472c-4b8d-806c-361ff26817de	t
20c3b90a-d84b-40ff-acc7-49e94afecac4	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	t
20c3b90a-d84b-40ff-acc7-49e94afecac4	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	t
20c3b90a-d84b-40ff-acc7-49e94afecac4	fae0d46e-48ab-4809-87dc-1342a6071211	f
20c3b90a-d84b-40ff-acc7-49e94afecac4	1a972335-a90b-49d9-aabe-f8dd1b9a734e	f
20c3b90a-d84b-40ff-acc7-49e94afecac4	04c034a1-7b68-4c88-b61a-6131bdaae4b4	f
20c3b90a-d84b-40ff-acc7-49e94afecac4	17151962-3d4e-4a6b-9ec4-f935fb79eca2	f
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	eaea2a29-24f4-43be-99da-e989a2c7e944	t
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	e3268633-89aa-4fcb-a1d6-8de6ee65235f	t
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	7c4783e6-472c-4b8d-806c-361ff26817de	t
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	t
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	t
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	fae0d46e-48ab-4809-87dc-1342a6071211	f
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	1a972335-a90b-49d9-aabe-f8dd1b9a734e	f
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	04c034a1-7b68-4c88-b61a-6131bdaae4b4	f
ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	17151962-3d4e-4a6b-9ec4-f935fb79eca2	f
37acefbe-975b-430e-b49e-8cb54f9e6a7f	eaea2a29-24f4-43be-99da-e989a2c7e944	t
37acefbe-975b-430e-b49e-8cb54f9e6a7f	e3268633-89aa-4fcb-a1d6-8de6ee65235f	t
37acefbe-975b-430e-b49e-8cb54f9e6a7f	7c4783e6-472c-4b8d-806c-361ff26817de	t
37acefbe-975b-430e-b49e-8cb54f9e6a7f	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	t
37acefbe-975b-430e-b49e-8cb54f9e6a7f	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	t
37acefbe-975b-430e-b49e-8cb54f9e6a7f	fae0d46e-48ab-4809-87dc-1342a6071211	f
37acefbe-975b-430e-b49e-8cb54f9e6a7f	1a972335-a90b-49d9-aabe-f8dd1b9a734e	f
37acefbe-975b-430e-b49e-8cb54f9e6a7f	04c034a1-7b68-4c88-b61a-6131bdaae4b4	f
37acefbe-975b-430e-b49e-8cb54f9e6a7f	17151962-3d4e-4a6b-9ec4-f935fb79eca2	f
3cd83037-98f6-44da-be80-73f9e77a3d39	eaea2a29-24f4-43be-99da-e989a2c7e944	t
3cd83037-98f6-44da-be80-73f9e77a3d39	e3268633-89aa-4fcb-a1d6-8de6ee65235f	t
3cd83037-98f6-44da-be80-73f9e77a3d39	7c4783e6-472c-4b8d-806c-361ff26817de	t
3cd83037-98f6-44da-be80-73f9e77a3d39	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	t
3cd83037-98f6-44da-be80-73f9e77a3d39	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	t
3cd83037-98f6-44da-be80-73f9e77a3d39	fae0d46e-48ab-4809-87dc-1342a6071211	f
3cd83037-98f6-44da-be80-73f9e77a3d39	1a972335-a90b-49d9-aabe-f8dd1b9a734e	f
3cd83037-98f6-44da-be80-73f9e77a3d39	04c034a1-7b68-4c88-b61a-6131bdaae4b4	f
3cd83037-98f6-44da-be80-73f9e77a3d39	17151962-3d4e-4a6b-9ec4-f935fb79eca2	f
4042690c-33d1-4e1b-acf7-9ba58ce60da0	6e0e1856-372a-4825-8ece-b0349456e31c	t
4042690c-33d1-4e1b-acf7-9ba58ce60da0	a575d33b-0fe5-4365-80a9-cb004b02a952	t
4042690c-33d1-4e1b-acf7-9ba58ce60da0	bfc8242a-b171-4c61-b05c-bf815aec0868	t
4042690c-33d1-4e1b-acf7-9ba58ce60da0	be3bdfa6-3417-4740-8344-69553a472eb9	t
4042690c-33d1-4e1b-acf7-9ba58ce60da0	d117141b-f630-4483-b380-3f51dcfe9ced	t
4042690c-33d1-4e1b-acf7-9ba58ce60da0	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
4042690c-33d1-4e1b-acf7-9ba58ce60da0	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
4042690c-33d1-4e1b-acf7-9ba58ce60da0	a534ad5a-f520-43c6-ada9-f749bcd71543	f
4042690c-33d1-4e1b-acf7-9ba58ce60da0	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
512c74b9-7b68-42e2-962e-0d6507f71cd1	a575d33b-0fe5-4365-80a9-cb004b02a952	t
512c74b9-7b68-42e2-962e-0d6507f71cd1	d117141b-f630-4483-b380-3f51dcfe9ced	t
512c74b9-7b68-42e2-962e-0d6507f71cd1	6e0e1856-372a-4825-8ece-b0349456e31c	t
512c74b9-7b68-42e2-962e-0d6507f71cd1	be3bdfa6-3417-4740-8344-69553a472eb9	t
512c74b9-7b68-42e2-962e-0d6507f71cd1	bfc8242a-b171-4c61-b05c-bf815aec0868	t
512c74b9-7b68-42e2-962e-0d6507f71cd1	a534ad5a-f520-43c6-ada9-f749bcd71543	f
512c74b9-7b68-42e2-962e-0d6507f71cd1	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
512c74b9-7b68-42e2-962e-0d6507f71cd1	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
512c74b9-7b68-42e2-962e-0d6507f71cd1	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
312930c6-3b4a-492f-9f52-bf0947d8c4e5	a575d33b-0fe5-4365-80a9-cb004b02a952	t
312930c6-3b4a-492f-9f52-bf0947d8c4e5	d117141b-f630-4483-b380-3f51dcfe9ced	t
312930c6-3b4a-492f-9f52-bf0947d8c4e5	6e0e1856-372a-4825-8ece-b0349456e31c	t
312930c6-3b4a-492f-9f52-bf0947d8c4e5	be3bdfa6-3417-4740-8344-69553a472eb9	t
312930c6-3b4a-492f-9f52-bf0947d8c4e5	bfc8242a-b171-4c61-b05c-bf815aec0868	t
312930c6-3b4a-492f-9f52-bf0947d8c4e5	a534ad5a-f520-43c6-ada9-f749bcd71543	f
312930c6-3b4a-492f-9f52-bf0947d8c4e5	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
312930c6-3b4a-492f-9f52-bf0947d8c4e5	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
312930c6-3b4a-492f-9f52-bf0947d8c4e5	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	a575d33b-0fe5-4365-80a9-cb004b02a952	t
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	d117141b-f630-4483-b380-3f51dcfe9ced	t
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	6e0e1856-372a-4825-8ece-b0349456e31c	t
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	be3bdfa6-3417-4740-8344-69553a472eb9	t
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	bfc8242a-b171-4c61-b05c-bf815aec0868	t
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	a534ad5a-f520-43c6-ada9-f749bcd71543	f
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
558f155e-0612-4bc6-b0ad-b0afa86ef6c1	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	a575d33b-0fe5-4365-80a9-cb004b02a952	t
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	d117141b-f630-4483-b380-3f51dcfe9ced	t
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	6e0e1856-372a-4825-8ece-b0349456e31c	t
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	be3bdfa6-3417-4740-8344-69553a472eb9	t
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	bfc8242a-b171-4c61-b05c-bf815aec0868	t
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	a534ad5a-f520-43c6-ada9-f749bcd71543	f
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
98f9a6c7-dea8-43bc-a1ef-ebe2a079b8b3	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
323975f7-f8df-44d0-96cf-877e7d6ab7b2	a575d33b-0fe5-4365-80a9-cb004b02a952	t
323975f7-f8df-44d0-96cf-877e7d6ab7b2	d117141b-f630-4483-b380-3f51dcfe9ced	t
323975f7-f8df-44d0-96cf-877e7d6ab7b2	6e0e1856-372a-4825-8ece-b0349456e31c	t
323975f7-f8df-44d0-96cf-877e7d6ab7b2	be3bdfa6-3417-4740-8344-69553a472eb9	t
323975f7-f8df-44d0-96cf-877e7d6ab7b2	bfc8242a-b171-4c61-b05c-bf815aec0868	t
323975f7-f8df-44d0-96cf-877e7d6ab7b2	a534ad5a-f520-43c6-ada9-f749bcd71543	f
323975f7-f8df-44d0-96cf-877e7d6ab7b2	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
323975f7-f8df-44d0-96cf-877e7d6ab7b2	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
323975f7-f8df-44d0-96cf-877e7d6ab7b2	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
701a3ada-3c87-42d9-bfc2-710bc231c878	a575d33b-0fe5-4365-80a9-cb004b02a952	t
701a3ada-3c87-42d9-bfc2-710bc231c878	d117141b-f630-4483-b380-3f51dcfe9ced	t
701a3ada-3c87-42d9-bfc2-710bc231c878	6e0e1856-372a-4825-8ece-b0349456e31c	t
701a3ada-3c87-42d9-bfc2-710bc231c878	be3bdfa6-3417-4740-8344-69553a472eb9	t
701a3ada-3c87-42d9-bfc2-710bc231c878	bfc8242a-b171-4c61-b05c-bf815aec0868	t
701a3ada-3c87-42d9-bfc2-710bc231c878	a534ad5a-f520-43c6-ada9-f749bcd71543	f
701a3ada-3c87-42d9-bfc2-710bc231c878	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
701a3ada-3c87-42d9-bfc2-710bc231c878	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
701a3ada-3c87-42d9-bfc2-710bc231c878	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
b467a243-0187-4bb7-8dcb-05d03fe39aec	6e0e1856-372a-4825-8ece-b0349456e31c	t
b467a243-0187-4bb7-8dcb-05d03fe39aec	a575d33b-0fe5-4365-80a9-cb004b02a952	t
b467a243-0187-4bb7-8dcb-05d03fe39aec	bfc8242a-b171-4c61-b05c-bf815aec0868	t
b467a243-0187-4bb7-8dcb-05d03fe39aec	be3bdfa6-3417-4740-8344-69553a472eb9	t
b467a243-0187-4bb7-8dcb-05d03fe39aec	d117141b-f630-4483-b380-3f51dcfe9ced	t
b467a243-0187-4bb7-8dcb-05d03fe39aec	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
b467a243-0187-4bb7-8dcb-05d03fe39aec	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
b467a243-0187-4bb7-8dcb-05d03fe39aec	a534ad5a-f520-43c6-ada9-f749bcd71543	f
b467a243-0187-4bb7-8dcb-05d03fe39aec	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	6e0e1856-372a-4825-8ece-b0349456e31c	t
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	a575d33b-0fe5-4365-80a9-cb004b02a952	t
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	bfc8242a-b171-4c61-b05c-bf815aec0868	t
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	be3bdfa6-3417-4740-8344-69553a472eb9	t
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	d117141b-f630-4483-b380-3f51dcfe9ced	t
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	a534ad5a-f520-43c6-ada9-f749bcd71543	f
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
17151962-3d4e-4a6b-9ec4-f935fb79eca2	ccb0aba5-5ea0-49da-8f80-aaacc9106f70
a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	dd6312a7-ac03-4032-beea-01f3c6c97ac7
\.


--
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
b3667e9c-4c92-47cb-98e4-28d5a79f175e	Trusted Hosts	69219f75-5959-4178-a860-0ae90853470b	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	69219f75-5959-4178-a860-0ae90853470b	anonymous
0de68d33-6315-4bf2-ad4f-d493a2a37465	Consent Required	69219f75-5959-4178-a860-0ae90853470b	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	69219f75-5959-4178-a860-0ae90853470b	anonymous
fc73b339-5fe4-4633-ab3f-216dd27193f9	Full Scope Disabled	69219f75-5959-4178-a860-0ae90853470b	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	69219f75-5959-4178-a860-0ae90853470b	anonymous
2e8d4ece-2e67-4c6b-ab69-54b363022c26	Max Clients Limit	69219f75-5959-4178-a860-0ae90853470b	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	69219f75-5959-4178-a860-0ae90853470b	anonymous
492b405d-c908-4501-a917-53344cd2da3b	Allowed Protocol Mapper Types	69219f75-5959-4178-a860-0ae90853470b	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	69219f75-5959-4178-a860-0ae90853470b	anonymous
a4a79d9f-02be-443a-af68-84ca17ea600a	Allowed Client Scopes	69219f75-5959-4178-a860-0ae90853470b	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	69219f75-5959-4178-a860-0ae90853470b	anonymous
ca8b34ee-a2b2-486d-914f-431e5c7db392	Allowed Protocol Mapper Types	69219f75-5959-4178-a860-0ae90853470b	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	69219f75-5959-4178-a860-0ae90853470b	authenticated
15c0523c-98c2-469c-ac85-2a9ba494bf93	Allowed Client Scopes	69219f75-5959-4178-a860-0ae90853470b	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	69219f75-5959-4178-a860-0ae90853470b	authenticated
37167676-2b47-4ed0-9582-02b27415489a	rsa-generated	69219f75-5959-4178-a860-0ae90853470b	rsa-generated	org.keycloak.keys.KeyProvider	69219f75-5959-4178-a860-0ae90853470b	\N
777fe743-2339-4fd4-805c-66d8631dd462	rsa-enc-generated	69219f75-5959-4178-a860-0ae90853470b	rsa-enc-generated	org.keycloak.keys.KeyProvider	69219f75-5959-4178-a860-0ae90853470b	\N
c2d6f82f-80e2-4c20-afa9-cfb9505f155f	hmac-generated	69219f75-5959-4178-a860-0ae90853470b	hmac-generated	org.keycloak.keys.KeyProvider	69219f75-5959-4178-a860-0ae90853470b	\N
3ebf5bf6-cefc-4c2b-b903-401f90e18755	aes-generated	69219f75-5959-4178-a860-0ae90853470b	aes-generated	org.keycloak.keys.KeyProvider	69219f75-5959-4178-a860-0ae90853470b	\N
897b16b3-2312-46f8-9ade-19fc26b3cc5a	Allowed Client Scopes	2d41d0c8-a7ac-4cdc-b114-4baf577da237	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	anonymous
50e3dc22-efd8-4c9f-a16d-10954d1abaa6	Full Scope Disabled	2d41d0c8-a7ac-4cdc-b114-4baf577da237	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	anonymous
b53d42c8-4433-4011-8ac3-36aae072045b	Trusted Hosts	2d41d0c8-a7ac-4cdc-b114-4baf577da237	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	anonymous
98363e6d-163e-4226-a6da-70095dec3968	Allowed Protocol Mapper Types	2d41d0c8-a7ac-4cdc-b114-4baf577da237	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	anonymous
da4d071d-ba2d-4724-9608-59b75cf2899d	Consent Required	2d41d0c8-a7ac-4cdc-b114-4baf577da237	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	anonymous
37f2bb16-81f7-4c1e-9b5f-16ba1e108362	Allowed Protocol Mapper Types	2d41d0c8-a7ac-4cdc-b114-4baf577da237	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	authenticated
ee845089-51c3-40b9-9a22-20192c4a69f8	Max Clients Limit	2d41d0c8-a7ac-4cdc-b114-4baf577da237	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	anonymous
dc54cc73-f8c6-4a2a-844e-a2bf30479b33	Allowed Client Scopes	2d41d0c8-a7ac-4cdc-b114-4baf577da237	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	authenticated
5bc91821-f94f-4c8a-9331-a29c5d722551	rsa-enc-generated	2d41d0c8-a7ac-4cdc-b114-4baf577da237	rsa-enc-generated	org.keycloak.keys.KeyProvider	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N
96a7cff1-2c6b-4729-9bb5-f4a4b8eeaadd	hmac-generated	2d41d0c8-a7ac-4cdc-b114-4baf577da237	hmac-generated	org.keycloak.keys.KeyProvider	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N
8012a3ab-1505-4b30-87b6-ff133e958e21	aes-generated	2d41d0c8-a7ac-4cdc-b114-4baf577da237	aes-generated	org.keycloak.keys.KeyProvider	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N
49cb8a98-12d5-479c-ae8b-0dd86e4a2381	rsa-generated	2d41d0c8-a7ac-4cdc-b114-4baf577da237	rsa-generated	org.keycloak.keys.KeyProvider	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
f45eca7a-7cb7-44dd-931c-fe64f01dff36	15c0523c-98c2-469c-ac85-2a9ba494bf93	allow-default-scopes	true
4713f1ac-48d0-472b-9e86-bb87c7b760f7	b3667e9c-4c92-47cb-98e4-28d5a79f175e	host-sending-registration-request-must-match	true
7c491775-986f-4d5f-b47b-10a5d17712ff	b3667e9c-4c92-47cb-98e4-28d5a79f175e	client-uris-must-match	true
802d795a-57ab-4ad2-a808-8fe134581c17	ca8b34ee-a2b2-486d-914f-431e5c7db392	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
403ba27a-d2d5-49c4-b220-f182e4772ab2	ca8b34ee-a2b2-486d-914f-431e5c7db392	allowed-protocol-mapper-types	oidc-full-name-mapper
f015617d-d7e2-4e43-aa65-4f018b7998bd	ca8b34ee-a2b2-486d-914f-431e5c7db392	allowed-protocol-mapper-types	saml-role-list-mapper
0de94ed6-2567-4df4-aa40-ef992f3386e2	ca8b34ee-a2b2-486d-914f-431e5c7db392	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
b5b24da3-e3e9-40ea-95d1-31926a9d6fa5	ca8b34ee-a2b2-486d-914f-431e5c7db392	allowed-protocol-mapper-types	saml-user-property-mapper
1eeff1b9-8cd0-4e67-9ca6-80c5badfc524	ca8b34ee-a2b2-486d-914f-431e5c7db392	allowed-protocol-mapper-types	saml-user-attribute-mapper
eb8cf709-43cc-42f6-b19e-4110e6bde5d8	ca8b34ee-a2b2-486d-914f-431e5c7db392	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
258b65ce-b7aa-4ecd-b1dd-54aa36317561	ca8b34ee-a2b2-486d-914f-431e5c7db392	allowed-protocol-mapper-types	oidc-address-mapper
8ba02b0a-8e08-4ecc-ac8c-a1c41ce05d8f	a4a79d9f-02be-443a-af68-84ca17ea600a	allow-default-scopes	true
2f71cea9-f660-41e0-9b9e-e8c3d133dd9b	2e8d4ece-2e67-4c6b-ab69-54b363022c26	max-clients	200
707e5189-af94-4336-933b-325464796ab8	492b405d-c908-4501-a917-53344cd2da3b	allowed-protocol-mapper-types	saml-user-attribute-mapper
32bdd23d-8107-4658-829a-9b785d1facbc	492b405d-c908-4501-a917-53344cd2da3b	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
31a1aec3-2c11-42fa-ae31-b863d8a53b23	492b405d-c908-4501-a917-53344cd2da3b	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
6b224e2d-57dd-4b51-939e-529d9fc96f45	492b405d-c908-4501-a917-53344cd2da3b	allowed-protocol-mapper-types	oidc-address-mapper
00007e20-d244-4d2c-9332-c03d0b963074	492b405d-c908-4501-a917-53344cd2da3b	allowed-protocol-mapper-types	oidc-full-name-mapper
ec92d749-a011-4055-bb37-9255e524029f	492b405d-c908-4501-a917-53344cd2da3b	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
3e6984b1-0c5f-4492-84cc-4d2bdf9ad42e	492b405d-c908-4501-a917-53344cd2da3b	allowed-protocol-mapper-types	saml-user-property-mapper
1851e0d9-10ec-4c42-8422-b48e85b54993	492b405d-c908-4501-a917-53344cd2da3b	allowed-protocol-mapper-types	saml-role-list-mapper
bf32a8ad-d926-4a9f-9272-54bfae79b399	777fe743-2339-4fd4-805c-66d8631dd462	algorithm	RSA-OAEP
331de14f-651f-4ff1-9957-562dc8e78da9	777fe743-2339-4fd4-805c-66d8631dd462	priority	100
610cbd4c-88ed-4a71-9a67-9e86ef0de367	777fe743-2339-4fd4-805c-66d8631dd462	privateKey	MIIEpAIBAAKCAQEAyBV7xksw/t5spYYCVeZuxvMY81bK8vK+XjbW95+MX83ik5NUhWR+0+KNWjxML75/eB7u0U1rR0IgF2GaW34x32RJNFaW9d80TsiYJCqc2NAGl47DU8MmODb1paTsqsxx3dYMJpMyxen8OMjcgwGOZipbi/z4AYHdP+SZoalWNIHgdbW2iaQljDbjkZlELwNbtR5Xr+iTEeuo2FajcV5aKEebFrX2yuKpXRn/8ey1KKIl/pqZcWVem5aRyjsTnKRWPbnybwp3QxAuY5+n22s2EBtHyeA3sQ1EgrombiGP8EEJ1NAYdlexDsidI8yRFduJNIt9nY1DgrAJkaUZXU/2rwIDAQABAoIBAE9h4qkyNN6xvZZQXEXbdlD9qwUEhuGr+GZlyJUXGnj6NO5LEkoYLI+BP4axDKMWp/kvAJ5O4oSzkgrkwPqSz1OrtLWMszkalOS7Bk23EGKe6jagQBPQBa5g88YD8Jf1JCoY3dpCJW9LXbPj0UUyzV3waUDZnUXv0amjV2bByf9rYkLomAKcCEepjN0h7bDW544RCuQxOnZ6H2lAw1hqnc9Wr+0Hpe+TKpODsW2Xex51fccSu2ZtMAeZWbGxuZkJk6soQ7S2e+WnE9PSYf+leml4ycI5hsQ8JbEDZenbEpeIAw+z7A7Nvh6PFKtJiWdXH6nxszeeUjxO3fJUrIhBnr0CgYEA6jXSBYOBv0WmtvX4b+cb7Ts6KyfQNgJ/wRWhXm5LPSKTHjBgVsjUg3jNcmp8+lqBr3ASj+EX55Lxd0A6HafPZivfg6G5rIHCP4J6XA2VMArk+uN1lynJ+5ZHZrN3xWkkkZET9LwJfKectzZN1igKf4VWM5THITLXYLC6MfZM9hMCgYEA2rLgoBoxv/eN1KuXCNvMblp1U+0p8jqLWSnLaU0TD9lt8RDQAYlEw9FxLI/evdVSpg5gUMuA1G+fAF57bVimSE23Dxkk+SBfp8aQwe0Z1Zwv8VsN6ot/TeThisMnu0BXEd5OTLUxUsxcyL8nnpb0H15fUEDofx67CWcbWHW+gHUCgYEAimKAlLduO1jpN6PARkZUruhW51bf5Hm3iJvCPCyJEjdSm/zTf5OsVX5UTe1zqO0/QSzEGvVSDYc6W068x/b2SZVUvM8bCT2mS6ZJrAhuhPN69m7ddRLBAIF78MfL1f3ZGJWTKADOzjOvGmXguc/w3AYpt9KJkikbL0tcyNaSBLcCgYEAkQHWCpITtpMvyXlUlZ0XeXwlG1a/X0sOJjqeEt3166ZhTVu2b65Sl/wBLGjgacJOIKibmDa23yR7qsT61c/XwU02OZ6Uc1LR2e7BALRzUr1S1JdpLMD90eoW2ej4KSJKGSDrjdT+NUYnpzuHy5GPoFT0ocPH5LG9lkh1SzwW6hkCgYAXFMGtJFZ+2D6zkr5xxkZfxnIY2AtVHKTsJDrTZTwjHqM6CwV2mHrrtUGy9oPBNcNClX+3yBvWXqgviUwPN67/296YDLpF2et4d6IX3yQJNBUyBQzfyn19f7sUA7/F5komcBdonKMzzkORrwxGrAMdYSzB0fa1XEcmmiyMxRn8IQ==
4d7a4914-80f2-47fe-94e7-90ada5c547a2	777fe743-2339-4fd4-805c-66d8631dd462	keyUse	ENC
083f2bfb-50bd-4262-8db2-9507b3a27651	777fe743-2339-4fd4-805c-66d8631dd462	certificate	MIICmzCCAYMCBgGLQpXjwzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjMxMDE4MTEzODIxWhcNMzMxMDE4MTE0MDAxWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDIFXvGSzD+3mylhgJV5m7G8xjzVsry8r5eNtb3n4xfzeKTk1SFZH7T4o1aPEwvvn94Hu7RTWtHQiAXYZpbfjHfZEk0Vpb13zROyJgkKpzY0AaXjsNTwyY4NvWlpOyqzHHd1gwmkzLF6fw4yNyDAY5mKluL/PgBgd0/5JmhqVY0geB1tbaJpCWMNuORmUQvA1u1Hlev6JMR66jYVqNxXlooR5sWtfbK4qldGf/x7LUooiX+mplxZV6blpHKOxOcpFY9ufJvCndDEC5jn6fbazYQG0fJ4DexDUSCuiZuIY/wQQnU0Bh2V7EOyJ0jzJEV24k0i32djUOCsAmRpRldT/avAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAGO6nKxx0dJzlp2Jnu3J/JErHFxbdRWBsJgd9MtNyhedsKJhyCekdj1apuTJhLQXL+PhLsR0K6QRuf7C+EgvhIahnakPodG3dX2FKeeLwJMQ8MJYNY/QsD8zU3ySqVylDswiHAr+A8zxhr1La4iD1iufNGQDzxoPeiK7fKkGuTnQ5b/tEdYFuQgF5VQl+w1uAfPS0UI8CVUO5a5JF1HyLdnDUdemwJsh2EIDayJNyX3WdAYdHXRPTOyxEwUId5UU2QDGc6vzuRgtZo/z3Y1KK6eSW+Im14ItPIq0Y//d41JPFI0nwn56aPDnqmZlI92r/uFJOmZbu9E5TF0LHWN2XPM=
48344144-a3e0-49cb-b113-abd7dbed8bbc	c2d6f82f-80e2-4c20-afa9-cfb9505f155f	priority	100
63c1d780-89f0-42fe-a3bd-77c94c4d4494	c2d6f82f-80e2-4c20-afa9-cfb9505f155f	algorithm	HS256
e0eb6b22-04ab-4890-a837-f3eebebed390	c2d6f82f-80e2-4c20-afa9-cfb9505f155f	kid	a4e5424e-446e-4fad-82da-b5624cd10db5
bf4421e6-e8dc-4e0f-b894-38f9af874038	c2d6f82f-80e2-4c20-afa9-cfb9505f155f	secret	RhbPhljL7O2fmO3LeCuvGP5XtdxI_HSbdXKtad5mj785LxWyncO0oGz-wt5P7iH-N4WrB1ohG35IjmkQhbqWww
c86073d1-38aa-4b3a-979e-dfe38902c328	3ebf5bf6-cefc-4c2b-b903-401f90e18755	priority	100
aefd72cd-3239-42d6-8fbf-f5c9b4a17670	3ebf5bf6-cefc-4c2b-b903-401f90e18755	kid	ec9557a8-50b9-4214-8afe-94340fbb84fb
a2bf8ea6-858e-4ed9-b92f-8c7abeddfe88	3ebf5bf6-cefc-4c2b-b903-401f90e18755	secret	nRfjmzT8YE46JDQVssCRVg
ce558466-fc21-4422-825e-7375fba00302	37167676-2b47-4ed0-9582-02b27415489a	keyUse	SIG
fe32ffc4-188c-4a3e-b3b2-ba6fefe867a6	37167676-2b47-4ed0-9582-02b27415489a	privateKey	MIIEogIBAAKCAQEAzgjf7MgwquEudy+SaJ3b6MBK+imz9Ojj0BriAIR1EUKtfTBv68QfDbxZ6Isj/NvrGpiPHlSf+o2gbM7viybv0KHbRHs6x1sxAUa6Cz5oG1LgpakYCyQqe6nDvq93iEyCAHZ7RpvOWWNO0RIOZ8KetL4FpL8bC69fczCCWrK0GwuzW97u7hDECOoWXdOp1n/BQfa0WKLCjY87KD/JQ6UvuvuwaK5snNzOXp/27TXsPyy2bqf2vrGvfEMpVOvxPNawo8NwoW85b7DOqTDFKvchoz2vxwrcSwVe68SJq07k4uTwgg67Bs/5W4r8NHUWsEi0Mhst45Z4SAOsMUmg/ETjTwIDAQABAoIBAB3AulV/M0f57LPZctMYuMELw8gMbahYWU2cFDbu6djsQBFsBT2OvM1G/dTPAwto1rKohUJkBhYwjZIo7/6wSMFgHkHtabeQO6trg0JMaMxJU5eYq5gwSNJC2bmXrTNJmRxn/7Vampnd9WvLp7jkKfb/2eDImCc/1BDWWHywgcHF1G1NE4VlApRBxthRuAI/1xwYODviTP1f2OviKrIg3taC3zI1FGjekydDDebCU8GoIN5FodfIMHr4jf+kVn+kGHtBiMI9db3NXQHGRHXGKLNqEGOSnSbX5JCEobzzwL5QAKIKAkcEIi1igE8LpgSFsicv/Yx+d8dhodHY5lbrUYECgYEA7EntJ0xHWx7ljjkSdk22qHBCi1DyNpAlPepBXAbA8jImLWTYYXpLiRww5zVp6ucKMbgyBcNDluUhkcLSv1/RgcxfCyPdeb6yE/4yDQdWOtt6XZpDilxRwEsf2Z4ng/G3S+GK5PR/5bSXLmrLG+i18qoOsip3634ALZRtDeqTlYcCgYEA3zjbCSJQOiM+4ClIqH+za5fxgCC5Ld1494POpBZGrP8odGD9CGCX3r6yAWL2WfXI3GXI0aybGZY81QXPBS1zU6WQ3bTMnB0cTMK11zD5cy5C5L2vR7jl8susoii0URbPwSLuntywV490aEE5v3tM5Rrs+jH6S7YRGGDYdTYAtfkCgYAdQSHdhbIn8/FT5HkGsKR2wj9a5FC4tKwHuGMTM7rbwZ28bQnlN7D2bskXNyO/847tjPKUiBJsMj4vv8E79G8J9PWneW9ITXXax9QGjOv+KYJC6ICINtngRuzQkqYtzdV1zZzWr/bNx8gX9RzkfbFZM/jR0jQ6scTv37qIyIwxLQKBgH0PUIAMjmAUEQzrdD6a1P2pse6z5quQkk4xtVru9AfGKHcTQ5Am9c8gjYADXrvF3RPFnr4B8x9hsZEzYOmorh0l/ESKH7wy/wDucYwvbwId3/JhZ0tKhuIBRCXRojxwCFNPa9rrD4zu3SvvpxflT45oCG6gA3fZeDhtQbhhWgKZAoGAVqRv6qDw8JqieB5I7kg+O3lrraP2122RSGp3NS5ThypsMLuyF5jqe8MZMF7bv9cBKkRLgnUxlw0Maq5kIvHaowFIpmbf7c9rRXB1T+tbL1PmLhiz+tNjqYGVsLxL5SApP37b43Ua27vn+9KYq+tF3l08SWyeSx7CerDUp9+5ng0=
9495a9c0-7d4e-4fc0-8315-12725de96d7c	37167676-2b47-4ed0-9582-02b27415489a	certificate	MIICmzCCAYMCBgGLQpXibDANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjMxMDE4MTEzODIxWhcNMzMxMDE4MTE0MDAxWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDOCN/syDCq4S53L5JondvowEr6KbP06OPQGuIAhHURQq19MG/rxB8NvFnoiyP82+samI8eVJ/6jaBszu+LJu/QodtEezrHWzEBRroLPmgbUuClqRgLJCp7qcO+r3eITIIAdntGm85ZY07REg5nwp60vgWkvxsLr19zMIJasrQbC7Nb3u7uEMQI6hZd06nWf8FB9rRYosKNjzsoP8lDpS+6+7Bormyc3M5en/btNew/LLZup/a+sa98QylU6/E81rCjw3ChbzlvsM6pMMUq9yGjPa/HCtxLBV7rxImrTuTi5PCCDrsGz/lbivw0dRawSLQyGy3jlnhIA6wxSaD8RONPAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAIA4kuNiaqeqgeJrFNd/m0ZTNf45OGIRwT43sz1b7Z22p3hu/fUZilMjM3l5e+6mhmWE3YoVHE0dBvibADuPRGiZ/01ho3bxVWm3y4E+7vRPREmgNzMhwvAASteN7hCOkBnuvz3cZ/m+WQn1eHmfySbziaHE56fRRBQutNoobo1p7pCz4ieXbQeyC+y5lehe2od69BoFj7K4W4zhLPKHcwJQp3gSwOqyhBKTIZhXzyrxR6ltP1wL9dq3F7v9u/gpZlFhSwjjWFPHbnf7CfFV/vHB84chH4YI6Dae9YFm+3TYhxVIKlRVvDlgtGVPZAujKLQIzMrXww4eeLQEoX5bQ+o=
034a8264-ad97-44ea-9382-457e9465210e	37167676-2b47-4ed0-9582-02b27415489a	priority	100
1749d46d-edf8-4a43-b20c-2485017cbb27	897b16b3-2312-46f8-9ade-19fc26b3cc5a	allow-default-scopes	true
ae554c71-2b14-47f2-88eb-8b2e662de01f	5bc91821-f94f-4c8a-9331-a29c5d722551	certificate	MIICnTCCAYUCBgGLQpfrEzANBgkqhkiG9w0BAQsFADASMRAwDgYDVQQDDAdhenVyZWFkMB4XDTIzMTAxODExNDAzNFoXDTMzMTAxODExNDIxNFowEjEQMA4GA1UEAwwHYXp1cmVhZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJ9XJNRGMwsESWHsx4Xh8zMKQTxrvZL3K5+hq4Kk2F/aIEiFrJlvLcw5RSG0iWikRVJ1toivP9lnnCUzdXGfYLf9wBdCQuE0gYayjYAPTP1xf/W7VUwqcyLtYrlYQnsFasfGR2y8Pf0z0omxnjljr5zwgn8G31U9NVKOYzomsJYMtZaqq36NqF/1zbHnAF+m7x/nVIbRTS4Uvs3EaL5hAVVe10Is7sHNwUJQmFeAIBDci3AadCKLiHItB1lYxMC6nxEPU/Ed7SGowXQLlssaO+Zygx9M8V7gJpI07cHPCwp7/LnpmBSvVYB/PKsDpE8u3XldgFFHwB/x5jQ75hEYtlECAwEAATANBgkqhkiG9w0BAQsFAAOCAQEANTjmfi2FTDj5zBqvH29JqxL/wyBmKmMthyE0K+w0bJQX3c5tMRuV8tnsjjLlXkk8qvQP88AGSfy3Nz8ej4i5gwUTuckJzyk62O61Z/28MbgiQrESQUPPWQZR+6hHBZuDdO6NDaUCNrTxOEKkiFkwZUdoCWlwUCN1NQlU++772x5bQFEOPGMoOX8lBbgfXCTSJ6Pc3f0xzl6/PMZnT/oLr4SM7A8FVoUYW1SkwfWiFMn+Q1AApTptGFAnlVBTxVL8RZOnGOyO/WHGUauZIq8UQRZD7rD0gQf9IuhyeFQdPVOvucvMuKUkrNl/OtZcVyLlAl9h929fu7LI0jC22EsK+w==
0ec8d910-74ab-4710-9474-539c84d8f4ac	5bc91821-f94f-4c8a-9331-a29c5d722551	algorithm	RSA-OAEP
99a9f56f-757f-4196-8b1e-9718503565e5	5bc91821-f94f-4c8a-9331-a29c5d722551	priority	100
26d103e5-e670-40ff-a15f-be991f1acb6d	5bc91821-f94f-4c8a-9331-a29c5d722551	privateKey	MIIEpAIBAAKCAQEAn1ck1EYzCwRJYezHheHzMwpBPGu9kvcrn6GrgqTYX9ogSIWsmW8tzDlFIbSJaKRFUnW2iK8/2WecJTN1cZ9gt/3AF0JC4TSBhrKNgA9M/XF/9btVTCpzIu1iuVhCewVqx8ZHbLw9/TPSibGeOWOvnPCCfwbfVT01Uo5jOiawlgy1lqqrfo2oX/XNsecAX6bvH+dUhtFNLhS+zcRovmEBVV7XQizuwc3BQlCYV4AgENyLcBp0IouIci0HWVjEwLqfEQ9T8R3tIajBdAuWyxo75nKDH0zxXuAmkjTtwc8LCnv8uemYFK9VgH88qwOkTy7deV2AUUfAH/HmNDvmERi2UQIDAQABAoIBAD4ymA+8b0RHohV1hdS/BF3SDPD25YMutHqVcwuGKWgRDzT/6QXjni7v1Ap6HIEaTm0Hwf7M2dGVXiAvXBLEMc7gYFEz7kNWaZEYtZ9dWaI84cQcIgmfMF5b54ON7jVzQeFFhq/tMw1ZYz+Yc7jXLr/GKkpHdnohcGUPa7BRVfDb2qEo9nGLQFqCUPV3n7LUBtBjy5R98M7Jpvp51fhum+f/NHaHQHADTWxZrE429IfdYITozrOJmmSoGcI8D+bGCI6efkcoqI8PvTaYy3CLc6zAAn8gjEgJrrCejJG5R1nQCRgUP//WsK5lHAnnd8LzQpoYUb/uw0/aUhM/1tYDUFkCgYEA4GMppNVTJeY4MyCziMlTthsCuBvOtaoOP+N2ZtJ8Hx/9l7P4pWb6lr1nH26jHrO8cL9v/zviE7OBUxITZCXMS4akqiD7EAmPJS4Aofx+bSucfaWMQI0g+csC666u2mP7GbwMo2pYJdLXamsPRGm8me1Adq3khxSDaMCWZ+7iE0MCgYEAtcn5UIcly8876vxj/VYz539knw6XBfIyv8yyHQmwcYDSYho5vZ+3RaloHWLqoKCnYCLVNenNFO9R6ru8FFfdTRHSRGe7wQRnOOZ+237xle2I6io/EMLL78WukFT+WwJfy1qYSWJSsqjasVYntssOvQTovhAE0vJbjrVLINl7FNsCgYEAmmzEaTODIM8bGFzGEjp0SRy3t1sz3KRnYCK8BrGPSKBsl239jl+b0AgTo3cx/dw2sOWfP2nIAkUEmNYU0FSPD99fDdLa1kOt5ymMt+6cV6eu8G3xYy99ZUwI+4hhv90VH7XigMicV5OOOyfo/u1CJjE4rzSn1SsR8RKxsF+f6R8CgYBfX3J0pCLZNYUa+IVA8QvUJUrWA+KJ1RJ4+9xqTZ4LPmmh3F50tKmDW6hq2m18Di0hy8SOP3Y/yHryqsG27o4FFBd7meywDC5XdN4TLBt07CULrVRe58P0rIKz6FN1zd4SIxqITZRTdTEfHrNBPHEkC8JLjL3rKgmM6mJa/p6LRwKBgQDFU+hYz0FF8q23R9XPzC37nrXFNN+aDAglj7pI+h1QWThSCQNySvwx5uR8U03P0eeil88m1uRuYlaBlyS97PHzjnYukUrSBXk0bFNUTli0lmvEe+I8ryVHM1jNVtovV+S/dpEZ5nARxacgJtr8QeibOQHygfWquudATpPoSt2TFw==
272d7f2b-7771-41bd-9203-d19dfc69285f	96a7cff1-2c6b-4729-9bb5-f4a4b8eeaadd	kid	73c94e26-0ec6-4173-bcf8-8991cba55f4d
eab6af34-870d-4b09-8fa8-dc4c1c8ab191	96a7cff1-2c6b-4729-9bb5-f4a4b8eeaadd	secret	hB3yAGPMYPm4hmIQfHps2GWdIevhBqoJ3cDwA8UrcEQbcj456q91Ffqlv-ootO4eWSVKynOrfOaPTkpp6l2hLg
d12b77db-364e-4e00-a274-38b3cdbb9534	96a7cff1-2c6b-4729-9bb5-f4a4b8eeaadd	priority	100
6c6a6cbe-9cab-4a8b-90b3-3eff09979546	96a7cff1-2c6b-4729-9bb5-f4a4b8eeaadd	algorithm	HS256
48631623-7317-4df6-ba75-59f40d3c88e7	8012a3ab-1505-4b30-87b6-ff133e958e21	priority	100
d4196d00-104e-4f46-9946-11d6bce12d68	8012a3ab-1505-4b30-87b6-ff133e958e21	secret	-u01Y6_uuMtbrzFeY9qAXw
9dd8d3e3-cabd-4e28-80ad-06a9edfc7db0	8012a3ab-1505-4b30-87b6-ff133e958e21	kid	137e07c9-a71b-49f6-9224-2834fedc46ab
25ea07ab-858f-4fb7-ad49-9a1737a59a6d	49cb8a98-12d5-479c-ae8b-0dd86e4a2381	certificate	MIICnTCCAYUCBgGLQpfrsTANBgkqhkiG9w0BAQsFADASMRAwDgYDVQQDDAdhenVyZWFkMB4XDTIzMTAxODExNDAzNFoXDTMzMTAxODExNDIxNFowEjEQMA4GA1UEAwwHYXp1cmVhZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMn4iTUl2M1GpBQaSqtGsD8/vXHynHpb3APozshK70a1oNsh6x+RoR41Dh2m05GeEr6de6Hr3yNLo8KrC9YTyYw+QM1hJcMUOk1m/KTrtT+J7NF0gSBI19IX/EmPIOgsjnS8TXlfbiydX/sWjIO802GiW1LPY7ciLUoAgNwkjx/nD9jU0CTgi8LlmSlD1ZuFRZpUY9xdS9fEyWhcWsUIaPUQD1aaHBon2RbmbujffxNSWzAdrK6p5BgC9dININXb7iUhvSD7l6BxEAR6aC1h1lVU5FuWGJv5klp96rRd5pGTRQv7gJpZB4+2wPvnGGQONh/lSpP84gvemKrym0IvPYsCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAwIS1A7UK0n633qiPgD7QcSdpEBtLYnmFaBuOxsLo3hxDzohmkeR//5JToiiqjmBar1Pm26kxl4jzg0ZHDEnyIWhLsW97g+tGCyhp1gexZn4pWVEM43WYtMrmCqYWjwHQZ/r79WIGF3K74wsVb6/7itQWPdKevLqm5gB4aqqb5JAz+f7j7P6vlQIDFDdka3kvbsdlnCWwHKNAZJPueRyQnxVEOkYG3a+OY8knnP/s+pVdxKpJA+Hn18x/YbX5T0A1+E4gyUdPA7op5N37mW5IMkD8duccapuBzmaKNVBKn1C3/SAstU361xYpBOB3+3wY8a2sIYole4d68gM1l/YOrQ==
247d2bdd-ffce-41cb-b304-609f7d25e586	49cb8a98-12d5-479c-ae8b-0dd86e4a2381	privateKey	MIIEogIBAAKCAQEAyfiJNSXYzUakFBpKq0awPz+9cfKcelvcA+jOyErvRrWg2yHrH5GhHjUOHabTkZ4Svp17oevfI0ujwqsL1hPJjD5AzWElwxQ6TWb8pOu1P4ns0XSBIEjX0hf8SY8g6CyOdLxNeV9uLJ1f+xaMg7zTYaJbUs9jtyItSgCA3CSPH+cP2NTQJOCLwuWZKUPVm4VFmlRj3F1L18TJaFxaxQho9RAPVpocGifZFuZu6N9/E1JbMB2srqnkGAL10g0g1dvuJSG9IPuXoHEQBHpoLWHWVVTkW5YYm/mSWn3qtF3mkZNFC/uAmlkHj7bA++cYZA42H+VKk/ziC96YqvKbQi89iwIDAQABAoIBACadxQoq5tV03LlVP5KY7Oji9INdakrA1oPO1v6XyUEhSBSt2wlJrF8csMq9k3Ujnpzgent+oEbc1v5I+vXfCamtW3GJUhGHBBC5kLOtt5Vi9ysjFe9Izi8G0/9yhM2veztZp4x90RBptKjK6mnjyBzCUKi4K24f9D3Sc9DjkpP8H+WQYXvtbspnDJ+E0F7F23WGpm5bJAgp3cDcUr8Z4SittKLw2ubkA6+OB0uXtjxGpKKP/I4T2FnXHWshfrOe474wA7HyRP8mLr0UEO+ytStSFSeC7eg4vNOX3ChgZh0sHNTzdWNbwPFwyEd43loC9/uLV8i/KGH62m/kybXgQlUCgYEA/X4trSiDdV2CHEIqS4iViJdrfbHbjkXrf4qIIVqmvfraFHBXrgf5xHQGuL7uHgkRbimLOnteKGxN8bF3X6YyqQMeP4i9oh6VpIgjeug5FQyVB7FXd1/fvMn2ChAY495vte7EPkmCor1uk1ROCJdL6Wp6N2lHYkNlmuy/YBGmFfcCgYEAy/fohbqHdyLcca9okMC7KrQG1yEbgqSYdIUhQ6HWKl5Pp4LDzAD6wi3A78Y+XQaZXqylcZisGoOQAwd9AcYTik7KkHuxDa2DPuGgQrQiAWyO8UbxM4L1vk7s/c0GzQncOiI0gRdVe8/Dsc1J241bkRaOlgKIxmBtYNrUEMC44A0CgYBnfo2dhc3uLAhEC0uDXTdX9iJfxi7Srn9QqjmcDIvJQtKox5k0p3L1Hz3jTaigQKmKJZH/hYDS1i0YgZEwTwWd9XTzEZwCxaPo8eAyfP9ZNbLe2ivQxCbvyDEYuKvA1P8c82fR2mdolBjCNAhL/6FxohRV7TjEyKmCECiuS2ZYzwKBgH12KFjZu6nUj7R+KNuhMX+67No3Syy5Ae3qVeO8EHhPOr/W94jssVHvwtW6I3IlNQG/QKT3PCWy90pluMb2h95zSLZG30mCiVCMiH9/PcuScvqGoKcGzxIYij4zdxN4FTbNA27EY5ic28rqc5vQ/5nnPh2XwXoEpkMFV5xWb2GhAoGAG1JihGnvRDXiJz6YooCmh75FPk/M93NjWyc7Vchaj6QnS7klWHGydlfZ284VTu/McyRc4p8swMP82UyhTbrABhy35Jb0nfSoLSj58dWaeiskqacegQtgFzmwU5TLarOy53A8FjtnMeN1rgpcOWLY/JERZ4anHaeYWUG4lTrpnMg=
f70e4e8d-d389-4f02-b0cd-9b46c677aa35	49cb8a98-12d5-479c-ae8b-0dd86e4a2381	priority	100
5de81f5a-ccae-4cfd-abd8-283ecf682128	b53d42c8-4433-4011-8ac3-36aae072045b	host-sending-registration-request-must-match	true
854cf704-538e-4fd0-b04a-f1bb00477b9c	b53d42c8-4433-4011-8ac3-36aae072045b	client-uris-must-match	true
260a9959-5a85-4af9-842e-39437a393e75	98363e6d-163e-4226-a6da-70095dec3968	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
9e26ae60-037b-4f19-ad2b-7bbd6acb69f7	98363e6d-163e-4226-a6da-70095dec3968	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
5a699afa-6060-4601-8b39-dc2a9b81c6d2	98363e6d-163e-4226-a6da-70095dec3968	allowed-protocol-mapper-types	oidc-full-name-mapper
b5bda141-ddf2-4ff5-bb7d-e5567c6c4529	98363e6d-163e-4226-a6da-70095dec3968	allowed-protocol-mapper-types	saml-role-list-mapper
d740b34f-f52b-4afb-bc2f-6ca1d2af7abe	98363e6d-163e-4226-a6da-70095dec3968	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
78d8bdd5-3510-45a2-ba65-cf3d305edf3a	98363e6d-163e-4226-a6da-70095dec3968	allowed-protocol-mapper-types	saml-user-property-mapper
36410dc7-9976-43b1-8106-01781c63bfdd	98363e6d-163e-4226-a6da-70095dec3968	allowed-protocol-mapper-types	saml-user-attribute-mapper
f85db9b7-6589-4c46-b965-c050e161572c	98363e6d-163e-4226-a6da-70095dec3968	allowed-protocol-mapper-types	oidc-address-mapper
29597fe5-d252-4888-b969-bed57110d590	37f2bb16-81f7-4c1e-9b5f-16ba1e108362	allowed-protocol-mapper-types	saml-user-property-mapper
170e9538-fc37-46ab-99c0-607e17381f54	37f2bb16-81f7-4c1e-9b5f-16ba1e108362	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
4ca72a84-7779-4ca2-9325-a5d9a0b9c87f	37f2bb16-81f7-4c1e-9b5f-16ba1e108362	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
26e0ed6b-961c-4ffa-8ea8-b92a47b4c968	37f2bb16-81f7-4c1e-9b5f-16ba1e108362	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
567e0fd1-c4f5-4475-b306-e883cb7ef7e7	37f2bb16-81f7-4c1e-9b5f-16ba1e108362	allowed-protocol-mapper-types	saml-user-attribute-mapper
40ce1151-9347-48be-b7d5-0247371c8120	37f2bb16-81f7-4c1e-9b5f-16ba1e108362	allowed-protocol-mapper-types	oidc-address-mapper
034417e4-68c0-46c7-ac69-54c37ea3cd3e	37f2bb16-81f7-4c1e-9b5f-16ba1e108362	allowed-protocol-mapper-types	saml-role-list-mapper
8590fa7b-9188-4290-b8a9-d06459a8130d	37f2bb16-81f7-4c1e-9b5f-16ba1e108362	allowed-protocol-mapper-types	oidc-full-name-mapper
492e4088-19e3-42bd-8a9a-0fd8624fb3a4	ee845089-51c3-40b9-9a22-20192c4a69f8	max-clients	200
bd950c56-facb-4fe2-be3b-3ba272136911	dc54cc73-f8c6-4a2a-844e-a2bf30479b33	allow-default-scopes	true
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.composite_role (composite, child_role) FROM stdin;
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	b6c6aec5-db14-4aa7-9c8a-8d63dc80f309
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	195fcb7a-5b12-4732-9650-7c4681128524
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	fcd85f6b-2ba9-4088-b155-9a7c794a7c03
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	19cd9931-aa23-4504-b63c-86b2d3d64a79
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	c079e46e-dcbe-442e-80fc-1c1e3896db3e
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	da4ccc08-f0c2-4053-8f74-2b2769964d8f
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	0a4b460a-efb1-4d4d-88ab-ae26dc939ed6
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	3b0783c2-c960-48b6-94ff-748cec0645db
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	08593ef7-f55c-40e8-8236-0c0a8082856c
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	98350b43-aec0-4be3-a04b-ad1550d8cd39
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	f90e5ace-fd32-417a-bd79-267b70f822bc
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	4a868e03-eec7-4988-9254-41dd82e457f6
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	f3569fb6-d934-45da-9725-0806d847d8e2
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	53a96286-2507-42ec-ae0b-e28eb8d438e4
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	a5b5e4eb-bf06-4d99-914f-0d9bddaaeb54
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	45537e8e-35ee-4077-84a4-2f2dba833f32
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	5d41fcc3-9c86-41c5-98a8-1ea46a0f95dc
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	576f063f-cad5-4460-bd6f-2e5f6fa8f554
19cd9931-aa23-4504-b63c-86b2d3d64a79	576f063f-cad5-4460-bd6f-2e5f6fa8f554
19cd9931-aa23-4504-b63c-86b2d3d64a79	a5b5e4eb-bf06-4d99-914f-0d9bddaaeb54
c079e46e-dcbe-442e-80fc-1c1e3896db3e	45537e8e-35ee-4077-84a4-2f2dba833f32
e5f45988-c3b0-480e-bb01-aee1769ae71e	ed720621-57ee-4319-8366-9f00365780b8
e5f45988-c3b0-480e-bb01-aee1769ae71e	e68224e2-ddad-479b-9e2a-a3937e8de51e
e68224e2-ddad-479b-9e2a-a3937e8de51e	f31c92d9-b0fb-4b45-aa51-3a8a81d38133
5010785e-b6e4-446a-b100-1b148d38fa7e	9644d218-b849-429e-b82e-a4c85039c4ec
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	74a76bc7-a200-41ef-b1df-ea568bfd3790
e5f45988-c3b0-480e-bb01-aee1769ae71e	ccb0aba5-5ea0-49da-8f80-aaacc9106f70
e5f45988-c3b0-480e-bb01-aee1769ae71e	4d31a4f1-8902-41ee-92ac-91767a0ec777
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	4cc0aac9-94f5-4482-a5bb-b7e8915580a7
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	21bd6337-2e38-411c-b4ff-d48d855e9d94
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	93709477-00ba-480f-9068-21f3bc310392
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	44d67e3b-ed6b-4a75-ad9c-c25ea59b1b36
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	7301fb7c-0ec8-4c1e-b2ac-d8a7fd421ba9
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	45ca86fe-7fca-4c1e-8008-b14fe0a12c08
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	221c50cf-fb55-4aab-8b91-e49b8452c60a
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	90dbca0b-b6ee-44f1-83a0-38a4f08dcd36
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	dd813344-0148-49e7-ab85-fbb86aa87636
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	342df5da-c02f-4417-8e4e-5fec284fbb87
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	aac04a4c-102e-4342-bd33-4343e218134f
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	3d54c6b3-69b5-4cab-8d4f-7efac4203353
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	0b19e6a8-42d0-42ee-8c51-769e6f547b3b
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	07da76a1-252e-40bc-a794-c541dfde6db5
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	13a5d9a7-6f07-4d73-b45b-a5bd707bda70
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	bee2081f-5f85-4972-b2cd-dd10e692ea79
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	593342fd-01a0-47e5-9c93-83fdd691ef73
44d67e3b-ed6b-4a75-ad9c-c25ea59b1b36	13a5d9a7-6f07-4d73-b45b-a5bd707bda70
93709477-00ba-480f-9068-21f3bc310392	07da76a1-252e-40bc-a794-c541dfde6db5
93709477-00ba-480f-9068-21f3bc310392	593342fd-01a0-47e5-9c93-83fdd691ef73
5f8746f5-53fe-4353-996b-1a575e429f68	a0b080d5-db64-4c1d-a306-caa581548853
5f8746f5-53fe-4353-996b-1a575e429f68	467579ac-8c42-4443-bc84-3edbd19f99fa
5f8746f5-53fe-4353-996b-1a575e429f68	6b581ebe-dfe5-43b3-9a0b-d98447d498f6
5f8746f5-53fe-4353-996b-1a575e429f68	d64adf26-5deb-4fc0-959e-ae217418c1a6
5f8746f5-53fe-4353-996b-1a575e429f68	b6f094c8-fc90-4b95-9831-59f101a80bf9
5f8746f5-53fe-4353-996b-1a575e429f68	b479c0d9-2414-449d-918d-94efa429d5ed
5f8746f5-53fe-4353-996b-1a575e429f68	cec65e24-8568-4574-9425-9683a12920bb
5f8746f5-53fe-4353-996b-1a575e429f68	e46529cb-5174-403c-8c27-ab6ae039bb43
5f8746f5-53fe-4353-996b-1a575e429f68	b99e7569-052f-429d-9942-ae88c2dd7aaf
5f8746f5-53fe-4353-996b-1a575e429f68	bee3bc2a-20fd-46fc-acb8-8dffd77bd92c
5f8746f5-53fe-4353-996b-1a575e429f68	59c4208d-0e65-4b03-ad55-55a608b0944c
5f8746f5-53fe-4353-996b-1a575e429f68	998dbd53-1a0d-4b24-875d-ef9e108ad5ee
5f8746f5-53fe-4353-996b-1a575e429f68	d1485c52-b59b-4d28-8a58-67cc7993e4e7
5f8746f5-53fe-4353-996b-1a575e429f68	e7cb57a3-0fd4-42d9-8544-02a7e3c588ed
5f8746f5-53fe-4353-996b-1a575e429f68	6f166459-fe36-4392-9e4d-22005ff102e1
5f8746f5-53fe-4353-996b-1a575e429f68	78feec95-1770-4647-b923-d8febd9c1a4b
5f8746f5-53fe-4353-996b-1a575e429f68	93b399f2-183f-49e6-8855-4470e5246fcd
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	452d877e-11c4-4688-9d93-4fce63e7a410
6b581ebe-dfe5-43b3-9a0b-d98447d498f6	e7cb57a3-0fd4-42d9-8544-02a7e3c588ed
6b581ebe-dfe5-43b3-9a0b-d98447d498f6	93b399f2-183f-49e6-8855-4470e5246fcd
d64adf26-5deb-4fc0-959e-ae217418c1a6	6f166459-fe36-4392-9e4d-22005ff102e1
5f8746f5-53fe-4353-996b-1a575e429f68	62616307-9ff8-4a6e-ad66-688297c96a47
c59dba83-3f47-47d1-acbb-3feaf4c55643	dd6312a7-ac03-4032-beea-01f3c6c97ac7
c59dba83-3f47-47d1-acbb-3feaf4c55643	fb4b124b-513f-4f82-9b84-10b6ffe1fd5b
c59dba83-3f47-47d1-acbb-3feaf4c55643	c59dba83-3f47-47d1-acbb-3feaf4c55643
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
e2ecfcb8-8c9f-4ba2-9371-87236c4ba69e	\N	password	7a4cfab8-7481-473d-8923-55bf1a5212aa	1697629201704	\N	{"value":"52OBd0JRirrEa0vUZw1x8rS1b9PHzYPUWV2qXVdZRPg=","salt":"M99QdwMByFghgNv/+xhe3g==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
e55e81e9-0133-4e6b-8d7d-ef93a166c3f1	\N	password	191a5553-2655-4f6d-a3a1-6ffd3163fd9b	1698245825914	My password	{"value":"mDxIbUtqjsYpWxKPqBgaR9eWA+4lD2aqMBf6IVbbMD0=","salt":"/BYJxDSc/KaA9gujk5JEpA==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
181bc10a-ebb9-4486-b605-8b286811c559	\N	password	380c030c-4817-4803-a50c-cc81df5530b4	1699889799895	\N	{"value":"H6pZHMKEmQBQ86dhCpV3TdQsFvv3Qc6kNU+j0QOCOP0=","salt":"Xa1D8V3SNoFPOQJJ1J5Paw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2023-10-18 11:39:59.045855	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.20.0	\N	\N	7629198703
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2023-10-18 11:39:59.457483	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.20.0	\N	\N	7629198703
22.0.0-17484	keycloak	META-INF/jpa-changelog-22.0.0.xml	2023-10-18 11:40:00.196215	114	EXECUTED	8:4c3d4e8b142a66fcdf21b89a4dd33301	customChange		\N	4.20.0	\N	\N	7629198703
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2023-10-18 11:39:59.006797	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.20.0	\N	\N	7629198703
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2023-10-18 11:39:59.01095	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.20.0	\N	\N	7629198703
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2023-10-18 11:39:59.372578	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.20.0	\N	\N	7629198703
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2023-10-18 11:39:59.041207	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.20.0	\N	\N	7629198703
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2023-10-18 11:39:59.108613	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.20.0	\N	\N	7629198703
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2023-10-18 11:39:59.110996	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.20.0	\N	\N	7629198703
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2023-10-18 11:39:59.16108	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.20.0	\N	\N	7629198703
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2023-10-18 11:39:59.163461	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.20.0	\N	\N	7629198703
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2023-10-18 11:39:59.16743	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.20.0	\N	\N	7629198703
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2023-10-18 11:39:59.220887	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.20.0	\N	\N	7629198703
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2023-10-18 11:39:59.251303	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.20.0	\N	\N	7629198703
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2023-10-18 11:39:59.253408	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.20.0	\N	\N	7629198703
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2023-10-18 11:39:59.26521	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.20.0	\N	\N	7629198703
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-10-18 11:39:59.281918	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.20.0	\N	\N	7629198703
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-10-18 11:39:59.284307	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.20.0	\N	\N	7629198703
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-10-18 11:39:59.286572	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.20.0	\N	\N	7629198703
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-10-18 11:39:59.289385	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.20.0	\N	\N	7629198703
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2023-10-18 11:39:59.315901	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.20.0	\N	\N	7629198703
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2023-10-18 11:39:59.340692	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.20.0	\N	\N	7629198703
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2023-10-18 11:39:59.346317	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.20.0	\N	\N	7629198703
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2023-10-18 11:39:59.348216	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.20.0	\N	\N	7629198703
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2023-10-18 11:39:59.350958	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.20.0	\N	\N	7629198703
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2023-10-18 11:39:59.365221	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.20.0	\N	\N	7629198703
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2023-10-18 11:39:59.370439	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.20.0	\N	\N	7629198703
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2023-10-18 11:39:59.396538	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.20.0	\N	\N	7629198703
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2023-10-18 11:39:59.454712	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.20.0	\N	\N	7629198703
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2023-10-18 11:39:59.497762	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.20.0	\N	\N	7629198703
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2023-10-18 11:39:59.50765	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.20.0	\N	\N	7629198703
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2023-10-18 11:39:59.520464	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.20.0	\N	\N	7629198703
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2023-10-18 11:39:59.525329	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.20.0	\N	\N	7629198703
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-10-18 11:39:59.568869	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.20.0	\N	\N	7629198703
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-10-18 11:39:59.570889	34	MARK_RAN	9:3a32bace77c84d7678d035a7f5a8084e	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.20.0	\N	\N	7629198703
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-10-18 11:39:59.590565	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.20.0	\N	\N	7629198703
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2023-10-18 11:39:59.595907	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.20.0	\N	\N	7629198703
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-10-18 11:39:59.602143	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.20.0	\N	\N	7629198703
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2023-10-18 11:39:59.606239	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.20.0	\N	\N	7629198703
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2023-10-18 11:39:59.610101	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.20.0	\N	\N	7629198703
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-10-18 11:39:59.611872	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.20.0	\N	\N	7629198703
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-10-18 11:39:59.6139	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.20.0	\N	\N	7629198703
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2023-10-18 11:39:59.618617	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.20.0	\N	\N	7629198703
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-10-18 11:39:59.71114	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.20.0	\N	\N	7629198703
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2023-10-18 11:39:59.716353	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.20.0	\N	\N	7629198703
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-10-18 11:39:59.721266	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.20.0	\N	\N	7629198703
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-10-18 11:39:59.72707	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.20.0	\N	\N	7629198703
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-10-18 11:39:59.729002	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.20.0	\N	\N	7629198703
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-10-18 11:39:59.754402	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.20.0	\N	\N	7629198703
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-10-18 11:39:59.758404	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.20.0	\N	\N	7629198703
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2023-10-18 11:39:59.785728	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.20.0	\N	\N	7629198703
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2023-10-18 11:39:59.809263	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.20.0	\N	\N	7629198703
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2023-10-18 11:39:59.812993	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.20.0	\N	\N	7629198703
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2023-10-18 11:39:59.815545	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.20.0	\N	\N	7629198703
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2023-10-18 11:39:59.818087	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.20.0	\N	\N	7629198703
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-10-18 11:39:59.824642	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.20.0	\N	\N	7629198703
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-10-18 11:39:59.829322	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.20.0	\N	\N	7629198703
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-10-18 11:39:59.842793	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.20.0	\N	\N	7629198703
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-10-18 11:39:59.893918	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.20.0	\N	\N	7629198703
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2023-10-18 11:39:59.909771	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.20.0	\N	\N	7629198703
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2023-10-18 11:39:59.914613	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.20.0	\N	\N	7629198703
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2023-10-18 11:39:59.921533	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.20.0	\N	\N	7629198703
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2023-10-18 11:39:59.926715	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.20.0	\N	\N	7629198703
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2023-10-18 11:39:59.930393	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.20.0	\N	\N	7629198703
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2023-10-18 11:39:59.932787	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.20.0	\N	\N	7629198703
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2023-10-18 11:39:59.935054	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.20.0	\N	\N	7629198703
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2023-10-18 11:39:59.945449	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.20.0	\N	\N	7629198703
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2023-10-18 11:39:59.950729	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.20.0	\N	\N	7629198703
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2023-10-18 11:39:59.954817	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.20.0	\N	\N	7629198703
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2023-10-18 11:39:59.963772	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.20.0	\N	\N	7629198703
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2023-10-18 11:39:59.968316	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.20.0	\N	\N	7629198703
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2023-10-18 11:39:59.972215	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.20.0	\N	\N	7629198703
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-10-18 11:39:59.977174	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.20.0	\N	\N	7629198703
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-10-18 11:39:59.982236	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.20.0	\N	\N	7629198703
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-10-18 11:39:59.984035	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.20.0	\N	\N	7629198703
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-10-18 11:39:59.994338	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.20.0	\N	\N	7629198703
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-10-18 11:40:00.000334	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.20.0	\N	\N	7629198703
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-10-18 11:40:00.004202	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.20.0	\N	\N	7629198703
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-10-18 11:40:00.005937	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.20.0	\N	\N	7629198703
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-10-18 11:40:00.018493	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.20.0	\N	\N	7629198703
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-10-18 11:40:00.020689	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.20.0	\N	\N	7629198703
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-10-18 11:40:00.026505	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.20.0	\N	\N	7629198703
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-10-18 11:40:00.02834	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.20.0	\N	\N	7629198703
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-10-18 11:40:00.032389	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.20.0	\N	\N	7629198703
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-10-18 11:40:00.034073	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.20.0	\N	\N	7629198703
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-10-18 11:40:00.039716	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.20.0	\N	\N	7629198703
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2023-10-18 11:40:00.044033	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.20.0	\N	\N	7629198703
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2023-10-18 11:40:00.049211	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.20.0	\N	\N	7629198703
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2023-10-18 11:40:00.056415	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.20.0	\N	\N	7629198703
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-10-18 11:40:00.063398	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.20.0	\N	\N	7629198703
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-10-18 11:40:00.069112	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.20.0	\N	\N	7629198703
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-10-18 11:40:00.075964	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.20.0	\N	\N	7629198703
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-10-18 11:40:00.081684	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.20.0	\N	\N	7629198703
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-10-18 11:40:00.083599	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.20.0	\N	\N	7629198703
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-10-18 11:40:00.090108	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.20.0	\N	\N	7629198703
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-10-18 11:40:00.092212	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.20.0	\N	\N	7629198703
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-10-18 11:40:00.097527	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.20.0	\N	\N	7629198703
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-10-18 11:40:00.106092	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.20.0	\N	\N	7629198703
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-10-18 11:40:00.108177	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.20.0	\N	\N	7629198703
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-10-18 11:40:00.115885	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.20.0	\N	\N	7629198703
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-10-18 11:40:00.121667	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.20.0	\N	\N	7629198703
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-10-18 11:40:00.124299	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.20.0	\N	\N	7629198703
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-10-18 11:40:00.13011	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.20.0	\N	\N	7629198703
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-10-18 11:40:00.134479	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.20.0	\N	\N	7629198703
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2023-10-18 11:40:00.139325	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.20.0	\N	\N	7629198703
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2023-10-18 11:40:00.144819	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.20.0	\N	\N	7629198703
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2023-10-18 11:40:00.149832	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.20.0	\N	\N	7629198703
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2023-10-18 11:40:00.154067	107	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.20.0	\N	\N	7629198703
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-10-18 11:40:00.159347	108	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.20.0	\N	\N	7629198703
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-10-18 11:40:00.161178	109	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.20.0	\N	\N	7629198703
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-10-18 11:40:00.165988	110	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.20.0	\N	\N	7629198703
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2023-10-18 11:40:00.169945	111	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.20.0	\N	\N	7629198703
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2023-10-18 11:40:00.189228	112	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.20.0	\N	\N	7629198703
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2023-10-18 11:40:00.191292	113	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.20.0	\N	\N	7629198703
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2023-10-29 12:46:43.334433	115	MARK_RAN	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.23.2	\N	\N	8583602855
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2023-10-29 12:46:43.346564	116	EXECUTED	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.23.2	\N	\N	8583602855
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
69219f75-5959-4178-a860-0ae90853470b	17151962-3d4e-4a6b-9ec4-f935fb79eca2	f
69219f75-5959-4178-a860-0ae90853470b	636ac67c-05ca-4257-991f-4a9d9c0db1e1	t
69219f75-5959-4178-a860-0ae90853470b	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46	t
69219f75-5959-4178-a860-0ae90853470b	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb	t
69219f75-5959-4178-a860-0ae90853470b	1a972335-a90b-49d9-aabe-f8dd1b9a734e	f
69219f75-5959-4178-a860-0ae90853470b	fae0d46e-48ab-4809-87dc-1342a6071211	f
69219f75-5959-4178-a860-0ae90853470b	e3268633-89aa-4fcb-a1d6-8de6ee65235f	t
69219f75-5959-4178-a860-0ae90853470b	7c4783e6-472c-4b8d-806c-361ff26817de	t
69219f75-5959-4178-a860-0ae90853470b	04c034a1-7b68-4c88-b61a-6131bdaae4b4	f
69219f75-5959-4178-a860-0ae90853470b	eaea2a29-24f4-43be-99da-e989a2c7e944	t
2d41d0c8-a7ac-4cdc-b114-4baf577da237	5b4c2a93-e5a4-4693-950d-4a2af5b23063	t
2d41d0c8-a7ac-4cdc-b114-4baf577da237	6e0e1856-372a-4825-8ece-b0349456e31c	t
2d41d0c8-a7ac-4cdc-b114-4baf577da237	bfc8242a-b171-4c61-b05c-bf815aec0868	t
2d41d0c8-a7ac-4cdc-b114-4baf577da237	be3bdfa6-3417-4740-8344-69553a472eb9	t
2d41d0c8-a7ac-4cdc-b114-4baf577da237	a575d33b-0fe5-4365-80a9-cb004b02a952	t
2d41d0c8-a7ac-4cdc-b114-4baf577da237	d117141b-f630-4483-b380-3f51dcfe9ced	t
2d41d0c8-a7ac-4cdc-b114-4baf577da237	a5d5eaea-9349-4661-a7a7-2bf02b67d6ec	f
2d41d0c8-a7ac-4cdc-b114-4baf577da237	a534ad5a-f520-43c6-ada9-f749bcd71543	f
2d41d0c8-a7ac-4cdc-b114-4baf577da237	c873130a-056f-4fac-b2c1-d8bc990e3c39	f
2d41d0c8-a7ac-4cdc-b114-4baf577da237	7a42d3d9-1b9b-4d01-b2bf-a061edee1908	f
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id) FROM stdin;
a0eb690c-7b69-42bc-b996-15b43d7d16cb	security-admin-console	{"redirect_uri":"http://localhost:8180/admin/master/console/#/master/realm-settings"}	invalid_redirect_uri	10.89.3.58	69219f75-5959-4178-a860-0ae90853470b	\N	1697629264269	LOGIN_ERROR	\N
4068d21c-5aa5-4241-aec3-4af1a415bb50	security-admin-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"http://localhost.localdomain:8180/admin/master/console/","code_id":"60d0d920-d798-415f-a700-c20ec10f42eb","username":"admin"}	invalid_user_credentials	10.89.3.58	69219f75-5959-4178-a860-0ae90853470b	\N	1697629270769	LOGIN_ERROR	7a4cfab8-7481-473d-8923-55bf1a5212aa
a793e3df-ccb1-4303-9b1c-1972ae148b93	account-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"http://localhost.localdomain:8180/realms/master/account/","code_id":"47202d83-ccff-46bf-a7f3-60c9cfb6f8af"}	user_not_found	10.89.3.58	69219f75-5959-4178-a860-0ae90853470b	\N	1697629618133	LOGIN_ERROR	\N
0aef73c3-4408-412f-a512-be9951bf3fc0	account-console	{"redirect_uri":"http://localhost.localdomain:8180/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.58	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697629678320	LOGIN_ERROR	\N
3a1f2e03-4240-4673-af35-f7d52365a4d0	account-console	{"redirect_uri":"http://localhost.localdomain:8180/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.58	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697629688767	LOGIN_ERROR	\N
90f58c05-4f23-4799-ad1d-fe2d1e540254	account-console	{"redirect_uri":"http://localhost.localdomain:8180/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.58	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697629714698	LOGIN_ERROR	\N
69a83ac1-7fcd-43e5-9e99-801cbc06d935	account-console	{"redirect_uri":"https://localhost.localdomain:8443/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.72	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697634931133	LOGIN_ERROR	\N
c4b0cfae-1440-4363-b873-5eccd469ef40	account-console	{"redirect_uri":"https://localhost.localdomain:8443/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.72	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697635012128	LOGIN_ERROR	\N
db0212d0-c8e2-4e21-b491-17bb48b0984e	account-console	{"redirect_uri":"https://localhost.localdomain:8443/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.72	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697635089867	LOGIN_ERROR	\N
5ac9dbc2-c29c-4893-9995-63c268b349b2	account-console	{"redirect_uri":"https://localhost:8443/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.73	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697635315533	LOGIN_ERROR	\N
7d38aa63-1c5e-40c2-9e24-c20c86342e0a	account-console	{"redirect_uri":"https://localhost:8443/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.73	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697635359069	LOGIN_ERROR	\N
94a80c8c-98bb-4952-bc85-8a6a6cdd4c79	account-console	{"redirect_uri":"https://localhost:8443/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.73	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697635374855	LOGIN_ERROR	\N
9ac93bcc-1ce2-4163-8dd0-2319f8503c28	account-console	{"redirect_uri":"https://localhost:8443/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.73	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697635383414	LOGIN_ERROR	\N
4e79bf46-7fc9-4f9e-ad58-5c7b3be7a9ec	account-console	{"redirect_uri":"https://localhost:8443/realms/azuread/account/"}	invalid_redirect_uri	10.89.3.73	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697635504014	LOGIN_ERROR	\N
20be3593-e011-47d2-868f-41c82daf8ac8	security-admin-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"https://localhost:8443/admin/master/console/#/azuread/clients/512c74b9-7b68-42e2-962e-0d6507f71cd1/settings","code_id":"8b3aa543-6023-4c88-829c-38c746b84b92","username":"admin"}	invalid_user_credentials	10.89.3.75	69219f75-5959-4178-a860-0ae90853470b	\N	1697637554804	LOGIN_ERROR	7a4cfab8-7481-473d-8923-55bf1a5212aa
701b7e12-bac8-48fe-8fb4-280730b1eff8	security-admin-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"https://localhost:8443/admin/master/console/#/azuread/clients/512c74b9-7b68-42e2-962e-0d6507f71cd1/settings","code_id":"8b3aa543-6023-4c88-829c-38c746b84b92","username":"admin"}	invalid_user_credentials	10.89.3.75	69219f75-5959-4178-a860-0ae90853470b	\N	1697637557257	LOGIN_ERROR	7a4cfab8-7481-473d-8923-55bf1a5212aa
e9d1e404-43e3-434e-8643-13a713b8a33f	security-admin-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"https://127.0.0.1:8443/admin/master/console/#/aad/clients","code_id":"db5288c7-7cba-4da4-90ff-4eedf0bf8908","username":"admin"}	invalid_user_credentials	10.89.3.76	69219f75-5959-4178-a860-0ae90853470b	\N	1697637734373	LOGIN_ERROR	7a4cfab8-7481-473d-8923-55bf1a5212aa
b99ed98f-dd11-4fb3-b18a-3d68dc5c35b5	spa	null	client_not_found	10.89.3.78	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697638306378	LOGIN_ERROR	\N
52bceee9-8e16-483f-9005-2e8a8a901de9	spa	{"grant_type":"authorization_code"}	invalid_client_credentials	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697746765785	CODE_TO_TOKEN_ERROR	\N
177909ed-af7a-4b9b-8b8c-8f9e0f9216b5	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697746837709	CODE_TO_TOKEN_ERROR	\N
93e09621-9129-495f-820a-ba420e577fb7	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697746864467	CODE_TO_TOKEN_ERROR	\N
93e03eda-e332-4d66-ab9d-b4f43367c952	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697746892047	CODE_TO_TOKEN_ERROR	\N
08949269-d336-4d10-b962-24a7b81bce2a	spa	{"grant_type":"authorization_code"}	invalid_client_credentials	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697746901566	CODE_TO_TOKEN_ERROR	\N
40e05d09-1aa9-44a3-8fdd-95d77f5b40d2	spa	{"grant_type":"authorization_code"}	invalid_client_credentials	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697746904616	CODE_TO_TOKEN_ERROR	\N
662cf20e-48ff-47d0-bf80-2ddfddba9f5f	spa	{"grant_type":"authorization_code"}	invalid_client_credentials	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697746907188	CODE_TO_TOKEN_ERROR	\N
1a6f0e13-b4bc-425b-85a7-75edc34cc796	spa	{"grant_type":"authorization_code"}	invalid_client_credentials	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697746935443	CODE_TO_TOKEN_ERROR	\N
e7c062ed-1c02-4c54-8bd2-b348fa7e779f	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747163039	CODE_TO_TOKEN_ERROR	\N
16938351-57f5-4c58-bb54-eb7f44f692a5	\N	null	session_expired	10.89.3.137	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698162668627	LOGOUT_ERROR	\N
80d1ecc8-3f0a-4620-8fe9-47a8421e6257	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.106	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747328729	CODE_TO_TOKEN_ERROR	\N
097a63ea-8148-493f-bd27-eb8f5f30969c	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747427691	CODE_TO_TOKEN_ERROR	\N
76efdaba-a5cc-44bf-b804-a04ddcea4af8	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747430440	CODE_TO_TOKEN_ERROR	\N
34fb2f55-b026-4786-8134-a38e222e6819	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747431684	CODE_TO_TOKEN_ERROR	\N
80087020-9b4f-4e19-a8e4-db380c6dd243	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747433162	CODE_TO_TOKEN_ERROR	\N
575f6013-e7b9-4ee2-8993-9fc7e9074875	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747437362	CODE_TO_TOKEN_ERROR	\N
d2011d2c-c935-41dc-9895-0bd03a4cdfe4	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747594432	CODE_TO_TOKEN_ERROR	\N
f12e9205-129a-4705-a827-98a6a446a25f	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747596290	CODE_TO_TOKEN_ERROR	\N
f2f0fc4a-e6c0-4ba2-a5a4-4c01644804bb	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747676996	CODE_TO_TOKEN_ERROR	\N
9dd74173-47e0-4e81-a19f-d43fbdace168	spa	{"grant_type":"authorization_code","code_id":"b74e9e13-d7c5-48ae-b679-76c1d7f601ca","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	b74e9e13-d7c5-48ae-b679-76c1d7f601ca	1697747678105	CODE_TO_TOKEN_ERROR	\N
bf4693e0-f051-469a-9665-307a23425404	spa	{"grant_type":"authorization_code"}	invalid_client_credentials	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1697747776268	CODE_TO_TOKEN_ERROR	\N
c6f97d28-43bd-455d-9b36-40844b66ae9d	spa	{"grant_type":"authorization_code","code_id":"e1b44e79-6306-4826-b9f1-052f5e468888","client_auth_method":"client-secret"}	pkce_verification_failed	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	e1b44e79-6306-4826-b9f1-052f5e468888	1697747792069	CODE_TO_TOKEN_ERROR	69cedef5-e400-45bf-9a20-aba1bab02e46
77b60a31-8ec2-4ab9-a5e5-ea30a9e7c972	spa	{"grant_type":"authorization_code","code_id":"e1b44e79-6306-4826-b9f1-052f5e468888","client_auth_method":"client-secret"}	invalid_code	10.89.3.119	2d41d0c8-a7ac-4cdc-b114-4baf577da237	e1b44e79-6306-4826-b9f1-052f5e468888	1697747796083	CODE_TO_TOKEN_ERROR	\N
23ab35e3-24fa-4044-8ec4-e83e344572b9	security-admin-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"https://localhost:8443/admin/master/console/#/aad/realm-settings/tokens","code_id":"242eeb0d-fad8-45ef-b33c-47b992878520","username":"admin"}	invalid_user_credentials	10.89.3.10	69219f75-5959-4178-a860-0ae90853470b	\N	1697979194579	LOGIN_ERROR	7a4cfab8-7481-473d-8923-55bf1a5212aa
8949dc55-43c4-4a64-80a5-f3d8a6dfa56b	\N	null	invalid_request	10.89.3.104	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698091548644	LOGOUT_ERROR	\N
aced465c-9672-40f2-ba55-37e3a5a7706c	\N	null	invalid_request	10.89.3.104	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698091624231	LOGOUT_ERROR	\N
3d5bf114-06f8-416c-8432-8a027db672c0	\N	{"redirect_uri":"https://localhost:8443/realms/aad/protocol/openid-connect/logout?redirect_uri=http://localhost:3000/grid-map/connections?netId=5b3ed0c7-20d3-45fe-8c3b-84acb64750d3&state=f539c351b85f4756a7215d64391e913b&session_state=c5decafa-d115-4903-bacd-9761766ae983&code=cb935643-d01e-4f20-b0c3-dc5b8945f5ae.c5decafa-d115-4903-bacd-9761766ae983.4042690c-33d1-4e1b-acf7-9ba58ce60da0"}	invalid_redirect_uri	10.89.3.104	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698091631805	LOGOUT_ERROR	\N
15ea4cee-b954-4207-b847-72d5170e609a	\N	null	session_expired	10.89.3.104	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698092662946	LOGOUT_ERROR	\N
fca5a1e8-cf21-4703-81f5-d47cecfa7d80	security-admin-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"https://fedora:8443/admin/master/console/#/aad","code_id":"4342c9b0-e464-4cc9-bae9-a5f4d361cb8b","username":"admin"}	invalid_user_credentials	10.89.3.128	69219f75-5959-4178-a860-0ae90853470b	\N	1698134741887	LOGIN_ERROR	7a4cfab8-7481-473d-8923-55bf1a5212aa
040e1e8a-712c-482e-9dfc-e947f0d67a26	security-admin-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"https://fedora:8443/admin/master/console/#/aad","code_id":"4342c9b0-e464-4cc9-bae9-a5f4d361cb8b","username":"admin"}	invalid_user_credentials	10.89.3.128	69219f75-5959-4178-a860-0ae90853470b	\N	1698134744893	LOGIN_ERROR	7a4cfab8-7481-473d-8923-55bf1a5212aa
3cd60c55-97a8-4fcf-a04a-9f41e0675479	account-console	{"auth_method":"openid-connect","auth_type":"code","redirect_uri":"https://fedora:8443/realms/aad/account/","code_id":"a9808aec-63c3-4e9e-8798-748bb9b83900","username":"admin"}	user_not_found	10.89.3.128	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698135598294	LOGIN_ERROR	\N
b57a2656-7770-43ea-9948-723ca671f946	\N	null	cookie_not_found	10.89.3.137	69219f75-5959-4178-a860-0ae90853470b	\N	1698136360380	LOGIN_ERROR	\N
d5a4a6a3-bcc8-4260-a6b5-a608f668e2de	\N	null	invalid_token	10.89.3.137	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698152958655	LOGOUT_ERROR	\N
0fb7eaaa-bbbc-430a-9e68-33ef475cbd6f	\N	null	invalid_token	10.89.3.137	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698152982030	LOGOUT_ERROR	\N
c7c09a32-c6b1-450c-86c3-3661886ba9b8	\N	null	session_expired	10.89.3.137	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698158238138	LOGOUT_ERROR	\N
f3b2b13c-2f99-473a-8793-eedc889e06c4	\N	null	session_expired	10.89.3.137	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698158465615	LOGOUT_ERROR	\N
d87bc6b6-e6d3-4b49-b9bb-651f2d890a01	\N	null	session_expired	10.89.3.137	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698161167522	LOGOUT_ERROR	\N
c3299b0c-8af2-4012-83f1-f9722efb3f42	\N	null	session_expired	10.89.3.141	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698174497668	LOGOUT_ERROR	\N
45dc9012-bfdb-4662-a723-bc6485300d96	\N	null	session_expired	10.89.3.141	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698183476279	LOGOUT_ERROR	\N
b1315827-3104-4f08-a003-275f429a0a31	\N	null	session_expired	10.89.3.141	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698184310533	LOGOUT_ERROR	\N
a8e8cdb6-9656-4d58-8bbf-2d7483713949	spa	{"auth_method":"oauth_credentials","grant_type":"password","client_auth_method":"client-secret"}	not_allowed	10.89.3.141	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698233004305	LOGIN_ERROR	\N
dbd82cd2-15d8-4bb3-b13c-af79d5ca14e4	\N	null	session_expired	10.89.3.172	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698245840369	LOGOUT_ERROR	\N
f657ad3c-b3d0-461a-8592-d86f0668f6b7	\N	null	session_expired	10.89.3.172	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698305532227	LOGOUT_ERROR	\N
08b02745-fb4f-402f-8225-e201116ea054	\N	null	session_expired	10.89.3.172	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698315764704	LOGOUT_ERROR	\N
09682d5f-2e79-44d4-ad91-14ea8ee176f1	\N	null	session_expired	10.89.3.172	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698320734688	LOGOUT_ERROR	\N
d1625819-6263-439a-934d-4c82c799de25	\N	null	session_expired	10.89.3.172	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698323587320	LOGOUT_ERROR	\N
c61cd116-9bdc-409e-b5a8-a650567a934c	service-account-spa	{"grant_type":"client_credentials"}	client_not_found	10.89.3.172	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698326311171	CLIENT_LOGIN_ERROR	\N
2a00da82-c132-4fdc-8f06-e7e3f03139c9	\N	null	session_expired	10.89.3.172	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698326799125	LOGOUT_ERROR	\N
a88caf0e-6cd0-4fdc-afdb-c674e153f388	spa	{"grant_type":"client_credentials"}	client_not_found	10.89.3.171	69219f75-5959-4178-a860-0ae90853470b	\N	1698326803069	CLIENT_LOGIN_ERROR	\N
26754a3b-43cf-4c77-87a0-3886e0a84408	spa	{"grant_type":"client_credentials"}	client_not_found	10.89.3.171	69219f75-5959-4178-a860-0ae90853470b	\N	1698326803095	CLIENT_LOGIN_ERROR	\N
8ee2a6d3-667d-4a9c-b517-a9e4055d2ba1	spa	{"grant_type":"client_credentials"}	client_not_found	10.89.3.171	69219f75-5959-4178-a860-0ae90853470b	\N	1698326803103	CLIENT_LOGIN_ERROR	\N
5f02f03c-065d-45aa-82bb-61dcd2f2ae18	spa	{"grant_type":"client_credentials"}	client_not_found	10.89.3.171	69219f75-5959-4178-a860-0ae90853470b	\N	1698326803113	CLIENT_LOGIN_ERROR	\N
b59e2917-9911-4de9-960c-d1d90485c209	spa	{"grant_type":"client_credentials"}	client_not_found	10.89.3.171	69219f75-5959-4178-a860-0ae90853470b	\N	1698326803077	CLIENT_LOGIN_ERROR	\N
d43d13fe-99c4-4e59-9eac-cedf552bf2a2	spa	{"grant_type":"client_credentials"}	client_not_found	10.89.3.171	69219f75-5959-4178-a860-0ae90853470b	\N	1698326803089	CLIENT_LOGIN_ERROR	\N
51a5bf69-3406-43e8-adad-a55b73164b86	spa	{"grant_type":"client_credentials"}	client_not_found	10.89.3.171	69219f75-5959-4178-a860-0ae90853470b	\N	1698326803128	CLIENT_LOGIN_ERROR	\N
0a77fbb4-e121-4c8e-81f2-d7c492748569	\N	null	session_expired	10.89.3.184	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698342295034	LOGOUT_ERROR	\N
2e1d00ea-9503-48b8-8a2d-8e3331237a7d	\N	null	session_expired	10.89.3.184	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698346349080	LOGOUT_ERROR	\N
f0c9b2de-016a-48f8-ada2-301fca750957	\N	null	session_expired	10.89.3.184	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698355947739	LOGOUT_ERROR	\N
05655813-179a-41d1-9bcc-8ec717aea0d0	\N	null	session_expired	10.89.3.184	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698393021826	LOGOUT_ERROR	\N
f57d1a1f-068e-4c2f-b62a-cad6d9dec550	\N	null	session_expired	10.89.3.184	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698401343860	LOGOUT_ERROR	\N
f99cead8-dc56-43dd-bf0c-bd1e25b79062	\N	null	session_expired	10.89.3.184	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698409407712	LOGOUT_ERROR	\N
476de79f-4b67-4352-99b1-719523107b97	spa	{"grant_type":"authorization_code","code_id":"d0f06adf-2cd3-4a7f-88fc-d99652fe3127","client_auth_method":"client-secret"}	invalid_code	10.89.3.184	2d41d0c8-a7ac-4cdc-b114-4baf577da237	d0f06adf-2cd3-4a7f-88fc-d99652fe3127	1698411986466	CODE_TO_TOKEN_ERROR	\N
c028c758-2d90-4118-87b4-44226e106e42	\N	null	session_expired	10.89.3.204	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698422646022	LOGOUT_ERROR	\N
b622950f-a2e6-4e4f-8cec-6b9381e0ae44	\N	null	session_expired	10.89.3.204	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698431754743	LOGOUT_ERROR	\N
89d0f470-f341-461e-b19d-5364571959e0	\N	null	session_expired	10.89.3.204	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698443414545	LOGOUT_ERROR	\N
7abdf5c4-5892-4a45-a4da-19380ba5b097	\N	null	session_expired	10.89.3.204	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698487121397	LOGOUT_ERROR	\N
49807017-9c1a-42f9-b96d-02074dc87656	\N	null	session_expired	10.89.3.204	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698490558465	LOGOUT_ERROR	\N
f77e0d23-001e-4eca-80af-812fa1c25892	\N	null	session_expired	10.89.3.204	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698522856960	LOGOUT_ERROR	\N
1a23247c-4664-474f-88ce-ba7496a876fb	\N	null	session_expired	10.89.3.204	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	1698579603806	LOGOUT_ERROR	\N
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
08d18f7e-70c4-4c31-b126-f71deeb5d564	grid-administrators	 	2d41d0c8-a7ac-4cdc-b114-4baf577da237
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
e5f45988-c3b0-480e-bb01-aee1769ae71e	69219f75-5959-4178-a860-0ae90853470b	f	${role_default-roles}	default-roles-master	69219f75-5959-4178-a860-0ae90853470b	\N	\N
b6c6aec5-db14-4aa7-9c8a-8d63dc80f309	69219f75-5959-4178-a860-0ae90853470b	f	${role_create-realm}	create-realm	69219f75-5959-4178-a860-0ae90853470b	\N	\N
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	69219f75-5959-4178-a860-0ae90853470b	f	${role_admin}	admin	69219f75-5959-4178-a860-0ae90853470b	\N	\N
195fcb7a-5b12-4732-9650-7c4681128524	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_create-client}	create-client	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
fcd85f6b-2ba9-4088-b155-9a7c794a7c03	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_view-realm}	view-realm	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
19cd9931-aa23-4504-b63c-86b2d3d64a79	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_view-users}	view-users	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
c079e46e-dcbe-442e-80fc-1c1e3896db3e	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_view-clients}	view-clients	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
da4ccc08-f0c2-4053-8f74-2b2769964d8f	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_view-events}	view-events	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
0a4b460a-efb1-4d4d-88ab-ae26dc939ed6	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_view-identity-providers}	view-identity-providers	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
3b0783c2-c960-48b6-94ff-748cec0645db	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_view-authorization}	view-authorization	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
08593ef7-f55c-40e8-8236-0c0a8082856c	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_manage-realm}	manage-realm	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
98350b43-aec0-4be3-a04b-ad1550d8cd39	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_manage-users}	manage-users	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
f90e5ace-fd32-417a-bd79-267b70f822bc	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_manage-clients}	manage-clients	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
4a868e03-eec7-4988-9254-41dd82e457f6	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_manage-events}	manage-events	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
f3569fb6-d934-45da-9725-0806d847d8e2	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_manage-identity-providers}	manage-identity-providers	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
53a96286-2507-42ec-ae0b-e28eb8d438e4	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_manage-authorization}	manage-authorization	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
a5b5e4eb-bf06-4d99-914f-0d9bddaaeb54	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_query-users}	query-users	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
45537e8e-35ee-4077-84a4-2f2dba833f32	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_query-clients}	query-clients	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
5d41fcc3-9c86-41c5-98a8-1ea46a0f95dc	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_query-realms}	query-realms	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
576f063f-cad5-4460-bd6f-2e5f6fa8f554	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_query-groups}	query-groups	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
ed720621-57ee-4319-8366-9f00365780b8	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	${role_view-profile}	view-profile	69219f75-5959-4178-a860-0ae90853470b	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	\N
e68224e2-ddad-479b-9e2a-a3937e8de51e	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	${role_manage-account}	manage-account	69219f75-5959-4178-a860-0ae90853470b	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	\N
f31c92d9-b0fb-4b45-aa51-3a8a81d38133	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	${role_manage-account-links}	manage-account-links	69219f75-5959-4178-a860-0ae90853470b	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	\N
d6d5927e-41b6-45c8-a798-0c72306edbb9	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	${role_view-applications}	view-applications	69219f75-5959-4178-a860-0ae90853470b	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	\N
9644d218-b849-429e-b82e-a4c85039c4ec	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	${role_view-consent}	view-consent	69219f75-5959-4178-a860-0ae90853470b	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	\N
5010785e-b6e4-446a-b100-1b148d38fa7e	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	${role_manage-consent}	manage-consent	69219f75-5959-4178-a860-0ae90853470b	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	\N
cbb37a43-e81a-4322-8636-a812f7de9448	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	${role_view-groups}	view-groups	69219f75-5959-4178-a860-0ae90853470b	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	\N
68581c23-46aa-4412-a0d3-4b2e3bcc3925	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	t	${role_delete-account}	delete-account	69219f75-5959-4178-a860-0ae90853470b	5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	\N
95664f6e-cdaa-4dc1-b946-ad82445c410a	ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	t	${role_read-token}	read-token	69219f75-5959-4178-a860-0ae90853470b	ac90994e-19c9-4aaa-a3f2-3901a65cd0c3	\N
74a76bc7-a200-41ef-b1df-ea568bfd3790	37acefbe-975b-430e-b49e-8cb54f9e6a7f	t	${role_impersonation}	impersonation	69219f75-5959-4178-a860-0ae90853470b	37acefbe-975b-430e-b49e-8cb54f9e6a7f	\N
ccb0aba5-5ea0-49da-8f80-aaacc9106f70	69219f75-5959-4178-a860-0ae90853470b	f	${role_offline-access}	offline_access	69219f75-5959-4178-a860-0ae90853470b	\N	\N
4d31a4f1-8902-41ee-92ac-91767a0ec777	69219f75-5959-4178-a860-0ae90853470b	f	${role_uma_authorization}	uma_authorization	69219f75-5959-4178-a860-0ae90853470b	\N	\N
c59dba83-3f47-47d1-acbb-3feaf4c55643	2d41d0c8-a7ac-4cdc-b114-4baf577da237	f	${role_default-roles}	default-roles-master	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	\N
4cc0aac9-94f5-4482-a5bb-b7e8915580a7	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_create-client}	create-client	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
21bd6337-2e38-411c-b4ff-d48d855e9d94	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_view-realm}	view-realm	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
93709477-00ba-480f-9068-21f3bc310392	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_view-users}	view-users	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
44d67e3b-ed6b-4a75-ad9c-c25ea59b1b36	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_view-clients}	view-clients	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
7301fb7c-0ec8-4c1e-b2ac-d8a7fd421ba9	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_view-events}	view-events	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
45ca86fe-7fca-4c1e-8008-b14fe0a12c08	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_view-identity-providers}	view-identity-providers	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
221c50cf-fb55-4aab-8b91-e49b8452c60a	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_view-authorization}	view-authorization	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
90dbca0b-b6ee-44f1-83a0-38a4f08dcd36	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_manage-realm}	manage-realm	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
dd813344-0148-49e7-ab85-fbb86aa87636	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_manage-users}	manage-users	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
342df5da-c02f-4417-8e4e-5fec284fbb87	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_manage-clients}	manage-clients	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
aac04a4c-102e-4342-bd33-4343e218134f	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_manage-events}	manage-events	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
3d54c6b3-69b5-4cab-8d4f-7efac4203353	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_manage-identity-providers}	manage-identity-providers	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
0b19e6a8-42d0-42ee-8c51-769e6f547b3b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_manage-authorization}	manage-authorization	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
07da76a1-252e-40bc-a794-c541dfde6db5	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_query-users}	query-users	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
13a5d9a7-6f07-4d73-b45b-a5bd707bda70	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_query-clients}	query-clients	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
bee2081f-5f85-4972-b2cd-dd10e692ea79	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_query-realms}	query-realms	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
593342fd-01a0-47e5-9c93-83fdd691ef73	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_query-groups}	query-groups	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
5f8746f5-53fe-4353-996b-1a575e429f68	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_realm-admin}	realm-admin	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
a0b080d5-db64-4c1d-a306-caa581548853	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_create-client}	create-client	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
467579ac-8c42-4443-bc84-3edbd19f99fa	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_view-realm}	view-realm	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
6b581ebe-dfe5-43b3-9a0b-d98447d498f6	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_view-users}	view-users	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
d64adf26-5deb-4fc0-959e-ae217418c1a6	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_view-clients}	view-clients	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
b6f094c8-fc90-4b95-9831-59f101a80bf9	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_view-events}	view-events	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
b479c0d9-2414-449d-918d-94efa429d5ed	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_view-identity-providers}	view-identity-providers	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
cec65e24-8568-4574-9425-9683a12920bb	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_view-authorization}	view-authorization	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
e46529cb-5174-403c-8c27-ab6ae039bb43	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_manage-realm}	manage-realm	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
b99e7569-052f-429d-9942-ae88c2dd7aaf	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_manage-users}	manage-users	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
bee3bc2a-20fd-46fc-acb8-8dffd77bd92c	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_manage-clients}	manage-clients	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
59c4208d-0e65-4b03-ad55-55a608b0944c	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_manage-events}	manage-events	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
998dbd53-1a0d-4b24-875d-ef9e108ad5ee	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_manage-identity-providers}	manage-identity-providers	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
d1485c52-b59b-4d28-8a58-67cc7993e4e7	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_manage-authorization}	manage-authorization	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
e7cb57a3-0fd4-42d9-8544-02a7e3c588ed	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_query-users}	query-users	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
6f166459-fe36-4392-9e4d-22005ff102e1	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_query-clients}	query-clients	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
78feec95-1770-4647-b923-d8febd9c1a4b	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_query-realms}	query-realms	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
93b399f2-183f-49e6-8855-4470e5246fcd	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_query-groups}	query-groups	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
452d877e-11c4-4688-9d93-4fce63e7a410	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	t	${role_impersonation}	impersonation	69219f75-5959-4178-a860-0ae90853470b	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	\N
62616307-9ff8-4a6e-ad66-688297c96a47	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	t	${role_impersonation}	impersonation	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
dd6312a7-ac03-4032-beea-01f3c6c97ac7	2d41d0c8-a7ac-4cdc-b114-4baf577da237	f	${role_offline-access}	offline_access	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	\N
f36bdd5b-a3f9-4d99-8091-b057c08915d8	512c74b9-7b68-42e2-962e-0d6507f71cd1	t	\N	manage-account	2d41d0c8-a7ac-4cdc-b114-4baf577da237	512c74b9-7b68-42e2-962e-0d6507f71cd1	\N
ef576c55-7142-4b27-a4ec-3868b685b8f8	512c74b9-7b68-42e2-962e-0d6507f71cd1	t	\N	view-groups	2d41d0c8-a7ac-4cdc-b114-4baf577da237	512c74b9-7b68-42e2-962e-0d6507f71cd1	\N
ddff9c61-08da-40e5-b894-d2e95871937f	512c74b9-7b68-42e2-962e-0d6507f71cd1	t	${role_delete-account}	delete-account	2d41d0c8-a7ac-4cdc-b114-4baf577da237	512c74b9-7b68-42e2-962e-0d6507f71cd1	\N
fb4b124b-513f-4f82-9b84-10b6ffe1fd5b	2d41d0c8-a7ac-4cdc-b114-4baf577da237	f	${role_uma_authorization}	uma_authorization	2d41d0c8-a7ac-4cdc-b114-4baf577da237	\N	\N
959f87a3-568a-4370-a6b9-4202fa2c83d6	4042690c-33d1-4e1b-acf7-9ba58ce60da0	t	\N	uma_protection	2d41d0c8-a7ac-4cdc-b114-4baf577da237	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
096a0bbc-680a-4ac3-9195-84a978946b63	4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	t	\N	uma_protection	2d41d0c8-a7ac-4cdc-b114-4baf577da237	4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.migration_model (id, version, update_time) FROM stdin;
zkkz8	22.0.0	1697629200
5sy8b	22.0.5	1698583603
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
3eb93418-25d3-4021-975b-3cb54da81394	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
fc3b6c76-ce9d-4f3b-9803-bd96de5529ed	defaultResourceType	
1a9c3688-b70a-4ad9-b9a0-ddae742b942c	groups	[{"id":"08d18f7e-70c4-4c31-b126-f71deeb5d564","extendChildren":false}]
1a9c3688-b70a-4ad9-b9a0-ddae742b942c	groupsClaim	
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
75bdc70b-6db7-4958-945c-4d5610b51251	audience resolve	openid-connect	oidc-audience-resolve-mapper	07482b6a-2476-4033-af31-9d6ac30697af	\N
72393e37-b83f-487c-8013-0a43b9b6229f	locale	openid-connect	oidc-usermodel-attribute-mapper	3cd83037-98f6-44da-be80-73f9e77a3d39	\N
44f04d1b-3cff-4947-bcc0-164805856ccb	role list	saml	saml-role-list-mapper	\N	636ac67c-05ca-4257-991f-4a9d9c0db1e1
d7114b31-0969-4c51-9616-4b7c7238d171	full name	openid-connect	oidc-full-name-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
e0f3fae2-cb8c-4f4b-90f1-5b69d8ffd7eb	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
6b1d4c5e-d809-4df9-ab66-dd50b5633490	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
408b64db-b2a3-4b42-add9-81614bab72b3	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
128ecc1b-82db-42ec-aa9c-26102cb47569	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
1ce16023-3fd1-4847-816b-fe37456b003d	username	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
15d2473d-d409-4465-a8d2-c47deef0a689	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
67ae41f5-9570-4775-a9b1-966548dc7c1b	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
c378aa55-b799-4bf1-ab6b-5b5103314db1	website	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
5408dc70-1880-40c1-a337-57da6b7f9a17	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
63d34945-1938-4294-979c-faa865b999b5	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
e42f3c6a-3460-4ff2-99c6-d5ce2bb07f93	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
7a6d50a3-7a34-42b2-9215-94b9fa75f1e6	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
3d8eda66-f23e-4973-a31d-f0eb36609d5e	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	dbd38a9b-dad1-4ebe-8ce0-b3ae00c01d46
318f9e90-499d-4be7-841c-913875195fba	email	openid-connect	oidc-usermodel-attribute-mapper	\N	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb
d7248f25-31dc-40ba-a108-b52a800d6caa	email verified	openid-connect	oidc-usermodel-property-mapper	\N	04e6cbb1-6d6e-44cd-8f84-7ad745ab0afb
8416988d-3465-42cb-9fb3-4df06a6ec21d	address	openid-connect	oidc-address-mapper	\N	1a972335-a90b-49d9-aabe-f8dd1b9a734e
26ab193e-9aaf-4bc9-b796-ee2879194b54	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	fae0d46e-48ab-4809-87dc-1342a6071211
a0cf73db-6690-4bcf-a9e6-e0494b5cbe4e	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	fae0d46e-48ab-4809-87dc-1342a6071211
bff49245-7c69-47b2-908d-da0ab847f1f5	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	e3268633-89aa-4fcb-a1d6-8de6ee65235f
de955c0e-cbca-4af9-8707-988bda929fe1	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	e3268633-89aa-4fcb-a1d6-8de6ee65235f
4b7d41b8-596e-4959-b799-a0eecf1f18db	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	e3268633-89aa-4fcb-a1d6-8de6ee65235f
3340d975-3eb6-4620-a43b-a7d72c367a77	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	7c4783e6-472c-4b8d-806c-361ff26817de
2de8cb34-356e-4999-aef1-8b95f9c20f02	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	04c034a1-7b68-4c88-b61a-6131bdaae4b4
72066df6-0046-43c3-bec4-bad96e1b718c	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	04c034a1-7b68-4c88-b61a-6131bdaae4b4
8ea48f2f-b53f-48ce-b48e-6d8c0cf3977c	acr loa level	openid-connect	oidc-acr-mapper	\N	eaea2a29-24f4-43be-99da-e989a2c7e944
48f10c48-a1eb-4190-9006-a2a86528d54e	role list	saml	saml-role-list-mapper	\N	5b4c2a93-e5a4-4693-950d-4a2af5b23063
9a993084-3cb8-426a-9616-f32b711b8d2b	full name	openid-connect	oidc-full-name-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
291a54a9-683a-4da6-97c4-07c370bbed1f	username	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
e5e1fc29-2bde-48f0-8672-897b823a96bd	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
08d88467-7147-4f71-a5de-8cd0db71a4ad	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
2fb112ba-8b5d-46e8-8d3e-d45f55d6d580	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
555c3aa4-c1f9-4449-bab9-b113ed6278c4	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
ca6e454a-471b-4d8f-917b-b7e21ec360a5	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
b9f74f64-bf8e-4380-93a1-98d9366d178e	website	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
4fa8e70c-6da3-4523-b87e-40ab85a13b71	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
5c2b1415-af43-4e1e-a3f4-7d11b12f3da5	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
fca41784-bcd0-49b6-b0d6-2e9280080b5d	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
48ecfbfb-8d10-4bf1-bfd6-83c8f37bf315	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
d87024a0-7d50-4c60-9ed1-c3356257e011	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
da47791f-268e-4b96-ad29-dadcd69203ae	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	6e0e1856-372a-4825-8ece-b0349456e31c
e5160161-50ea-4e01-a849-9decbded1975	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	a575d33b-0fe5-4365-80a9-cb004b02a952
a244df25-66e3-4286-b10d-7e93c601fbfb	email	openid-connect	oidc-usermodel-attribute-mapper	\N	bfc8242a-b171-4c61-b05c-bf815aec0868
d5e4d45d-d6f1-4725-85c6-a95466fa1208	email verified	openid-connect	oidc-usermodel-property-mapper	\N	bfc8242a-b171-4c61-b05c-bf815aec0868
f8d9c778-6fa9-4643-934a-85b7dcf706db	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	7a42d3d9-1b9b-4d01-b2bf-a061edee1908
8a5825b3-ccc6-4a2f-b2e0-bd45630a9735	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	7a42d3d9-1b9b-4d01-b2bf-a061edee1908
85a03ee2-ad64-4bcd-a670-97ce732206a4	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	be3bdfa6-3417-4740-8344-69553a472eb9
bd4a56c1-0a6f-4723-b90e-3a8cf46804a6	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	be3bdfa6-3417-4740-8344-69553a472eb9
b4d1d399-7d3c-4364-a81d-0d73b3fe8d9e	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	be3bdfa6-3417-4740-8344-69553a472eb9
ce20f8ef-7eaa-4a93-82ab-4c4f539cd06d	acr loa level	openid-connect	oidc-acr-mapper	\N	d117141b-f630-4483-b380-3f51dcfe9ced
0ef79314-0409-4d7b-b0fa-60ea85b1e448	address	openid-connect	oidc-address-mapper	\N	a534ad5a-f520-43c6-ada9-f749bcd71543
311f5686-f4a0-425f-91c3-3f11caadb883	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	c873130a-056f-4fac-b2c1-d8bc990e3c39
57b2dcd4-2c8e-43f4-8b04-9955cf9faa07	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	c873130a-056f-4fac-b2c1-d8bc990e3c39
2ed43618-446b-4039-a32d-28075c3099bc	audience resolve	openid-connect	oidc-audience-resolve-mapper	312930c6-3b4a-492f-9f52-bf0947d8c4e5	\N
496ffe94-7528-4761-b4cf-c61faf0f3969	locale	openid-connect	oidc-usermodel-attribute-mapper	701a3ada-3c87-42d9-bfc2-710bc231c878	\N
9ca46f6c-8a35-4e17-9007-4b7d81e82fc0	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
9fdba0ca-20c4-4631-aa45-8e86774ff2b6	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
ca073786-4e26-483d-9f54-f29ad62c7518	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
c2a718a7-cd09-493e-81cc-b76cede325df	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
b8935d4b-4f6b-4e2d-bba5-0c01dd918d35	client roles	openid-connect	oidc-usermodel-client-role-mapper	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
cb1fe3a0-e67a-4eae-9a64-d817c30f4923	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	\N
7a4b38ad-f96a-4a80-85bf-59084cbffcc4	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	\N
77113c7c-f386-480a-a597-39bcd544d64a	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
72393e37-b83f-487c-8013-0a43b9b6229f	true	userinfo.token.claim
72393e37-b83f-487c-8013-0a43b9b6229f	locale	user.attribute
72393e37-b83f-487c-8013-0a43b9b6229f	true	id.token.claim
72393e37-b83f-487c-8013-0a43b9b6229f	true	access.token.claim
72393e37-b83f-487c-8013-0a43b9b6229f	locale	claim.name
72393e37-b83f-487c-8013-0a43b9b6229f	String	jsonType.label
44f04d1b-3cff-4947-bcc0-164805856ccb	false	single
44f04d1b-3cff-4947-bcc0-164805856ccb	Basic	attribute.nameformat
44f04d1b-3cff-4947-bcc0-164805856ccb	Role	attribute.name
128ecc1b-82db-42ec-aa9c-26102cb47569	true	userinfo.token.claim
128ecc1b-82db-42ec-aa9c-26102cb47569	nickname	user.attribute
128ecc1b-82db-42ec-aa9c-26102cb47569	true	id.token.claim
128ecc1b-82db-42ec-aa9c-26102cb47569	true	access.token.claim
128ecc1b-82db-42ec-aa9c-26102cb47569	nickname	claim.name
128ecc1b-82db-42ec-aa9c-26102cb47569	String	jsonType.label
15d2473d-d409-4465-a8d2-c47deef0a689	true	userinfo.token.claim
15d2473d-d409-4465-a8d2-c47deef0a689	profile	user.attribute
15d2473d-d409-4465-a8d2-c47deef0a689	true	id.token.claim
15d2473d-d409-4465-a8d2-c47deef0a689	true	access.token.claim
15d2473d-d409-4465-a8d2-c47deef0a689	profile	claim.name
15d2473d-d409-4465-a8d2-c47deef0a689	String	jsonType.label
1ce16023-3fd1-4847-816b-fe37456b003d	true	userinfo.token.claim
1ce16023-3fd1-4847-816b-fe37456b003d	username	user.attribute
1ce16023-3fd1-4847-816b-fe37456b003d	true	id.token.claim
1ce16023-3fd1-4847-816b-fe37456b003d	true	access.token.claim
1ce16023-3fd1-4847-816b-fe37456b003d	preferred_username	claim.name
1ce16023-3fd1-4847-816b-fe37456b003d	String	jsonType.label
3d8eda66-f23e-4973-a31d-f0eb36609d5e	true	userinfo.token.claim
3d8eda66-f23e-4973-a31d-f0eb36609d5e	updatedAt	user.attribute
3d8eda66-f23e-4973-a31d-f0eb36609d5e	true	id.token.claim
3d8eda66-f23e-4973-a31d-f0eb36609d5e	true	access.token.claim
3d8eda66-f23e-4973-a31d-f0eb36609d5e	updated_at	claim.name
3d8eda66-f23e-4973-a31d-f0eb36609d5e	long	jsonType.label
408b64db-b2a3-4b42-add9-81614bab72b3	true	userinfo.token.claim
408b64db-b2a3-4b42-add9-81614bab72b3	middleName	user.attribute
408b64db-b2a3-4b42-add9-81614bab72b3	true	id.token.claim
408b64db-b2a3-4b42-add9-81614bab72b3	true	access.token.claim
408b64db-b2a3-4b42-add9-81614bab72b3	middle_name	claim.name
408b64db-b2a3-4b42-add9-81614bab72b3	String	jsonType.label
5408dc70-1880-40c1-a337-57da6b7f9a17	true	userinfo.token.claim
5408dc70-1880-40c1-a337-57da6b7f9a17	gender	user.attribute
5408dc70-1880-40c1-a337-57da6b7f9a17	true	id.token.claim
5408dc70-1880-40c1-a337-57da6b7f9a17	true	access.token.claim
5408dc70-1880-40c1-a337-57da6b7f9a17	gender	claim.name
5408dc70-1880-40c1-a337-57da6b7f9a17	String	jsonType.label
63d34945-1938-4294-979c-faa865b999b5	true	userinfo.token.claim
63d34945-1938-4294-979c-faa865b999b5	birthdate	user.attribute
63d34945-1938-4294-979c-faa865b999b5	true	id.token.claim
63d34945-1938-4294-979c-faa865b999b5	true	access.token.claim
63d34945-1938-4294-979c-faa865b999b5	birthdate	claim.name
63d34945-1938-4294-979c-faa865b999b5	String	jsonType.label
67ae41f5-9570-4775-a9b1-966548dc7c1b	true	userinfo.token.claim
67ae41f5-9570-4775-a9b1-966548dc7c1b	picture	user.attribute
67ae41f5-9570-4775-a9b1-966548dc7c1b	true	id.token.claim
67ae41f5-9570-4775-a9b1-966548dc7c1b	true	access.token.claim
67ae41f5-9570-4775-a9b1-966548dc7c1b	picture	claim.name
67ae41f5-9570-4775-a9b1-966548dc7c1b	String	jsonType.label
6b1d4c5e-d809-4df9-ab66-dd50b5633490	true	userinfo.token.claim
6b1d4c5e-d809-4df9-ab66-dd50b5633490	firstName	user.attribute
6b1d4c5e-d809-4df9-ab66-dd50b5633490	true	id.token.claim
6b1d4c5e-d809-4df9-ab66-dd50b5633490	true	access.token.claim
6b1d4c5e-d809-4df9-ab66-dd50b5633490	given_name	claim.name
6b1d4c5e-d809-4df9-ab66-dd50b5633490	String	jsonType.label
7a6d50a3-7a34-42b2-9215-94b9fa75f1e6	true	userinfo.token.claim
7a6d50a3-7a34-42b2-9215-94b9fa75f1e6	locale	user.attribute
7a6d50a3-7a34-42b2-9215-94b9fa75f1e6	true	id.token.claim
7a6d50a3-7a34-42b2-9215-94b9fa75f1e6	true	access.token.claim
7a6d50a3-7a34-42b2-9215-94b9fa75f1e6	locale	claim.name
7a6d50a3-7a34-42b2-9215-94b9fa75f1e6	String	jsonType.label
c378aa55-b799-4bf1-ab6b-5b5103314db1	true	userinfo.token.claim
c378aa55-b799-4bf1-ab6b-5b5103314db1	website	user.attribute
c378aa55-b799-4bf1-ab6b-5b5103314db1	true	id.token.claim
c378aa55-b799-4bf1-ab6b-5b5103314db1	true	access.token.claim
c378aa55-b799-4bf1-ab6b-5b5103314db1	website	claim.name
c378aa55-b799-4bf1-ab6b-5b5103314db1	String	jsonType.label
d7114b31-0969-4c51-9616-4b7c7238d171	true	userinfo.token.claim
d7114b31-0969-4c51-9616-4b7c7238d171	true	id.token.claim
d7114b31-0969-4c51-9616-4b7c7238d171	true	access.token.claim
e0f3fae2-cb8c-4f4b-90f1-5b69d8ffd7eb	true	userinfo.token.claim
e0f3fae2-cb8c-4f4b-90f1-5b69d8ffd7eb	lastName	user.attribute
e0f3fae2-cb8c-4f4b-90f1-5b69d8ffd7eb	true	id.token.claim
e0f3fae2-cb8c-4f4b-90f1-5b69d8ffd7eb	true	access.token.claim
e0f3fae2-cb8c-4f4b-90f1-5b69d8ffd7eb	family_name	claim.name
e0f3fae2-cb8c-4f4b-90f1-5b69d8ffd7eb	String	jsonType.label
e42f3c6a-3460-4ff2-99c6-d5ce2bb07f93	true	userinfo.token.claim
e42f3c6a-3460-4ff2-99c6-d5ce2bb07f93	zoneinfo	user.attribute
e42f3c6a-3460-4ff2-99c6-d5ce2bb07f93	true	id.token.claim
e42f3c6a-3460-4ff2-99c6-d5ce2bb07f93	true	access.token.claim
e42f3c6a-3460-4ff2-99c6-d5ce2bb07f93	zoneinfo	claim.name
e42f3c6a-3460-4ff2-99c6-d5ce2bb07f93	String	jsonType.label
318f9e90-499d-4be7-841c-913875195fba	true	userinfo.token.claim
318f9e90-499d-4be7-841c-913875195fba	email	user.attribute
318f9e90-499d-4be7-841c-913875195fba	true	id.token.claim
318f9e90-499d-4be7-841c-913875195fba	true	access.token.claim
318f9e90-499d-4be7-841c-913875195fba	email	claim.name
318f9e90-499d-4be7-841c-913875195fba	String	jsonType.label
d7248f25-31dc-40ba-a108-b52a800d6caa	true	userinfo.token.claim
d7248f25-31dc-40ba-a108-b52a800d6caa	emailVerified	user.attribute
d7248f25-31dc-40ba-a108-b52a800d6caa	true	id.token.claim
d7248f25-31dc-40ba-a108-b52a800d6caa	true	access.token.claim
d7248f25-31dc-40ba-a108-b52a800d6caa	email_verified	claim.name
d7248f25-31dc-40ba-a108-b52a800d6caa	boolean	jsonType.label
8416988d-3465-42cb-9fb3-4df06a6ec21d	formatted	user.attribute.formatted
8416988d-3465-42cb-9fb3-4df06a6ec21d	country	user.attribute.country
8416988d-3465-42cb-9fb3-4df06a6ec21d	postal_code	user.attribute.postal_code
8416988d-3465-42cb-9fb3-4df06a6ec21d	true	userinfo.token.claim
8416988d-3465-42cb-9fb3-4df06a6ec21d	street	user.attribute.street
8416988d-3465-42cb-9fb3-4df06a6ec21d	true	id.token.claim
8416988d-3465-42cb-9fb3-4df06a6ec21d	region	user.attribute.region
8416988d-3465-42cb-9fb3-4df06a6ec21d	true	access.token.claim
8416988d-3465-42cb-9fb3-4df06a6ec21d	locality	user.attribute.locality
26ab193e-9aaf-4bc9-b796-ee2879194b54	true	userinfo.token.claim
26ab193e-9aaf-4bc9-b796-ee2879194b54	phoneNumber	user.attribute
26ab193e-9aaf-4bc9-b796-ee2879194b54	true	id.token.claim
26ab193e-9aaf-4bc9-b796-ee2879194b54	true	access.token.claim
26ab193e-9aaf-4bc9-b796-ee2879194b54	phone_number	claim.name
26ab193e-9aaf-4bc9-b796-ee2879194b54	String	jsonType.label
a0cf73db-6690-4bcf-a9e6-e0494b5cbe4e	true	userinfo.token.claim
a0cf73db-6690-4bcf-a9e6-e0494b5cbe4e	phoneNumberVerified	user.attribute
a0cf73db-6690-4bcf-a9e6-e0494b5cbe4e	true	id.token.claim
a0cf73db-6690-4bcf-a9e6-e0494b5cbe4e	true	access.token.claim
a0cf73db-6690-4bcf-a9e6-e0494b5cbe4e	phone_number_verified	claim.name
a0cf73db-6690-4bcf-a9e6-e0494b5cbe4e	boolean	jsonType.label
bff49245-7c69-47b2-908d-da0ab847f1f5	true	multivalued
bff49245-7c69-47b2-908d-da0ab847f1f5	foo	user.attribute
bff49245-7c69-47b2-908d-da0ab847f1f5	true	access.token.claim
bff49245-7c69-47b2-908d-da0ab847f1f5	realm_access.roles	claim.name
bff49245-7c69-47b2-908d-da0ab847f1f5	String	jsonType.label
de955c0e-cbca-4af9-8707-988bda929fe1	true	multivalued
de955c0e-cbca-4af9-8707-988bda929fe1	foo	user.attribute
de955c0e-cbca-4af9-8707-988bda929fe1	true	access.token.claim
de955c0e-cbca-4af9-8707-988bda929fe1	resource_access.${client_id}.roles	claim.name
de955c0e-cbca-4af9-8707-988bda929fe1	String	jsonType.label
2de8cb34-356e-4999-aef1-8b95f9c20f02	true	userinfo.token.claim
2de8cb34-356e-4999-aef1-8b95f9c20f02	username	user.attribute
2de8cb34-356e-4999-aef1-8b95f9c20f02	true	id.token.claim
2de8cb34-356e-4999-aef1-8b95f9c20f02	true	access.token.claim
2de8cb34-356e-4999-aef1-8b95f9c20f02	upn	claim.name
2de8cb34-356e-4999-aef1-8b95f9c20f02	String	jsonType.label
72066df6-0046-43c3-bec4-bad96e1b718c	true	multivalued
72066df6-0046-43c3-bec4-bad96e1b718c	foo	user.attribute
72066df6-0046-43c3-bec4-bad96e1b718c	true	id.token.claim
72066df6-0046-43c3-bec4-bad96e1b718c	true	access.token.claim
72066df6-0046-43c3-bec4-bad96e1b718c	groups	claim.name
72066df6-0046-43c3-bec4-bad96e1b718c	String	jsonType.label
8ea48f2f-b53f-48ce-b48e-6d8c0cf3977c	true	id.token.claim
8ea48f2f-b53f-48ce-b48e-6d8c0cf3977c	true	access.token.claim
48f10c48-a1eb-4190-9006-a2a86528d54e	false	single
48f10c48-a1eb-4190-9006-a2a86528d54e	Basic	attribute.nameformat
48f10c48-a1eb-4190-9006-a2a86528d54e	Role	attribute.name
08d88467-7147-4f71-a5de-8cd0db71a4ad	true	userinfo.token.claim
08d88467-7147-4f71-a5de-8cd0db71a4ad	gender	user.attribute
08d88467-7147-4f71-a5de-8cd0db71a4ad	true	id.token.claim
08d88467-7147-4f71-a5de-8cd0db71a4ad	true	access.token.claim
08d88467-7147-4f71-a5de-8cd0db71a4ad	gender	claim.name
08d88467-7147-4f71-a5de-8cd0db71a4ad	String	jsonType.label
291a54a9-683a-4da6-97c4-07c370bbed1f	true	userinfo.token.claim
291a54a9-683a-4da6-97c4-07c370bbed1f	username	user.attribute
291a54a9-683a-4da6-97c4-07c370bbed1f	true	id.token.claim
291a54a9-683a-4da6-97c4-07c370bbed1f	true	access.token.claim
291a54a9-683a-4da6-97c4-07c370bbed1f	preferred_username	claim.name
291a54a9-683a-4da6-97c4-07c370bbed1f	String	jsonType.label
2fb112ba-8b5d-46e8-8d3e-d45f55d6d580	true	userinfo.token.claim
2fb112ba-8b5d-46e8-8d3e-d45f55d6d580	nickname	user.attribute
2fb112ba-8b5d-46e8-8d3e-d45f55d6d580	true	id.token.claim
2fb112ba-8b5d-46e8-8d3e-d45f55d6d580	true	access.token.claim
2fb112ba-8b5d-46e8-8d3e-d45f55d6d580	nickname	claim.name
2fb112ba-8b5d-46e8-8d3e-d45f55d6d580	String	jsonType.label
48ecfbfb-8d10-4bf1-bfd6-83c8f37bf315	true	userinfo.token.claim
48ecfbfb-8d10-4bf1-bfd6-83c8f37bf315	updatedAt	user.attribute
48ecfbfb-8d10-4bf1-bfd6-83c8f37bf315	true	id.token.claim
48ecfbfb-8d10-4bf1-bfd6-83c8f37bf315	true	access.token.claim
48ecfbfb-8d10-4bf1-bfd6-83c8f37bf315	updated_at	claim.name
48ecfbfb-8d10-4bf1-bfd6-83c8f37bf315	long	jsonType.label
4fa8e70c-6da3-4523-b87e-40ab85a13b71	true	userinfo.token.claim
4fa8e70c-6da3-4523-b87e-40ab85a13b71	birthdate	user.attribute
4fa8e70c-6da3-4523-b87e-40ab85a13b71	true	id.token.claim
4fa8e70c-6da3-4523-b87e-40ab85a13b71	true	access.token.claim
4fa8e70c-6da3-4523-b87e-40ab85a13b71	birthdate	claim.name
4fa8e70c-6da3-4523-b87e-40ab85a13b71	String	jsonType.label
555c3aa4-c1f9-4449-bab9-b113ed6278c4	true	userinfo.token.claim
555c3aa4-c1f9-4449-bab9-b113ed6278c4	locale	user.attribute
555c3aa4-c1f9-4449-bab9-b113ed6278c4	true	id.token.claim
555c3aa4-c1f9-4449-bab9-b113ed6278c4	true	access.token.claim
555c3aa4-c1f9-4449-bab9-b113ed6278c4	locale	claim.name
555c3aa4-c1f9-4449-bab9-b113ed6278c4	String	jsonType.label
5c2b1415-af43-4e1e-a3f4-7d11b12f3da5	true	userinfo.token.claim
5c2b1415-af43-4e1e-a3f4-7d11b12f3da5	middleName	user.attribute
5c2b1415-af43-4e1e-a3f4-7d11b12f3da5	true	id.token.claim
5c2b1415-af43-4e1e-a3f4-7d11b12f3da5	true	access.token.claim
5c2b1415-af43-4e1e-a3f4-7d11b12f3da5	middle_name	claim.name
5c2b1415-af43-4e1e-a3f4-7d11b12f3da5	String	jsonType.label
9a993084-3cb8-426a-9616-f32b711b8d2b	true	id.token.claim
9a993084-3cb8-426a-9616-f32b711b8d2b	true	access.token.claim
9a993084-3cb8-426a-9616-f32b711b8d2b	true	userinfo.token.claim
b9f74f64-bf8e-4380-93a1-98d9366d178e	true	userinfo.token.claim
b9f74f64-bf8e-4380-93a1-98d9366d178e	website	user.attribute
b9f74f64-bf8e-4380-93a1-98d9366d178e	true	id.token.claim
b9f74f64-bf8e-4380-93a1-98d9366d178e	true	access.token.claim
b9f74f64-bf8e-4380-93a1-98d9366d178e	website	claim.name
b9f74f64-bf8e-4380-93a1-98d9366d178e	String	jsonType.label
ca6e454a-471b-4d8f-917b-b7e21ec360a5	true	userinfo.token.claim
ca6e454a-471b-4d8f-917b-b7e21ec360a5	firstName	user.attribute
ca6e454a-471b-4d8f-917b-b7e21ec360a5	true	id.token.claim
ca6e454a-471b-4d8f-917b-b7e21ec360a5	true	access.token.claim
ca6e454a-471b-4d8f-917b-b7e21ec360a5	given_name	claim.name
ca6e454a-471b-4d8f-917b-b7e21ec360a5	String	jsonType.label
d87024a0-7d50-4c60-9ed1-c3356257e011	true	userinfo.token.claim
d87024a0-7d50-4c60-9ed1-c3356257e011	zoneinfo	user.attribute
d87024a0-7d50-4c60-9ed1-c3356257e011	true	id.token.claim
d87024a0-7d50-4c60-9ed1-c3356257e011	true	access.token.claim
d87024a0-7d50-4c60-9ed1-c3356257e011	zoneinfo	claim.name
d87024a0-7d50-4c60-9ed1-c3356257e011	String	jsonType.label
da47791f-268e-4b96-ad29-dadcd69203ae	true	userinfo.token.claim
da47791f-268e-4b96-ad29-dadcd69203ae	profile	user.attribute
da47791f-268e-4b96-ad29-dadcd69203ae	true	id.token.claim
da47791f-268e-4b96-ad29-dadcd69203ae	true	access.token.claim
da47791f-268e-4b96-ad29-dadcd69203ae	profile	claim.name
da47791f-268e-4b96-ad29-dadcd69203ae	String	jsonType.label
e5e1fc29-2bde-48f0-8672-897b823a96bd	true	userinfo.token.claim
e5e1fc29-2bde-48f0-8672-897b823a96bd	lastName	user.attribute
e5e1fc29-2bde-48f0-8672-897b823a96bd	true	id.token.claim
e5e1fc29-2bde-48f0-8672-897b823a96bd	true	access.token.claim
e5e1fc29-2bde-48f0-8672-897b823a96bd	family_name	claim.name
e5e1fc29-2bde-48f0-8672-897b823a96bd	String	jsonType.label
fca41784-bcd0-49b6-b0d6-2e9280080b5d	true	userinfo.token.claim
fca41784-bcd0-49b6-b0d6-2e9280080b5d	picture	user.attribute
fca41784-bcd0-49b6-b0d6-2e9280080b5d	true	id.token.claim
fca41784-bcd0-49b6-b0d6-2e9280080b5d	true	access.token.claim
fca41784-bcd0-49b6-b0d6-2e9280080b5d	picture	claim.name
fca41784-bcd0-49b6-b0d6-2e9280080b5d	String	jsonType.label
a244df25-66e3-4286-b10d-7e93c601fbfb	true	userinfo.token.claim
a244df25-66e3-4286-b10d-7e93c601fbfb	email	user.attribute
a244df25-66e3-4286-b10d-7e93c601fbfb	true	id.token.claim
a244df25-66e3-4286-b10d-7e93c601fbfb	true	access.token.claim
a244df25-66e3-4286-b10d-7e93c601fbfb	email	claim.name
a244df25-66e3-4286-b10d-7e93c601fbfb	String	jsonType.label
d5e4d45d-d6f1-4725-85c6-a95466fa1208	true	userinfo.token.claim
d5e4d45d-d6f1-4725-85c6-a95466fa1208	emailVerified	user.attribute
d5e4d45d-d6f1-4725-85c6-a95466fa1208	true	id.token.claim
d5e4d45d-d6f1-4725-85c6-a95466fa1208	true	access.token.claim
d5e4d45d-d6f1-4725-85c6-a95466fa1208	email_verified	claim.name
d5e4d45d-d6f1-4725-85c6-a95466fa1208	boolean	jsonType.label
8a5825b3-ccc6-4a2f-b2e0-bd45630a9735	true	multivalued
8a5825b3-ccc6-4a2f-b2e0-bd45630a9735	true	userinfo.token.claim
8a5825b3-ccc6-4a2f-b2e0-bd45630a9735	foo	user.attribute
8a5825b3-ccc6-4a2f-b2e0-bd45630a9735	true	id.token.claim
8a5825b3-ccc6-4a2f-b2e0-bd45630a9735	true	access.token.claim
8a5825b3-ccc6-4a2f-b2e0-bd45630a9735	groups	claim.name
8a5825b3-ccc6-4a2f-b2e0-bd45630a9735	String	jsonType.label
f8d9c778-6fa9-4643-934a-85b7dcf706db	true	userinfo.token.claim
f8d9c778-6fa9-4643-934a-85b7dcf706db	username	user.attribute
f8d9c778-6fa9-4643-934a-85b7dcf706db	true	id.token.claim
f8d9c778-6fa9-4643-934a-85b7dcf706db	true	access.token.claim
f8d9c778-6fa9-4643-934a-85b7dcf706db	upn	claim.name
f8d9c778-6fa9-4643-934a-85b7dcf706db	String	jsonType.label
85a03ee2-ad64-4bcd-a670-97ce732206a4	foo	user.attribute
85a03ee2-ad64-4bcd-a670-97ce732206a4	true	access.token.claim
85a03ee2-ad64-4bcd-a670-97ce732206a4	realm_access.roles	claim.name
85a03ee2-ad64-4bcd-a670-97ce732206a4	String	jsonType.label
85a03ee2-ad64-4bcd-a670-97ce732206a4	true	multivalued
bd4a56c1-0a6f-4723-b90e-3a8cf46804a6	foo	user.attribute
bd4a56c1-0a6f-4723-b90e-3a8cf46804a6	true	access.token.claim
bd4a56c1-0a6f-4723-b90e-3a8cf46804a6	resource_access.${client_id}.roles	claim.name
bd4a56c1-0a6f-4723-b90e-3a8cf46804a6	String	jsonType.label
bd4a56c1-0a6f-4723-b90e-3a8cf46804a6	true	multivalued
ce20f8ef-7eaa-4a93-82ab-4c4f539cd06d	true	id.token.claim
ce20f8ef-7eaa-4a93-82ab-4c4f539cd06d	true	access.token.claim
ce20f8ef-7eaa-4a93-82ab-4c4f539cd06d	true	userinfo.token.claim
0ef79314-0409-4d7b-b0fa-60ea85b1e448	formatted	user.attribute.formatted
0ef79314-0409-4d7b-b0fa-60ea85b1e448	country	user.attribute.country
0ef79314-0409-4d7b-b0fa-60ea85b1e448	postal_code	user.attribute.postal_code
0ef79314-0409-4d7b-b0fa-60ea85b1e448	true	userinfo.token.claim
0ef79314-0409-4d7b-b0fa-60ea85b1e448	street	user.attribute.street
0ef79314-0409-4d7b-b0fa-60ea85b1e448	true	id.token.claim
0ef79314-0409-4d7b-b0fa-60ea85b1e448	region	user.attribute.region
0ef79314-0409-4d7b-b0fa-60ea85b1e448	true	access.token.claim
0ef79314-0409-4d7b-b0fa-60ea85b1e448	locality	user.attribute.locality
311f5686-f4a0-425f-91c3-3f11caadb883	true	userinfo.token.claim
311f5686-f4a0-425f-91c3-3f11caadb883	phoneNumberVerified	user.attribute
311f5686-f4a0-425f-91c3-3f11caadb883	true	id.token.claim
311f5686-f4a0-425f-91c3-3f11caadb883	true	access.token.claim
311f5686-f4a0-425f-91c3-3f11caadb883	phone_number_verified	claim.name
311f5686-f4a0-425f-91c3-3f11caadb883	boolean	jsonType.label
57b2dcd4-2c8e-43f4-8b04-9955cf9faa07	true	userinfo.token.claim
57b2dcd4-2c8e-43f4-8b04-9955cf9faa07	phoneNumber	user.attribute
57b2dcd4-2c8e-43f4-8b04-9955cf9faa07	true	id.token.claim
57b2dcd4-2c8e-43f4-8b04-9955cf9faa07	true	access.token.claim
57b2dcd4-2c8e-43f4-8b04-9955cf9faa07	phone_number	claim.name
57b2dcd4-2c8e-43f4-8b04-9955cf9faa07	String	jsonType.label
496ffe94-7528-4761-b4cf-c61faf0f3969	true	userinfo.token.claim
496ffe94-7528-4761-b4cf-c61faf0f3969	locale	user.attribute
496ffe94-7528-4761-b4cf-c61faf0f3969	true	id.token.claim
496ffe94-7528-4761-b4cf-c61faf0f3969	true	access.token.claim
496ffe94-7528-4761-b4cf-c61faf0f3969	locale	claim.name
496ffe94-7528-4761-b4cf-c61faf0f3969	String	jsonType.label
9ca46f6c-8a35-4e17-9007-4b7d81e82fc0	client_id	user.session.note
9ca46f6c-8a35-4e17-9007-4b7d81e82fc0	true	id.token.claim
9ca46f6c-8a35-4e17-9007-4b7d81e82fc0	true	access.token.claim
9ca46f6c-8a35-4e17-9007-4b7d81e82fc0	client_id	claim.name
9ca46f6c-8a35-4e17-9007-4b7d81e82fc0	String	jsonType.label
9fdba0ca-20c4-4631-aa45-8e86774ff2b6	clientHost	user.session.note
9fdba0ca-20c4-4631-aa45-8e86774ff2b6	true	id.token.claim
9fdba0ca-20c4-4631-aa45-8e86774ff2b6	true	access.token.claim
9fdba0ca-20c4-4631-aa45-8e86774ff2b6	clientHost	claim.name
9fdba0ca-20c4-4631-aa45-8e86774ff2b6	String	jsonType.label
ca073786-4e26-483d-9f54-f29ad62c7518	clientAddress	user.session.note
ca073786-4e26-483d-9f54-f29ad62c7518	true	id.token.claim
ca073786-4e26-483d-9f54-f29ad62c7518	true	access.token.claim
ca073786-4e26-483d-9f54-f29ad62c7518	clientAddress	claim.name
ca073786-4e26-483d-9f54-f29ad62c7518	String	jsonType.label
c2a718a7-cd09-493e-81cc-b76cede325df	foo	user.attribute
c2a718a7-cd09-493e-81cc-b76cede325df	true	access.token.claim
c2a718a7-cd09-493e-81cc-b76cede325df	realm_access.roles	claim.name
c2a718a7-cd09-493e-81cc-b76cede325df	String	jsonType.label
c2a718a7-cd09-493e-81cc-b76cede325df	true	multivalued
c2a718a7-cd09-493e-81cc-b76cede325df	false	userinfo.token.claim
c2a718a7-cd09-493e-81cc-b76cede325df	false	id.token.claim
b8935d4b-4f6b-4e2d-bba5-0c01dd918d35	foo	user.attribute
b8935d4b-4f6b-4e2d-bba5-0c01dd918d35	true	access.token.claim
b8935d4b-4f6b-4e2d-bba5-0c01dd918d35	resource_access.${client_id}.roles	claim.name
b8935d4b-4f6b-4e2d-bba5-0c01dd918d35	String	jsonType.label
b8935d4b-4f6b-4e2d-bba5-0c01dd918d35	true	multivalued
b8935d4b-4f6b-4e2d-bba5-0c01dd918d35	false	userinfo.token.claim
b8935d4b-4f6b-4e2d-bba5-0c01dd918d35	false	id.token.claim
77113c7c-f386-480a-a597-39bcd544d64a	clientAddress	user.session.note
77113c7c-f386-480a-a597-39bcd544d64a	true	id.token.claim
77113c7c-f386-480a-a597-39bcd544d64a	true	access.token.claim
77113c7c-f386-480a-a597-39bcd544d64a	clientAddress	claim.name
77113c7c-f386-480a-a597-39bcd544d64a	String	jsonType.label
7a4b38ad-f96a-4a80-85bf-59084cbffcc4	clientHost	user.session.note
7a4b38ad-f96a-4a80-85bf-59084cbffcc4	true	id.token.claim
7a4b38ad-f96a-4a80-85bf-59084cbffcc4	true	access.token.claim
7a4b38ad-f96a-4a80-85bf-59084cbffcc4	clientHost	claim.name
7a4b38ad-f96a-4a80-85bf-59084cbffcc4	String	jsonType.label
cb1fe3a0-e67a-4eae-9a64-d817c30f4923	client_id	user.session.note
cb1fe3a0-e67a-4eae-9a64-d817c30f4923	true	id.token.claim
cb1fe3a0-e67a-4eae-9a64-d817c30f4923	true	access.token.claim
cb1fe3a0-e67a-4eae-9a64-d817c30f4923	client_id	claim.name
cb1fe3a0-e67a-4eae-9a64-d817c30f4923	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
69219f75-5959-4178-a860-0ae90853470b	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	37acefbe-975b-430e-b49e-8cb54f9e6a7f	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	d8a7a3e4-d406-4507-9868-91c9117b4caa	069e58b3-781b-44a8-bb7e-436ec20710d6	2bec55b0-439b-4101-876d-168ee196f42a	486ef05e-c701-460b-bc5b-ecd16cfde9b6	f87c0951-6f71-47fe-9ff3-30b469c4eb2d	2592000	f	900	t	f	46bbeac2-5dbb-4e92-9a3d-cbab842c8e48	0	f	0	0	e5f45988-c3b0-480e-bb01-aee1769ae71e
2d41d0c8-a7ac-4cdc-b114-4baf577da237	60	300	120				t	f	0	customtheme	aad	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	c13748c9-1aea-461a-bc5e-9a1fb7a9fd52	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	e5bb4c58-afbf-446a-9b29-2bd461e788bd	0586966e-4ef5-4874-8286-509f5f6c93ee	a9d873c2-73a1-4f1b-a565-7e1dcab6b1cc	04b71a86-1a66-4cb2-8518-ae68209084da	bb432a90-61f9-4852-ae3b-3fb9819b95f5	2592000	f	120	f	f	4417fff2-662e-4178-8659-b359d6df1601	0	f	86400	86400	c59dba83-3f47-47d1-acbb-3feaf4c55643
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	69219f75-5959-4178-a860-0ae90853470b	
_browser_header.xContentTypeOptions	69219f75-5959-4178-a860-0ae90853470b	nosniff
_browser_header.referrerPolicy	69219f75-5959-4178-a860-0ae90853470b	no-referrer
_browser_header.xRobotsTag	69219f75-5959-4178-a860-0ae90853470b	none
_browser_header.xFrameOptions	69219f75-5959-4178-a860-0ae90853470b	SAMEORIGIN
_browser_header.contentSecurityPolicy	69219f75-5959-4178-a860-0ae90853470b	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	69219f75-5959-4178-a860-0ae90853470b	1; mode=block
_browser_header.strictTransportSecurity	69219f75-5959-4178-a860-0ae90853470b	max-age=31536000; includeSubDomains
bruteForceProtected	69219f75-5959-4178-a860-0ae90853470b	false
permanentLockout	69219f75-5959-4178-a860-0ae90853470b	false
maxFailureWaitSeconds	69219f75-5959-4178-a860-0ae90853470b	900
minimumQuickLoginWaitSeconds	69219f75-5959-4178-a860-0ae90853470b	60
waitIncrementSeconds	69219f75-5959-4178-a860-0ae90853470b	60
quickLoginCheckMilliSeconds	69219f75-5959-4178-a860-0ae90853470b	1000
maxDeltaTimeSeconds	69219f75-5959-4178-a860-0ae90853470b	43200
failureFactor	69219f75-5959-4178-a860-0ae90853470b	30
realmReusableOtpCode	69219f75-5959-4178-a860-0ae90853470b	false
displayName	69219f75-5959-4178-a860-0ae90853470b	Keycloak
displayNameHtml	69219f75-5959-4178-a860-0ae90853470b	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	69219f75-5959-4178-a860-0ae90853470b	RS256
offlineSessionMaxLifespanEnabled	69219f75-5959-4178-a860-0ae90853470b	false
offlineSessionMaxLifespan	69219f75-5959-4178-a860-0ae90853470b	5184000
userProfileEnabled	2d41d0c8-a7ac-4cdc-b114-4baf577da237	false
acr.loa.map	2d41d0c8-a7ac-4cdc-b114-4baf577da237	{}
realmReusableOtpCode	2d41d0c8-a7ac-4cdc-b114-4baf577da237	false
clientOfflineSessionIdleTimeout	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0
clientOfflineSessionMaxLifespan	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0
oauth2DeviceCodeLifespan	2d41d0c8-a7ac-4cdc-b114-4baf577da237	600
oauth2DevicePollingInterval	2d41d0c8-a7ac-4cdc-b114-4baf577da237	5
cibaBackchannelTokenDeliveryMode	2d41d0c8-a7ac-4cdc-b114-4baf577da237	poll
cibaExpiresIn	2d41d0c8-a7ac-4cdc-b114-4baf577da237	120
cibaInterval	2d41d0c8-a7ac-4cdc-b114-4baf577da237	5
cibaAuthRequestedUserHint	2d41d0c8-a7ac-4cdc-b114-4baf577da237	login_hint
parRequestUriLifespan	2d41d0c8-a7ac-4cdc-b114-4baf577da237	60
frontendUrl	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
shortVerificationUri	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
actionTokenGeneratedByUserLifespan-verify-email	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
actionTokenGeneratedByUserLifespan-idp-verify-account-via-email	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
actionTokenGeneratedByUserLifespan-reset-credentials	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
actionTokenGeneratedByUserLifespan-execute-actions	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
clientSessionIdleTimeout	2d41d0c8-a7ac-4cdc-b114-4baf577da237	300
clientSessionMaxLifespan	2d41d0c8-a7ac-4cdc-b114-4baf577da237	86400
displayName	2d41d0c8-a7ac-4cdc-b114-4baf577da237	Keycloak
displayNameHtml	2d41d0c8-a7ac-4cdc-b114-4baf577da237	<div class="kc-logo-text"><span>Keycloak</span></div>
bruteForceProtected	2d41d0c8-a7ac-4cdc-b114-4baf577da237	false
permanentLockout	2d41d0c8-a7ac-4cdc-b114-4baf577da237	false
maxFailureWaitSeconds	2d41d0c8-a7ac-4cdc-b114-4baf577da237	900
minimumQuickLoginWaitSeconds	2d41d0c8-a7ac-4cdc-b114-4baf577da237	60
waitIncrementSeconds	2d41d0c8-a7ac-4cdc-b114-4baf577da237	60
quickLoginCheckMilliSeconds	2d41d0c8-a7ac-4cdc-b114-4baf577da237	1000
maxDeltaTimeSeconds	2d41d0c8-a7ac-4cdc-b114-4baf577da237	43200
failureFactor	2d41d0c8-a7ac-4cdc-b114-4baf577da237	30
actionTokenGeneratedByAdminLifespan	2d41d0c8-a7ac-4cdc-b114-4baf577da237	43200
actionTokenGeneratedByUserLifespan	2d41d0c8-a7ac-4cdc-b114-4baf577da237	300
defaultSignatureAlgorithm	2d41d0c8-a7ac-4cdc-b114-4baf577da237	RS256
offlineSessionMaxLifespanEnabled	2d41d0c8-a7ac-4cdc-b114-4baf577da237	false
offlineSessionMaxLifespan	2d41d0c8-a7ac-4cdc-b114-4baf577da237	5184000
webAuthnPolicyRpEntityName	2d41d0c8-a7ac-4cdc-b114-4baf577da237	keycloak
webAuthnPolicySignatureAlgorithms	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ES256
webAuthnPolicyRpId	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
webAuthnPolicyAttestationConveyancePreference	2d41d0c8-a7ac-4cdc-b114-4baf577da237	not specified
webAuthnPolicyAuthenticatorAttachment	2d41d0c8-a7ac-4cdc-b114-4baf577da237	not specified
webAuthnPolicyRequireResidentKey	2d41d0c8-a7ac-4cdc-b114-4baf577da237	not specified
webAuthnPolicyUserVerificationRequirement	2d41d0c8-a7ac-4cdc-b114-4baf577da237	not specified
webAuthnPolicyCreateTimeout	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0
webAuthnPolicyAvoidSameAuthenticatorRegister	2d41d0c8-a7ac-4cdc-b114-4baf577da237	false
webAuthnPolicyRpEntityNamePasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	ES256
webAuthnPolicyRpIdPasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
webAuthnPolicyAttestationConveyancePreferencePasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	not specified
webAuthnPolicyRequireResidentKeyPasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	not specified
webAuthnPolicyCreateTimeoutPasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	false
client-policies.profiles	2d41d0c8-a7ac-4cdc-b114-4baf577da237	{"profiles":[]}
client-policies.policies	2d41d0c8-a7ac-4cdc-b114-4baf577da237	{"policies":[]}
_browser_header.contentSecurityPolicyReportOnly	2d41d0c8-a7ac-4cdc-b114-4baf577da237	
_browser_header.xContentTypeOptions	2d41d0c8-a7ac-4cdc-b114-4baf577da237	nosniff
_browser_header.referrerPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	no-referrer
_browser_header.xRobotsTag	2d41d0c8-a7ac-4cdc-b114-4baf577da237	none
_browser_header.xFrameOptions	2d41d0c8-a7ac-4cdc-b114-4baf577da237	SAMEORIGIN
_browser_header.contentSecurityPolicy	2d41d0c8-a7ac-4cdc-b114-4baf577da237	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	2d41d0c8-a7ac-4cdc-b114-4baf577da237	1; mode=block
_browser_header.strictTransportSecurity	2d41d0c8-a7ac-4cdc-b114-4baf577da237	max-age=31536000; includeSubDomains
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
69219f75-5959-4178-a860-0ae90853470b	jboss-logging
2d41d0c8-a7ac-4cdc-b114-4baf577da237	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	69219f75-5959-4178-a860-0ae90853470b
password	password	t	t	2d41d0c8-a7ac-4cdc-b114-4baf577da237
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.redirect_uris (client_id, value) FROM stdin;
5fa4638a-51f2-4b9f-96c2-5c5ab88c07a1	/realms/master/account/*
07482b6a-2476-4033-af31-9d6ac30697af	/realms/master/account/*
3cd83037-98f6-44da-be80-73f9e77a3d39	/admin/master/console/*
701a3ada-3c87-42d9-bfc2-710bc231c878	/admin/aad/console/*
512c74b9-7b68-42e2-962e-0d6507f71cd1	/realms/aad/account/*
312930c6-3b4a-492f-9f52-bf0947d8c4e5	/realms/aad/account/*
4042690c-33d1-4e1b-acf7-9ba58ce60da0	*
b467a243-0187-4bb7-8dcb-05d03fe39aec	
b467a243-0187-4bb7-8dcb-05d03fe39aec	http://localhost:3000/*
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	/*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
c561e7e1-c4be-4bb5-808f-aaf0114b8c64	VERIFY_EMAIL	Verify Email	69219f75-5959-4178-a860-0ae90853470b	t	f	VERIFY_EMAIL	50
bf81fbe8-4797-4163-80d9-297478afc13e	UPDATE_PROFILE	Update Profile	69219f75-5959-4178-a860-0ae90853470b	t	f	UPDATE_PROFILE	40
cde7485b-0110-45a8-8da2-81cbd88e1175	CONFIGURE_TOTP	Configure OTP	69219f75-5959-4178-a860-0ae90853470b	t	f	CONFIGURE_TOTP	10
e6c33078-f035-4428-a69e-34ad656e230f	UPDATE_PASSWORD	Update Password	69219f75-5959-4178-a860-0ae90853470b	t	f	UPDATE_PASSWORD	30
f719c066-cfbf-4c86-a088-77a1dae6fe39	TERMS_AND_CONDITIONS	Terms and Conditions	69219f75-5959-4178-a860-0ae90853470b	f	f	TERMS_AND_CONDITIONS	20
a29a28c7-277f-4eee-ac9d-c3c0ebef53b2	delete_account	Delete Account	69219f75-5959-4178-a860-0ae90853470b	f	f	delete_account	60
8187742a-1322-47cf-93ad-b87443be59f7	update_user_locale	Update User Locale	69219f75-5959-4178-a860-0ae90853470b	t	f	update_user_locale	1000
7bd155f0-36fd-4349-a212-a85e6554eb15	UPDATE_EMAIL	Update Email	69219f75-5959-4178-a860-0ae90853470b	t	f	UPDATE_EMAIL	70
fc362dfa-080f-436b-80ac-c8d182870af7	CONFIGURE_RECOVERY_AUTHN_CODES	Recovery Authentication Codes	69219f75-5959-4178-a860-0ae90853470b	t	f	CONFIGURE_RECOVERY_AUTHN_CODES	70
55cd9340-79f4-442f-a890-633679444f77	webauthn-register	Webauthn Register	69219f75-5959-4178-a860-0ae90853470b	t	f	webauthn-register	70
d1ce6351-a33f-42ab-81bd-a9fc902aaa4e	webauthn-register-passwordless	Webauthn Register Passwordless	69219f75-5959-4178-a860-0ae90853470b	t	f	webauthn-register-passwordless	80
d01c9444-fe41-4208-943c-1b1399363c2a	CONFIGURE_TOTP	Configure OTP	2d41d0c8-a7ac-4cdc-b114-4baf577da237	t	f	CONFIGURE_TOTP	10
8d2fd039-705f-4137-a286-edc6513d8204	TERMS_AND_CONDITIONS	Terms and Conditions	2d41d0c8-a7ac-4cdc-b114-4baf577da237	f	f	TERMS_AND_CONDITIONS	20
7a5c0c04-6293-4927-a957-716db19cfb44	UPDATE_PASSWORD	Update Password	2d41d0c8-a7ac-4cdc-b114-4baf577da237	t	f	UPDATE_PASSWORD	30
e7baf8a1-8fc4-4e87-9bb7-1ee036d710c4	UPDATE_PROFILE	Update Profile	2d41d0c8-a7ac-4cdc-b114-4baf577da237	t	f	UPDATE_PROFILE	40
e46f8243-c821-4a97-b4db-fb8aab9f9cae	VERIFY_EMAIL	Verify Email	2d41d0c8-a7ac-4cdc-b114-4baf577da237	t	f	VERIFY_EMAIL	50
36924476-ca5d-4cb1-ac9b-f12ec6cb252c	delete_account	Delete Account	2d41d0c8-a7ac-4cdc-b114-4baf577da237	f	f	delete_account	60
35d8df65-a46f-4e97-b35c-3406c7eccb3a	webauthn-register	Webauthn Register	2d41d0c8-a7ac-4cdc-b114-4baf577da237	t	f	webauthn-register	70
19437408-da7d-4180-808a-36b839373a94	webauthn-register-passwordless	Webauthn Register Passwordless	2d41d0c8-a7ac-4cdc-b114-4baf577da237	t	f	webauthn-register-passwordless	80
771edd16-87ba-4e17-911a-a3287e01383d	update_user_locale	Update User Locale	2d41d0c8-a7ac-4cdc-b114-4baf577da237	t	f	update_user_locale	1000
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
cf379b7a-5f5e-4001-92fe-91c2dab78442	fc3b6c76-ce9d-4f3b-9803-bd96de5529ed
cf379b7a-5f5e-4001-92fe-91c2dab78442	5a45080a-e4c1-47ca-9633-21e15b714a44
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
cf379b7a-5f5e-4001-92fe-91c2dab78442	4b20b197-b7c6-447d-a7f2-a1cfaf10d53e
cf379b7a-5f5e-4001-92fe-91c2dab78442	04d909c8-c528-41bf-b6f3-6a1390147931
cf379b7a-5f5e-4001-92fe-91c2dab78442	683fbbaa-f34b-4886-bcd3-3cf65fcd7647
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	f	0	1
4042690c-33d1-4e1b-acf7-9ba58ce60da0	t	0	1
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
fc3b6c76-ce9d-4f3b-9803-bd96de5529ed	Networks administration	Allows using all API endpoint across gridcapacity-map networks	scope	1	0	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
1a9c3688-b70a-4ad9-b9a0-ddae742b942c	Administrators group policy	Grants networks access to members of grid-administrators group	group	1	0	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
5a45080a-e4c1-47ca-9633-21e15b714a44	Public networks guest access		scope	1	0	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
3eb93418-25d3-4021-975b-3cb54da81394	Default Policy	A policy that grants access only for users within this realm	js	0	0	4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
cf379b7a-5f5e-4001-92fe-91c2dab78442	networks	urn:network		4042690c-33d1-4e1b-acf7-9ba58ce60da0	4042690c-33d1-4e1b-acf7-9ba58ce60da0	f	Network RESTful API resource
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
0ccd37d0-4c96-4b12-a9ac-41acbab2acae	manage	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
f637766e-2985-40cd-856b-5fbb75c1f530	view	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
41d70059-1230-4dea-9681-30727e56c851	map-roles	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
019bd292-030c-4121-833a-8da3ea79b8ac	map-roles-client-scope	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
dd4ce5d5-6b0c-426a-8d36-2c660bc608d8	map-roles-composite	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
19d5c4ad-91c2-46ad-8516-c2454c9328dc	configure	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
e094f0d2-5907-47c4-b088-e3371ea0ca8f	token-exchange	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
cf21e07c-2745-4068-b436-7f3611c34fcc	map-role	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
eb61c7dd-9774-4512-8de7-177cf3901247	map-role-client-scope	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
8efc8ee1-5d76-44e4-9640-4d1515af37a6	map-role-composite	\N	ecd7c5c7-c26d-43aa-acbb-50e76a88cf2f	\N
4b20b197-b7c6-447d-a7f2-a1cfaf10d53e	net:*		4042690c-33d1-4e1b-acf7-9ba58ce60da0	\N
04d909c8-c528-41bf-b6f3-6a1390147931	net:5b3ed0c7-20d3-45fe-8c3b-84acb64750d3:read		4042690c-33d1-4e1b-acf7-9ba58ce60da0	Read CIM CGMES network data
683fbbaa-f34b-4886-bcd3-3cf65fcd7647	net:5b3ed0c7-20d3-45fe-8c3b-84acb64750d3:update		4042690c-33d1-4e1b-acf7-9ba58ce60da0	Update CIM CGMES network data
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.resource_uris (resource_id, value) FROM stdin;
cf379b7a-5f5e-4001-92fe-91c2dab78442	/api/nets/*
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
07482b6a-2476-4033-af31-9d6ac30697af	cbb37a43-e81a-4322-8636-a812f7de9448
07482b6a-2476-4033-af31-9d6ac30697af	e68224e2-ddad-479b-9e2a-a3937e8de51e
312930c6-3b4a-492f-9f52-bf0947d8c4e5	f36bdd5b-a3f9-4d99-8091-b057c08915d8
312930c6-3b4a-492f-9f52-bf0947d8c4e5	ef576c55-7142-4b27-a4ec-3868b685b8f8
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
4b20b197-b7c6-447d-a7f2-a1cfaf10d53e	fc3b6c76-ce9d-4f3b-9803-bd96de5529ed
04d909c8-c528-41bf-b6f3-6a1390147931	5a45080a-e4c1-47ca-9633-21e15b714a44
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_attribute (name, value, user_id, id) FROM stdin;
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
7a4cfab8-7481-473d-8923-55bf1a5212aa	\N	3d121e25-5001-4419-b312-850721a13578	f	t	\N	\N	\N	69219f75-5959-4178-a860-0ae90853470b	admin	1697629201616	\N	0
191a5553-2655-4f6d-a3a1-6ffd3163fd9b	\N	2901fd1e-88c6-4cc9-ae15-e1e6e67f813c	f	t	\N	Guest		2d41d0c8-a7ac-4cdc-b114-4baf577da237	guest	1698245815110	\N	0
380c030c-4817-4803-a50c-cc81df5530b4	demo@example.com	demo@example.com	f	t	\N	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	demo	1698589904739	\N	0
365ffe08-cd56-424a-bb33-ab3acd027c38	\N	9e46f166-1f02-4b3e-a2f7-46090f68467d	f	t	\N	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	service-account-api-backend	1698336953993	4042690c-33d1-4e1b-acf7-9ba58ce60da0	0
ba38a8be-067f-4e2f-bec7-975c982aa46a	\N	75514a99-7d00-4ac5-b055-2c1c893a27bc	f	t	\N	\N	\N	2d41d0c8-a7ac-4cdc-b114-4baf577da237	service-account-hexagon-service	1702652674995	4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
08d18f7e-70c4-4c31-b126-f71deeb5d564	380c030c-4817-4803-a50c-cc81df5530b4
08d18f7e-70c4-4c31-b126-f71deeb5d564	ba38a8be-067f-4e2f-bec7-975c982aa46a
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
e5f45988-c3b0-480e-bb01-aee1769ae71e	7a4cfab8-7481-473d-8923-55bf1a5212aa
ecbbb4db-219e-4e96-9ba7-037eb737fe2f	7a4cfab8-7481-473d-8923-55bf1a5212aa
4cc0aac9-94f5-4482-a5bb-b7e8915580a7	7a4cfab8-7481-473d-8923-55bf1a5212aa
21bd6337-2e38-411c-b4ff-d48d855e9d94	7a4cfab8-7481-473d-8923-55bf1a5212aa
93709477-00ba-480f-9068-21f3bc310392	7a4cfab8-7481-473d-8923-55bf1a5212aa
44d67e3b-ed6b-4a75-ad9c-c25ea59b1b36	7a4cfab8-7481-473d-8923-55bf1a5212aa
7301fb7c-0ec8-4c1e-b2ac-d8a7fd421ba9	7a4cfab8-7481-473d-8923-55bf1a5212aa
45ca86fe-7fca-4c1e-8008-b14fe0a12c08	7a4cfab8-7481-473d-8923-55bf1a5212aa
221c50cf-fb55-4aab-8b91-e49b8452c60a	7a4cfab8-7481-473d-8923-55bf1a5212aa
90dbca0b-b6ee-44f1-83a0-38a4f08dcd36	7a4cfab8-7481-473d-8923-55bf1a5212aa
dd813344-0148-49e7-ab85-fbb86aa87636	7a4cfab8-7481-473d-8923-55bf1a5212aa
342df5da-c02f-4417-8e4e-5fec284fbb87	7a4cfab8-7481-473d-8923-55bf1a5212aa
aac04a4c-102e-4342-bd33-4343e218134f	7a4cfab8-7481-473d-8923-55bf1a5212aa
3d54c6b3-69b5-4cab-8d4f-7efac4203353	7a4cfab8-7481-473d-8923-55bf1a5212aa
0b19e6a8-42d0-42ee-8c51-769e6f547b3b	7a4cfab8-7481-473d-8923-55bf1a5212aa
07da76a1-252e-40bc-a794-c541dfde6db5	7a4cfab8-7481-473d-8923-55bf1a5212aa
13a5d9a7-6f07-4d73-b45b-a5bd707bda70	7a4cfab8-7481-473d-8923-55bf1a5212aa
bee2081f-5f85-4972-b2cd-dd10e692ea79	7a4cfab8-7481-473d-8923-55bf1a5212aa
593342fd-01a0-47e5-9c93-83fdd691ef73	7a4cfab8-7481-473d-8923-55bf1a5212aa
c59dba83-3f47-47d1-acbb-3feaf4c55643	191a5553-2655-4f6d-a3a1-6ffd3163fd9b
c59dba83-3f47-47d1-acbb-3feaf4c55643	365ffe08-cd56-424a-bb33-ab3acd027c38
959f87a3-568a-4370-a6b9-4202fa2c83d6	365ffe08-cd56-424a-bb33-ab3acd027c38
c59dba83-3f47-47d1-acbb-3feaf4c55643	380c030c-4817-4803-a50c-cc81df5530b4
c59dba83-3f47-47d1-acbb-3feaf4c55643	ba38a8be-067f-4e2f-bec7-975c982aa46a
096a0bbc-680a-4ac3-9195-84a978946b63	ba38a8be-067f-4e2f-bec7-975c982aa46a
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: postgres_user
--

COPY public.web_origins (client_id, value) FROM stdin;
3cd83037-98f6-44da-be80-73f9e77a3d39	+
701a3ada-3c87-42d9-bfc2-710bc231c878	+
4042690c-33d1-4e1b-acf7-9ba58ce60da0	http://localhost:8443
4042690c-33d1-4e1b-acf7-9ba58ce60da0	http://localhost:3000
b467a243-0187-4bb7-8dcb-05d03fe39aec	*
4199efcf-9bbc-4bc0-ba3b-c59f80d27fe6	/*
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: postgres_user
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: postgres_user
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

